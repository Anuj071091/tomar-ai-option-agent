"""database.py - SQLite copy of the signal journal (trade_history.db inside each instrument folder).

The JSON journal stays the source of truth for the dashboard. This keeps a queryable history
(results by market regime, data for a future trade-based model) and is safe to call every run.
"""
import os
import sqlite3
from contextlib import closing

DB_NAME = "trade_history.db"
_SCHEMA = """CREATE TABLE IF NOT EXISTS trades(
    id INTEGER PRIMARY KEY AUTOINCREMENT, candle_time TEXT NOT NULL, signal TEXT NOT NULL, time TEXT,
    entry REAL, stoploss REAL, target1 REAL, target2 REAL, confidence REAL, ev REAL, regime TEXT,
    status TEXT, r REAL, closed TEXT, UNIQUE(candle_time, signal))"""
_UPSERT = """INSERT INTO trades(candle_time, signal, time, entry, stoploss, target1, target2, confidence, ev, regime, status, r, closed)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(candle_time, signal) DO UPDATE SET status=excluded.status, r=excluded.r, closed=excluded.closed"""


def _conn(data_dir):
    os.makedirs(data_dir, exist_ok=True)
    c = sqlite3.connect(os.path.join(data_dir, DB_NAME), timeout=10)
    c.execute(_SCHEMA)
    return c


def sync(data_dir, hist):
    """Insert new journal entries and update the status/result of existing ones. Returns rows processed."""
    rows = []
    for e in hist or []:
        ct = e.get("candle_time") or e.get("time")
        if not ct or not e.get("signal"):
            continue
        rows.append((ct, e["signal"], e.get("time"), e.get("entry", e.get("price")), e.get("stoploss"), e.get("target1"),
                     e.get("target2"), e.get("confidence"), e.get("ev"), e.get("regime"), e.get("status", "PENDING"),
                     e.get("r"), e.get("closed")))
    if not rows:
        return 0
    with closing(_conn(data_dir)) as c, c:
        c.executemany(_UPSERT, rows)
    return len(rows)


def by_regime(data_dir):
    """Closed trades grouped by the market regime they were taken in."""
    with closing(_conn(data_dir)) as c:
        cur = c.execute("""SELECT COALESCE(regime,'Unknown'), COUNT(*), SUM(CASE WHEN r > 0 THEN 1 ELSE 0 END), AVG(r)
                           FROM trades WHERE status IN ('WIN','LOSS','TIMEOUT') AND r IS NOT NULL
                           GROUP BY 1 ORDER BY 2 DESC""")
        return [dict(regime=a, n=n, win_rate=(w or 0) / n * 100, avg_r=avg or 0.0) for a, n, w, avg in cur.fetchall()]


def load_closed(data_dir):
    """All closed trades as a DataFrame (for future trade-based modelling; needs a few hundred rows to be meaningful)."""
    import pandas as pd
    with closing(_conn(data_dir)) as c:
        return pd.read_sql("SELECT * FROM trades WHERE status IN ('WIN','LOSS','TIMEOUT') AND r IS NOT NULL", c)

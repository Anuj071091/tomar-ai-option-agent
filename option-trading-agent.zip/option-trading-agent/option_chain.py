from nsepython import *
from datetime import datetime

# ============================================
# FETCH OPTION CHAIN
# ============================================

oc = nse_optionchain_scrapper("NIFTY")

records = oc["data"]

# ============================================
# FIND NEAREST EXPIRY
# ============================================

expiry_dates = []

for row in records:

    if row.get("CE"):

        expiry_dates.append(
            row["CE"]["expiryDate"]
        )

    elif row.get("PE"):

        expiry_dates.append(
            row["PE"]["expiryDate"]
        )

expiry_dates = list(set(expiry_dates))

expiry_dates.sort(
    key=lambda x: datetime.strptime(
        x,
        "%d-%b-%Y"
    )
)

nearest_expiry = expiry_dates[0]

# ============================================
# SPOT PRICE
# ============================================

spot_price = None

for row in records:

    if row.get("CE"):

        spot_price = row["CE"]["underlyingValue"]
        break

    elif row.get("PE"):

        spot_price = row["PE"]["underlyingValue"]
        break

# ============================================
# VARIABLES
# ============================================

total_ce = 0
total_pe = 0

max_ce_oi = 0
max_pe_oi = 0

max_ce_strike = None
max_pe_strike = None

# ============================================
# NEAREST EXPIRY + ATM AREA ONLY
# ============================================

for row in records:

    ce = row.get("CE")
    pe = row.get("PE")

    # Expiry Filter

    if ce:

        if ce["expiryDate"] != nearest_expiry:
            continue

    elif pe:

        if pe["expiryDate"] != nearest_expiry:
            continue

    strike = float(row["strikePrice"])

    # Only nearby strikes
    # 22600 spot => 22100 to 23100

    if abs(strike - spot_price) > 500:
        continue

    # CE

    if ce:

        ce_oi = ce.get(
            "openInterest",
            0
        )

        total_ce += ce_oi

        if ce_oi > max_ce_oi:

            max_ce_oi = ce_oi
            max_ce_strike = strike

    # PE

    if pe:

        pe_oi = pe.get(
            "openInterest",
            0
        )

        total_pe += pe_oi

        if pe_oi > max_pe_oi:

            max_pe_oi = pe_oi
            max_pe_strike = strike

# ============================================
# PCR
# ============================================

if total_ce > 0:

    pcr = round(
        total_pe / total_ce,
        2
    )

else:

    pcr = 0

# ============================================
# MARKET BIAS
# ============================================

if pcr > 1.1:

    bias = "BULLISH"

elif pcr < 0.9:

    bias = "BEARISH"

else:

    bias = "SIDEWAYS"

# ============================================
# TRADING VIEW
# ============================================

if pcr < 0.9:

    view = "BEARISH"

elif pcr > 1.1:

    view = "BULLISH"

else:

    view = "NEUTRAL"

# ============================================
# OUTPUT
# ============================================

print("\n")
print("=" * 70)
print("           NIFTY OPTION CHAIN ANALYSIS")
print("=" * 70)

print(f"\nSpot Price      : {spot_price}")
print(f"Nearest Expiry  : {nearest_expiry}")

print("\nPCR")
print("-" * 70)

print(f"PCR             : {pcr}")
print(f"Market Bias     : {bias}")

print("\nSUPPORT / RESISTANCE")
print("-" * 70)

print(f"Support         : {max_pe_strike}")
print(f"Resistance      : {max_ce_strike}")

print("\nOI DATA")
print("-" * 70)

print(f"Highest CE OI   : {max_ce_oi}")
print(f"Highest PE OI   : {max_pe_oi}")

print("\nTOTAL OI")
print("-" * 70)

print(f"Total CE OI     : {total_ce}")
print(f"Total PE OI     : {total_pe}")

print("\nTRADING VIEW")
print("-" * 70)

print(f"Option Chain View : {view}")

if (
    max_pe_strike
    and
    spot_price <= max_pe_strike
):
    print("Market near support")

elif (
    max_ce_strike
    and
    spot_price >= max_ce_strike
):
    print("Market near resistance")

else:
    print("Market inside range")

print("\nTimestamp")
print("-" * 70)

print(oc["timestamp"])

print("=" * 70)
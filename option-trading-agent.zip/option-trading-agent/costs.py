"""costs.py - NSE index-option trading costs and a net-of-costs replay of the journal.

Rates checked Nov 2026 (post Finance Act 2026, effective 1 Apr 2026). Verify against your broker's charges page:
  brokerage     flat Rs 20 per executed order (or 0.03% if lower)
  STT           0.15% of premium, SELL side only          (was 0.10% until 31 Mar 2026)
  exchange fee  0.03553% of premium, both sides           (NSE options)
  SEBI fee      Rs 10 per crore of turnover
  GST           18% on brokerage + exchange fee + SEBI fee
  stamp duty    0.003% of premium, BUY side only

replay() prices every CLOSED journal entry that stored its option premiums (entries made before this update
have none and are skipped - nothing is guessed). Exit premium for WIN/LOSS uses the plan's delta-based
target/stop premium, so it is an estimate, not a broker fill.
"""
import numpy as np

BROKERAGE_FLAT, BROKERAGE_PCT = 20.0, 0.0003
STT_PCT, EXCH_PCT, SEBI_PCT, GST_PCT, STAMP_PCT = 0.0015, 0.0003553, 0.000001, 0.18, 0.00003
TICK = 0.05


def order_cost(price, qty, side):
    t = max(float(price), 0.0) * int(qty)
    if t <= 0:
        return dict(turnover=0.0, brokerage=0.0, stt=0.0, exchange=0.0, sebi=0.0, gst=0.0, stamp=0.0, total=0.0)
    sell = side.upper() == "SELL"
    brokerage = min(BROKERAGE_FLAT, t * BROKERAGE_PCT)
    stt, stamp = (t * STT_PCT if sell else 0.0), (0.0 if sell else t * STAMP_PCT)
    exch, sebi = t * EXCH_PCT, t * SEBI_PCT
    gst = (brokerage + exch + sebi) * GST_PCT
    return dict(turnover=t, brokerage=brokerage, stt=stt, exchange=exch, sebi=sebi, gst=gst, stamp=stamp,
                total=brokerage + stt + exch + sebi + gst + stamp)


def slip(price, side, ticks=2):
    """Long options pay more when buying and receive less when selling."""
    return price + ticks * TICK if side.upper() == "BUY" else max(price - ticks * TICK, TICK)


def replay(hist, lot_size=65, lots=1, slippage_ticks=2):
    """Net-of-costs result per closed journal entry that has option premiums. Returns (rows, equity_rs, skipped)."""
    rows, eq, cum, skipped, qty = [], [], 0.0, 0, int(lot_size) * int(lots)
    for e in hist:
        if e.get("status") not in ("WIN", "LOSS", "TIMEOUT"):
            continue
        o = e.get("option") or {}
        prem, sl, t1 = o.get("premium"), o.get("sl_prem"), o.get("t1_prem")
        if not (prem and sl and t1):
            skipped += 1
            continue
        r = float(e.get("r", 0.0))
        exit_p = sl if e["status"] == "LOSS" else t1 if e["status"] == "WIN" else prem + r * (prem - sl)
        ein, eout = slip(prem, "BUY", slippage_ticks), slip(max(exit_p, TICK), "SELL", slippage_ticks)
        c = order_cost(ein, qty, "BUY")["total"] + order_cost(eout, qty, "SELL")["total"]
        net = (eout - ein) * qty - c
        risk = max((prem - sl) * qty, 1.0)
        rows.append(dict(time=e.get("time"), signal=e["signal"], status=e["status"], r_gross=r, r_net=net / risk,
                         gross=(exit_p - prem) * qty, costs=c, net=net))
        cum += net
        eq.append(round(cum, 2))
    return rows, eq, skipped


def summary(rows):
    if not rows:
        return dict(n=0)
    r = np.array([x["r_net"] for x in rows])
    net, costs = sum(x["net"] for x in rows), sum(x["costs"] for x in rows)
    return dict(n=len(rows), win_rate=float((r > 0).mean() * 100), avg_r_net=float(r.mean()), avg_r_gross=float(np.mean([x["r_gross"] for x in rows])),
                net=float(net), costs=float(costs), gross=float(sum(x["gross"] for x in rows)))


def stress(rows, mults=(1.0, 1.5, 2.0)):
    """Total net Rs if real costs turned out to be 1.5x or 2x the model."""
    net, costs = sum(x["net"] for x in rows), sum(x["costs"] for x in rows)
    return [dict(mult=m, total=net - (m - 1) * costs) for m in mults]

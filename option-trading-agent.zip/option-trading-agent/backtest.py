"""backtest.py - walk-forward backtest of the AI engine's learning model.

For every trading day D it trains ONLY on candles before D (same train_models() the live agent uses, including the
unseen-data reliability test), then replays the live decision rule on day D candle by candle. Labels never cross a
day boundary, so there is no look-ahead. News / option-chain / GIFT tilt cannot be replayed (no history), so this
measures the model + risk rules alone. Costs are charged as in the live decision (COST_R per trade).

    python backtest.py                       # NIFTY, last ~30 days from Yahoo
    python backtest.py --inst SENSEX --sens Active
    python backtest.py --demo                # offline synthetic data (pipeline test only, results are meaningless)
    python backtest.py --csv trades.csv      # save every simulated trade
"""
import argparse
from datetime import datetime

import numpy as np
import pandas as pd

import ai_engine as ai
import final_agent as fa


def run_backtest(d, sens="Balanced", max_signals_day=3, stop_after_losses=2, min_train_days=8, min_rows=300):
    S = ai.SENSITIVITY[sens]
    f, aux = ai.build_features(d)
    rl, rs = ai.triple_barrier(d, aux["atr"].values)
    X = f[ai.FEATURES].values.astype(float)
    days = d.index.normalize()
    ends = d.index + pd.Timedelta(minutes=fa.CFG["candle_minutes"])
    t_first, t_last = fa._hm(fa.CFG["first_trade"]), fa._hm(fa.CFG["last_trade"])
    trades, base, tested_days = [], [], 0
    for k, day in enumerate(sorted(set(days))):
        pos = np.where(days == day)[0]
        first = int(pos[0])
        if k < min_train_days or first < min_rows:
            continue
        M = ai.train_models(f.iloc[:first], rl[:first], rs[:first], min_rows=min_rows)
        if M.get("models") is None:
            continue
        tested_days += 1
        ml, ms = M["models"]
        scale = max(M["rel"], S["floor"])
        Xd = X[pos]
        ok = np.isfinite(Xd).all(1)
        Xz = np.nan_to_num(Xd)
        el = ai.ridge_edge(ml, Xz) * scale - ai.COST_R
        es = ai.ridge_edge(ms, Xz) * scale - ai.COST_R
        base += [v for v in np.r_[rl[pos], rs[pos]] if np.isfinite(v)]
        n_sig, streak, busy_until = 0, 0, -1
        for q, p in enumerate(pos):
            if not ok[q] or p <= busy_until:
                continue
            hm = (ends[p].hour, ends[p].minute)
            if hm < t_first or hm > t_last:
                continue
            if n_sig >= max_signals_day or streak >= stop_after_losses:
                break
            lean = "CALL" if el[q] > es[q] else "PUT"
            ev, other = (el[q], es[q]) if lean == "CALL" else (es[q], el[q])
            if not (ev >= S["ev_min"] and ev - other >= S["margin"]):
                continue
            r = rl[p] if lean == "CALL" else rs[p]
            if not np.isfinite(r):
                continue
            n_sig += 1
            busy_until = p + ai.HORIZON
            streak = streak + 1 if r <= -0.99 else (0 if r > 0 else streak)
            trades.append(dict(date=day.strftime("%d-%m-%Y"), time=ends[p].strftime("%H:%M"), side=lean,
                               ev=round(float(ev), 3), reliability=M["rel"], r=round(float(r), 3),
                               net=round(float(r - ai.COST_R), 3)))
    return trades, base, tested_days


def summarize(trades, base, tested_days):
    out = dict(days_tested=tested_days, trades=len(trades), random_trade_avg_r=(float(np.mean(base)) if base else None))
    if not trades:
        return out
    t = pd.DataFrame(trades)
    eq = t["net"].cumsum()
    gain, loss = t.loc[t["net"] > 0, "net"].sum(), -t.loc[t["net"] < 0, "net"].sum()
    out.update(win_rate=float((t["r"] > 0).mean() * 100), avg_gross_r=float(t["r"].mean()), avg_net_r=float(t["net"].mean()),
               total_net_r=float(t["net"].sum()), max_drawdown_r=float((eq.cummax() - eq).max()),
               profit_factor=(float(gain / loss) if loss > 0 else None))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inst", default="NIFTY", choices=list(fa.INSTRUMENTS))
    ap.add_argument("--sens", default="Balanced", choices=list(ai.SENSITIVITY))
    ap.add_argument("--max-signals", type=int, default=3)
    ap.add_argument("--stop-losses", type=int, default=2)
    ap.add_argument("--demo", action="store_true", help="offline synthetic candles")
    ap.add_argument("--csv", help="save simulated trades to this CSV file")
    a = ap.parse_args()
    now = datetime.now(fa.IST)
    if a.demo:
        raw = fa.make_demo_candles(now.replace(tzinfo=None), days=30)
    else:
        raw = fa.fetch_candles(a.inst)
    d = fa.prepare_candles(raw, now)
    print(f"{a.inst}: {len(d)} candles, {d.index[0]:%d-%m-%Y} to {d.index[-1]:%d-%m-%Y}, sensitivity {a.sens}")
    trades, base, n_days = run_backtest(d, a.sens, a.max_signals, a.stop_losses)
    s = summarize(trades, base, n_days)
    print(f"Days tested (out-of-sample): {s['days_tested']}   Simulated trades: {s['trades']}")
    if s["random_trade_avg_r"] is not None:
        print(f"Average result of a RANDOM trade on the same days: {s['random_trade_avg_r']:+.3f}R (the bar to beat)")
    if s["trades"]:
        pf = "n/a" if s["profit_factor"] is None else f"{s['profit_factor']:.2f}"
        print(f"Win rate {s['win_rate']:.0f}%  |  avg {s['avg_gross_r']:+.2f}R gross, {s['avg_net_r']:+.2f}R net of costs  |  "
              f"total {s['total_net_r']:+.1f}R  |  max drawdown {s['max_drawdown_r']:.1f}R  |  profit factor {pf}")
        print("Break-even win rate for stop 1R / target 1.5R is about 40% before costs.")
        if a.csv:
            pd.DataFrame(trades).to_csv(a.csv, index=False)
            print("Trades saved to", a.csv)
    else:
        print("The model took no trades in the tested days (it found no edge above the threshold). That is a valid result.")


if __name__ == "__main__":
    main()

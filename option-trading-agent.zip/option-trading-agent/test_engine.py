"""test_engine.py - run:  python test_engine.py   (no internet needed)"""
import json
import os
import shutil
import tempfile
import warnings
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

import ai_engine as ai
import final_agent as fa

warnings.filterwarnings("ignore")
PASS, FAIL = [], []


def check(name, cond, extra=""):
    (PASS if cond else FAIL).append(name)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))


def make(days=30, phi=0.0, seed=1, start=24500.0, sigma=0.0006, end="2026-11-03"):
    rng = np.random.default_rng(seed)
    idx = []
    for day in pd.bdate_range(end=end, periods=days):
        idx += list(pd.date_range(day + pd.Timedelta(hours=9, minutes=15), day + pd.Timedelta(hours=15, minutes=25), freq="5min"))
    idx = pd.DatetimeIndex(idx)
    n = len(idx)
    e = rng.normal(0, sigma, n)
    r = np.zeros(n)
    for i in range(1, n):
        r[i] = phi * r[i - 1] + e[i]
    close = start * np.exp(np.cumsum(r))
    op = np.r_[start, close[:-1]]
    hi = np.maximum(op, close) * (1 + np.abs(rng.normal(0, 0.0002, n)))
    lo = np.minimum(op, close) * (1 - np.abs(rng.normal(0, 0.0002, n)))
    return pd.DataFrame(dict(Open=op, High=hi, Low=lo, Close=close, Volume=0.0), index=idx)


# ---------------------------------------------------------------- 1. no look-ahead in features
d = make(seed=3)
f_full, _ = ai.build_features(d)
cut = len(d) - 200
f_cut, _ = ai.build_features(d.iloc[:cut])
a, b = f_full.iloc[cut - 1].values, f_cut.iloc[-1].values
check("features at candle t do not change when future candles are appended", np.allclose(a, b, equal_nan=True, atol=1e-9),
      f"max diff {np.nanmax(np.abs(a - b)):.2e}")
check("latest feature row has no NaN", np.isfinite(f_full.iloc[-1].values).all())

# ---------------------------------------------------------------- 2. triple barrier labels
idx = pd.date_range("2026-11-03 09:15", periods=30, freq="5min")
px = np.full(30, 100.0)
h = px + 0.1
l = px - 0.1
h[5] = 102.0                                     # candle 5 touches +2 -> long target (1.5 ATR, ATR=1) hit
hm = pd.DataFrame(dict(Open=px, High=h, Low=l, Close=px, Volume=0.0), index=idx)
rl, rs = ai.triple_barrier(hm, np.ones(30))
check("long target hit gives +1.5R", abs(rl[0] - 1.5) < 1e-9, f"{rl[0]}")
check("same candle moves a PUT to stop -> -1R", abs(rs[0] + 1.0) < 1e-9, f"{rs[0]}")
h2, l2 = px + 0.1, px - 0.1
h2[3], l2[3] = 102.0, 98.0                       # both barriers inside one candle -> stop first (conservative)
hm2 = pd.DataFrame(dict(Open=px, High=h2, Low=l2, Close=px, Volume=0.0), index=idx)
rl2, _ = ai.triple_barrier(hm2, np.ones(30))
check("both barriers in one candle counts as a stop", abs(rl2[0] + 1.0) < 1e-9)
check("last candles (unknown future) are not labelled", np.isnan(rl[-1]) and np.isnan(rl[-5]))

# ---------------------------------------------------------------- 3. model honesty: noise vs real edge
def fired_R(phi, sens, seeds=14):
    R, pts = [], 0
    for sd in range(seeds):
        dd = make(days=40, phi=phi, seed=900 + sd)
        f, aux = ai.build_features(dd)
        rl_, rs_ = ai.triple_barrier(dd, aux["atr"].values)
        for pos in range(len(dd) - 700, len(dd) - 40, 40):
            sub = dd.iloc[:pos + 1]
            end = sub.index[-1] + pd.Timedelta(minutes=5)
            if not (9 * 60 + 30 <= end.hour * 60 + end.minute <= 15 * 60):
                continue
            pts += 1
            act = ai.analyze(sub, sub.index[-1].to_pydatetime(), sens=sens)["decision"]["action"]
            if act != "WAIT":
                R.append(rl_[pos] if act == "BUY CALL" else rs_[pos])
    R = np.array([r for r in R if np.isfinite(r)])
    return len(R), pts, (R.mean() if len(R) else 0.0), (R.std() / np.sqrt(len(R)) if len(R) > 1 else 9.9)


n0, p0, m0, se0 = fired_R(0.0, "Balanced")
check("pure noise: engine stays mostly out", n0 / p0 < 0.25, f"{n0}/{p0} signals")
check("pure noise: fired signals have no significant edge (|mean R| < 2.5 se)", abs(m0) < 2.5 * se0, f"mean {m0:+.2f} se {se0:.2f}")
n1, p1, m1, se1 = fired_R(0.25, "Active")
check("planted momentum edge: fired signals earn positive R", m1 > 0.05, f"mean {m1:+.2f} +/- {se1:.2f} on {n1} signals")

# ---------------------------------------------------------------- 4. news analysis
now = datetime.now().timestamp()
bull = ai.analyze_news([dict(title="Nifty ends higher as banks rally on strong FII inflows", ts=now - 600),
                        dict(title="Sensex surges to record high", ts=now - 1200)], now)
bear = ai.analyze_news([dict(title="Markets crash as war fears trigger sell-off", ts=now - 600),
                        dict(title="Nifty slumps, FII outflows deepen", ts=now - 900)], now)
check("bullish headlines score positive", bull["score"] > 0.3 and bull["tone"] == "POSITIVE", f"{bull['score']}")
check("bearish headlines score negative", bear["score"] < -0.3 and bear["tone"] == "NEGATIVE", f"{bear['score']}")
check("negation flips sentiment", ai.score_headline("Nifty not falling despite global rout") > ai.score_headline("Nifty falling on global rout"))
dup = ai.analyze_news([dict(title="Nifty rallies", ts=now), dict(title="Nifty rallies!", ts=now)], now)
check("duplicate headlines are merged", dup["count"] == 1)
ev = ai.analyze_news([dict(title="RBI MPC policy decision today", ts=now), dict(title="RBI repo rate outcome awaited", ts=now)], now)
check("two RBI headlines raise event risk to HIGH", ev["event_risk"] == "HIGH", ev["event_risk"])
check("empty news is handled", ai.analyze_news([], now)["tone"] == "N/A")

# ---------------------------------------------------------------- 5. Claude reply parsing (no network)
ok = ai.parse_llm_json('Sure! {"market_bias":"BEARISH","news_impact":-0.6,"event_risk":"HIGH","veto":true,"veto_reason":"RBI today","summary":"x"}')
check("LLM JSON is parsed, even with extra text", ok["ok"] and ok["veto"] and ok["event_risk"] == "HIGH")
check("bad LLM reply fails safely", not ai.parse_llm_json("no json here")["ok"])
check("missing API key fails safely", not ai.llm_review({}, [], api_key="")["ok"] or os.environ.get("ANTHROPIC_API_KEY"))
news_llm = ai.analyze_news([dict(title="Nifty rallies", ts=now)], now, llm=ok)
check("Claude opinion blends into news score and raises risk", news_llm["event_risk"] == "HIGH" and news_llm["score"] < bull["score"])

# ---------------------------------------------------------------- 6. veto + blockers decide WAIT
dd = make(phi=0.25, seed=5)
A = ai.analyze(dd, dd.index[-1].to_pydatetime(), sens="Active", blockers=["Market is closed"])
check("blocker forces WAIT", A["decision"]["action"] == "WAIT" and "Market is closed" in A["decision"]["blockers"])
A2 = ai.analyze(dd, dd.index[-1].to_pydatetime(), sens="Active", llm=ok)
check("Claude veto forces WAIT", A2["decision"]["action"] == "WAIT")

# ---------------------------------------------------------------- 7. plan maths
p = ai.build_plan("CALL", 24000.0, 20.0)
check("CALL plan: SL below, targets above, RR 1.5", p["stoploss"] < 24000 < p["target1"] < p["target2"] and p["rr"] == 1.5)
p = ai.build_plan("PUT", 24000.0, 20.0)
check("PUT plan: SL above, targets below", p["stoploss"] > 24000 > p["target1"] > p["target2"])
check("delta is sane", 0.4 < ai.bs_delta(24000, 24000, 3, 14, True) < 0.6 and ai.bs_delta(24000, 24000, 3, 0, True) == 0.5)

# ---------------------------------------------------------------- 8. journal resolve + daily guard
idx = pd.date_range("2026-11-03 09:15", periods=40, freq="5min")
c = np.full(40, 100.0)
hh, ll = c + 0.2, c - 0.2
hh[8] = 103.0
j = pd.DataFrame(dict(Open=c, High=hh, Low=ll, Close=c, Volume=0.0), index=idx)
ct = idx[5].strftime("%d-%m-%Y %H:%M:%S")
hist = [dict(time="03-11-2026 10:00:00", candle_time=ct, signal="BUY CALL", entry=100.0, stoploss=98.0, target1=103.0, max_bars=12, status="PENDING"),
        dict(time="03-11-2026 10:01:00", candle_time=ct, signal="BUY PUT", entry=100.0, stoploss=102.0, target1=97.0, max_bars=12, status="PENDING")]
ai.resolve_journal(hist, j)
check("journal: CALL hits target -> WIN +1.5R", hist[0]["status"] == "WIN" and abs(hist[0]["r"] - 1.5) < 0.01, str(hist[0].get("r")))
check("journal: PUT stopped out -> LOSS -1R", hist[1]["status"] == "LOSS" and hist[1]["r"] == -1.0)
st = ai.journal_stats(hist)
check("journal stats", st["n"] == 2 and st["wins"] == 1 and abs(st["total_r"] - 0.5) < 0.01)
hist2 = [dict(time="03-11-2026 10:00:00", status="LOSS", r=-1.0), dict(time="03-11-2026 10:30:00", status="LOSS", r=-1.0)]
check("two losses in a row pauses the day", any("paused" in b for b in ai.today_guard(hist2, "03-11-2026", 3, 2)))
check("signal cap reached blocks", any("limit" in b for b in ai.today_guard(hist2 + [dict(time="03-11-2026 11:00:00", status="WIN", r=1.5)], "03-11-2026", 3, 2)))
check("guard ignores other days", ai.today_guard(hist2, "04-11-2026", 3, 2) == [])

# ---------------------------------------------------------------- 9. full agent run (demo data, temp dir)
tmp = tempfile.mkdtemp()
IST = ZoneInfo("Asia/Kolkata")
now_ist = datetime(2026, 11, 3, 11, 2, tzinfo=IST)           # a Tuesday, market open
nn = now_ist.replace(tzinfo=None)
cand = fa.make_demo_candles(nn, seed=21)
spot = float(cand["Close"].iloc[-1])
kw = dict(candles=cand, chain_raw=fa.make_demo_chain(spot, nn), news_items=fa.DEMO_NEWS, now=now_ist, data_dir=tmp, send=False,
          llm=None, gift=dict(price=spot, change=10.0, change_pct=0.1, expiry="x", time="t"), vix=dict(last=14.0, prev=14.5, change_pct=-3.4),
          settings=dict(fa.DEFAULT_SETTINGS, sensitivity="Active", max_signals_day=5))
r = fa.safe_run("NIFTY", **kw)
check("agent run writes schema-4 signals.json", r is not None and r["schema"] == 4 and r["decision"]["action"] in ("WAIT", "BUY CALL", "BUY PUT"))
P = fa.get_paths(tmp, "NIFTY")
sig = json.load(open(P["signals"]))
need = ["decision", "regime", "model", "context", "news", "plan", "session", "chain", "vix", "tech"]
check("signals.json has every key the dashboard reads", all(k in sig for k in need))
check("market_data.csv has indicator columns", {"ema20", "ema50", "sess_mean", "atr"} <= set(pd.read_csv(P["market"], index_col=0).columns))
check("signals.json is valid strict JSON (no NaN)", "NaN" not in open(P["signals"]).read())
check("lock file released", not os.path.exists(P["lock"]))
r2 = fa.safe_run("SENSEX", **{**kw, "chain_raw": None, "gift": None})
check("SENSEX (no option chain) runs", r2 is not None and r2["chain"] is None and r2["decision"]["action"] in ("WAIT", "BUY CALL", "BUY PUT"))

# force a signal path: market-hours alert, journal, dedupe
best = None
for sd in range(60):
    cc = fa.make_demo_candles(nn, seed=sd, phi=0.25)
    s_ = dict(kw, candles=cc, chain_raw=fa.make_demo_chain(float(cc["Close"].iloc[-1]), nn))
    t2 = tempfile.mkdtemp()
    rr = fa.safe_run("NIFTY", **{**s_, "data_dir": t2})
    if rr and rr["decision"]["action"] != "WAIT":
        best = (sd, t2, s_, rr)
        break
check("a tradable setup can be found in demo data", best is not None)
if best:
    sd, t2, s_, rr = best
    h_ = json.load(open(fa.get_paths(t2, "NIFTY")["history"]))
    check("signal is written to journal as PENDING", len(h_) == 1 and h_[0]["status"] == "PENDING" and h_[0]["signal"] == rr["decision"]["action"])
    fa.safe_run("NIFTY", **{**s_, "data_dir": t2})
    h_ = json.load(open(fa.get_paths(t2, "NIFTY")["history"]))
    check("same signal on the next run is not duplicated", len(h_) == 1)
    check("plan matches the decision side", rr["plan"]["side"] == ("CALL" if rr["decision"]["action"] == "BUY CALL" else "PUT"))
    # market closed -> blocker
    closed = datetime(2026, 11, 3, 18, 0, tzinfo=IST)
    rc = fa.safe_run("NIFTY", **{**s_, "data_dir": tempfile.mkdtemp(), "now": closed})
    check("after market close the agent says WAIT", rc is not None and rc["decision"]["action"] == "WAIT")
    shutil.rmtree(t2, ignore_errors=True)
shutil.rmtree(tmp, ignore_errors=True)

print(f"\n{len(PASS)} passed, {len(FAIL)} failed")
if FAIL:
    print("FAILED:", FAIL)
    raise SystemExit(1)

"""
dashboard.py - AI Option Desk (v4.2)

The dashboard calculates nothing about the market itself. It reads what final_agent.py wrote
(signals.json, market_data.csv, option_chain.json, signal_history.json), so it always matches the agent.
By default it also runs the agent in a background thread, so one command is enough:

    streamlit run dashboard.py
"""
import bisect
import inspect
import json
import os
import threading
import time
import traceback
from datetime import datetime
from html import escape as esc
from zoneinfo import ZoneInfo

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components

try:
    from streamlit_autorefresh import st_autorefresh
except Exception:                                   # optional dependency
    st_autorefresh = None

import ai_engine as ai
import final_agent as fa
from chart_component import chart_html

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("NIFTY_DATA_DIR") or BASE
UI_FILE = os.path.join(BASE, "dashboard_settings.json")
IST = ZoneInfo("Asia/Kolkata")

st.set_page_config(page_title="AI Option Desk", page_icon="📈", layout="wide", initial_sidebar_state="collapsed")

def stretch(fn=None):
    """Works on old Streamlit (use_container_width) and new Streamlit (width='stretch')."""
    try:
        new = "width" in inspect.signature(fn or st.button).parameters
    except (TypeError, ValueError):
        new = True
    return {"width": "stretch"} if new else {"use_container_width": True}


# ------------------------------------------------------------------ themes
THEMES = {
    "Dark": dict(BG="#0a0e13", PANEL="#111720", RAISED="#171f2b", BORDER="#1f2937", GRID="#161d28", TEXT="#e6ecf4",
                 MUTED="#8493a7", UP="#2fd0a0", DOWN="#f26d78", WARN="#e9b44c", INFO="#7fb2ff"),
    "Light": dict(BG="#f3f5f8", PANEL="#ffffff", RAISED="#f7f9fc", BORDER="#dbe2ec", GRID="#e9eef5", TEXT="#0f1b2d",
                  MUTED="#5a6b82", UP="#0c9a74", DOWN="#d6384a", WARN="#a86a00", INFO="#1f63c9"),
}
try:
    with open(UI_FILE) as f:
        saved = json.load(f)
except Exception:
    saved = {}


def pick(opts, key, default):
    v = saved.get(key, default)
    return opts.index(v) if v in opts else opts.index(default)


REFRESH, FONTS, CHART_H, BARS = [15, 30, 60, 120], [15, 16, 18], [480, 580, 700], [60, 100, 160, 260]
SS = fa.load_settings(DATA)

top_l, top_m, top_run, top_set = st.columns([1.2, 2.5, 0.85, 0.75])
force = top_run.button("Run agent now", key="run_now", **stretch())
manual_run = force
try:
    settings_ui = top_set.popover("Settings", **stretch(st.popover))
except Exception:                                   # very old / unusual Streamlit: fall back to a bar
    settings_ui = st.expander("Settings", expanded=False)
with settings_ui:
    st.markdown("**Display**")
    theme_name = st.selectbox("Theme", list(THEMES), index=pick(list(THEMES), "theme", "Dark"))
    auto_on = st.toggle("Auto-refresh", value=saved.get("auto_on", True))
    refresh_sec = st.selectbox("Refresh every (seconds)", REFRESH, index=pick(REFRESH, "refresh_sec", 60))
    font_px = st.selectbox("Text size", FONTS, index=pick(FONTS, "font_px", 16))
    chart_h = st.selectbox("Chart height", CHART_H, index=pick(CHART_H, "chart_h", 580))
    chart_bars = st.selectbox("Visible candles", BARS, index=pick(BARS, "chart_bars", 100))
    show_levels = st.toggle("Chart levels (stop, targets, OI walls)", value=saved.get("show_levels", True))
    show_marks = st.toggle("Chart: past signals", value=saved.get("show_marks", True))
    show_ema = st.toggle("Chart: EMA 20/50 + session average", value=saved.get("show_ema", True))
    st.markdown("**AI engine**")
    sens = st.radio("Sensitivity", list(ai.SENSITIVITY), index=list(ai.SENSITIVITY).index(SS["sensitivity"]), horizontal=True,
                    help="Conservative = fewer, stronger setups. Active = more setups, each with a smaller edge.")
    has_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    use_llm = st.toggle("Claude news and risk review", value=bool(SS["use_llm"]) and has_key, disabled=not has_key,
                        help="Needs ANTHROPIC_API_KEY in your environment. Without it the built-in news analyser is used.")
    max_sig = st.selectbox("Max signals per day", [1, 2, 3, 5, 8], index=[1, 2, 3, 5, 8].index(SS["max_signals_day"]) if SS["max_signals_day"] in (1, 2, 3, 5, 8) else 2)
    stop_loss_n = st.selectbox("Pause after consecutive losses", [1, 2, 3], index=[1, 2, 3].index(SS["stop_after_losses"]) if SS["stop_after_losses"] in (1, 2, 3) else 1)
    bg_agent = st.toggle("Run the agent inside the dashboard", value=bool(SS["bg_agent"]),
                         help="Turn off if you run `python final_agent.py --loop 60` yourself.")
    st.caption("Changes are saved automatically.")

ui_now = dict(theme=theme_name, auto_on=auto_on, refresh_sec=refresh_sec, font_px=font_px, chart_h=chart_h,
              chart_bars=chart_bars, show_levels=show_levels, show_marks=show_marks, show_ema=show_ema)
if ui_now != saved:
    try:
        with open(UI_FILE, "w") as f:
            json.dump(ui_now, f)
    except Exception:
        pass
new_ai = dict(sensitivity=sens, use_llm=bool(use_llm) if has_key else bool(SS['use_llm']), max_signals_day=int(max_sig), stop_after_losses=int(stop_loss_n), bg_agent=bool(bg_agent))
ai_changed = any(SS.get(k) != v for k, v in new_ai.items())
if ai_changed:
    fa.save_settings(DATA, new_ai)
    force = True

T = THEMES[theme_name]
BG, PANEL, RAISED, BORDER, GRID = T["BG"], T["PANEL"], T["RAISED"], T["BORDER"], T["GRID"]
UP, DOWN, WARN, INFO, TEXT, MUTED = T["UP"], T["DOWN"], T["WARN"], T["INFO"], T["TEXT"], T["MUTED"]
if auto_on and st_autorefresh:
    st_autorefresh(interval=refresh_sec * 1000, key=f"refresh_{refresh_sec}")

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
html, body, [class*="css"], .stApp {{ font-family:'Manrope',system-ui,sans-serif; color:{TEXT}; }}
html {{ font-size:{font_px}px; }}
.stApp {{ background:{BG}; }}
header[data-testid="stHeader"] {{ background:transparent; }}
#MainMenu, footer, .stDeployButton, [data-testid="stToolbar"] {{ visibility:hidden; }}
.block-container {{ padding-top:1.4rem; max-width:1560px; }}
h1,h2,h3,[data-testid="stMarkdownContainer"] {{ color:{TEXT}; }}
label, label p, [data-testid="stWidgetLabel"] p {{ color:{MUTED} !important; }}
div[role="radiogroup"] label p {{ color:{TEXT} !important; }}
[data-baseweb="input"], [data-baseweb="input"] input, [data-baseweb="select"] > div
  {{ background:{PANEL} !important; color:{TEXT} !important; border-color:{BORDER} !important; }}
[data-baseweb="popover"] li, [data-baseweb="popover"] ul {{ background:{PANEL} !important; color:{TEXT} !important; }}
[data-testid="stExpander"] {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:10px; }}
[data-testid="stExpander"] summary p, [data-testid="stExpander"] summary {{ color:{TEXT} !important; }}
[data-testid="stPopoverBody"] {{ background:{PANEL}; border:1px solid {BORDER}; min-width:340px; }}
.stButton button, .stDownloadButton button, [data-testid="stPopover"] button
  {{ background:{PANEL}; color:{TEXT}; border:1px solid {BORDER}; border-radius:8px; }}
button[data-baseweb="tab"] p {{ color:{MUTED} !important; font-weight:600; }}
button[data-baseweb="tab"][aria-selected="true"] p {{ color:{TEXT} !important; }}
.num {{ font-family:'IBM Plex Mono',monospace; font-variant-numeric:tabular-nums; }}
.brand {{ font-weight:800; font-size:1.25rem; letter-spacing:-0.02em; line-height:1.1; }}
.brand small {{ display:block; font-weight:500; font-size:.78rem; color:{MUTED}; letter-spacing:0; margin-top:2px; }}
.chip {{ display:inline-block; padding:3px 11px; border-radius:999px; font-size:.8rem; margin:0 6px 6px 0;
        border:1px solid var(--c); color:var(--c); white-space:nowrap; font-weight:600; }}
.chip.fill {{ background:var(--c); color:{BG}; }}
.card {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:12px; padding:16px 18px; }}
.card + .card {{ margin-top:12px; }}
.verdict {{ border-left:4px solid var(--c); }}
.verdict .act {{ font-size:2.5rem; font-weight:800; letter-spacing:-0.03em; color:var(--c); line-height:1.05; }}
.verdict .sub {{ color:{MUTED}; font-size:.95rem; margin-top:6px; }}
.meter {{ position:relative; height:8px; border-radius:4px; margin:16px 2px 4px;
         background:linear-gradient(90deg,{DOWN},{BORDER} 50%,{UP}); }}
.meter .dot {{ position:absolute; top:-5px; width:18px; height:18px; border-radius:50%; background:{TEXT};
              border:3px solid {BG}; transform:translateX(-50%); }}
.meter-l {{ display:flex; justify-content:space-between; color:{MUTED}; font-size:.78rem; margin-bottom:10px; }}
.txt {{ font-size:.95rem; line-height:1.5; }}
.muted {{ color:{MUTED}; }}
.row {{ display:flex; justify-content:space-between; align-items:baseline; padding:8px 0; border-bottom:1px solid {GRID}; gap:10px; }}
.row:last-child {{ border-bottom:none; }}
.row .k {{ color:{MUTED}; font-size:.9rem; }}
.pt {{ display:flex; gap:9px; padding:5px 0; font-size:.92rem; line-height:1.35; }}
.pt i {{ flex:none; width:8px; height:8px; border-radius:50%; margin-top:6px; background:var(--c); }}
.stat {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:10px; padding:12px 14px; height:100%; }}
.stat .l {{ color:{MUTED}; font-size:.82rem; }}
.stat .v {{ font-size:1.35rem; font-weight:700; color:var(--c); margin-top:2px; }}
.stat .s {{ color:{MUTED}; font-size:.8rem; margin-top:2px; }}
.sec {{ font-size:1.05rem; font-weight:700; margin:22px 0 10px; }}
.bar {{ height:7px; border-radius:4px; background:{GRID}; overflow:hidden; margin-top:6px; }}
.bar > div {{ height:100%; background:var(--c); }}
table.t {{ border-collapse:collapse; width:100%; font-size:.88rem; }}
table.t th {{ text-align:left; color:{MUTED}; font-weight:600; padding:8px 10px; border-bottom:1px solid {BORDER}; position:sticky; top:0; background:{PANEL}; }}
table.t td {{ padding:7px 10px; border-bottom:1px solid {GRID}; }}
table.t tr.hl td {{ background:{RAISED}; font-weight:700; }}
.wrap {{ max-height:460px; overflow:auto; border:1px solid {BORDER}; border-radius:10px; background:{PANEL}; }}
@media (max-width: 800px) {{ .verdict .act {{ font-size:1.9rem; }} .block-container {{ padding:1rem .6rem; }} }}
</style>""", unsafe_allow_html=True)


# ------------------------------------------------------------------ helpers
def chip(text, color, fill=False):
    return f'<span class="chip{" fill" if fill else ""}" style="--c:{color}">{esc(str(text))}</span>'


def stat(label, value, sub="", color=None):
    return (f'<div class="stat" style="--c:{color or TEXT}"><div class="l">{esc(str(label))}</div>'
            f'<div class="v num">{esc(str(value))}</div><div class="s">{esc(str(sub))}</div></div>')


def section(t):
    st.markdown(f'<div class="sec">{esc(t)}</div>', unsafe_allow_html=True)


def kv(k, v, color=None):
    c = f' style="color:{color}"' if color else ""
    return f'<div class="row"><span class="k">{esc(str(k))}</span><span class="num"{c}>{esc(str(v))}</span></div>'


def pts(items):
    return "".join(f'<div class="pt" style="--c:{c}"><i></i><span>{esc(t)}</span></div>' for t, c in items)


def n0(v):
    return f"{v:,.0f}" if v else "N/A"


def pchart(fig, key):
    try:
        st.plotly_chart(fig, width="stretch", key=key)
    except TypeError:
        st.plotly_chart(fig, use_container_width=True, key=key)


def style_fig(fig, h=320):
    fig.update_layout(height=h, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(color=TEXT, family="Manrope"),
                      margin=dict(l=10, r=10, t=36, b=10), legend=dict(orientation="h", y=1.12))
    fig.update_xaxes(gridcolor=GRID)
    fig.update_yaxes(gridcolor=GRID)
    return fig


def ts(t_):
    return int(pd.Timestamp(t_).timestamp())            # index is IST wall-clock; show as-is


@st.cache_resource
def start_background_agent(data_dir):
    """One agent loop per dashboard process. Respects the 'Run the agent inside the dashboard' setting."""
    def loop():
        while True:
            try:
                s = fa.load_settings(data_dir)
                if s.get("bg_agent", True):
                    fa.run_all(data_dir=data_dir)
                time.sleep(max(int(s.get("agent_interval", 60)), 20))
            except Exception:
                traceback.print_exc()
                time.sleep(30)
    t = threading.Thread(target=loop, daemon=True, name="ai-agent")
    t.start()
    return t


start_background_agent(DATA)

# ------------------------------------------------------------------ instrument + files
INSTRUMENTS = {"NIFTY": "NIFTY 50", "SENSEX": "SENSEX"}
LOTS = {"NIFTY": 65, "SENSEX": 20}                      # verify with the exchange and edit here if it changes
with top_l:
    st.markdown('<div class="brand">AI Option Desk<small>Reads the market, decides, explains</small></div>', unsafe_allow_html=True)
with top_m:
    INST = st.radio("Instrument", list(INSTRUMENTS), horizontal=True, key="inst", label_visibility="collapsed")
INAME = INSTRUMENTS[INST]
P = fa.get_paths(DATA, INST)

if force:
    with st.spinner("Running the agent..."):
        for _ in range(45):                         # the background agent may be mid-run: wait for it to finish
            if not os.path.exists(P["lock"]):
                break
            time.sleep(1)
        run_res = fa.safe_run(INST, data_dir=DATA)
    if manual_run:
        if run_res is not None:
            st.toast(f"Agent finished at {datetime.now(IST):%H:%M:%S}. If the market is closed, prices stay the same.")
        elif os.path.exists(P["lock"]):
            st.warning("Another agent run is still in progress. Wait a few seconds and press again.")
        else:
            st.error("Agent run failed: " + str((fa.read_json(P["signals"], {}) or {}).get("agent_error") or "see the terminal for the error"))
if not (os.path.exists(P["signals"]) and os.path.exists(P["market"])):
    with st.spinner(f"First run for {INAME}: downloading data and training the model (about 20 seconds)..."):
        for _ in range(60):                         # the background agent may already be building these files: wait, do not collide
            if not os.path.exists(P["lock"]):
                break
            time.sleep(1)
        if not (os.path.exists(P["signals"]) and os.path.exists(P["market"])):
            fa.safe_run(INST, data_dir=DATA)
if not (os.path.exists(P["signals"]) and os.path.exists(P["market"])):
    _err = (fa.read_json(P["signals"], {}) or {}).get("agent_error")
    st.error(f"No data for {INAME} yet." + (f" Last agent error: {_err}" if _err else " Check your internet connection.")
             + " Run `python diagnose.py` in the project folder to see exactly what is failing, "
               "or create offline demo data with `python final_agent.py --demo` and start the dashboard with NIFTY_DATA_DIR=demo_data.")
    st.stop()

J = fa.read_json(P["signals"], {})
if J.get("schema") != 4 and J.get("agent_error"):
    st.error(f"The agent failed for {INAME}: {J['agent_error']}. Run `python diagnose.py` for details.")
    st.stop()
if J.get("schema") != 4:
    st.error("signals.json is from an older version. Delete the nifty/ and sensex/ folders (or run the new final_agent.py once) and refresh.")
    st.stop()
data = pd.read_csv(P["market"], index_col=0, parse_dates=True)
chain_data = fa.read_json(P["chain"], None) if os.path.exists(P["chain"]) else None
hist = fa.read_json(P["history"], [])

dec, reg, mdl, ctx = J["decision"], J["regime"], J["model"], J["context"]
plan, news, ch = J["plan"], J["news"], J.get("chain") or {}
sess, vix, gift, tech = J.get("session") or {}, J.get("vix"), J.get("gift"), J.get("tech") or {}
spot, action, lean = J["spot_price"], dec["action"], dec["lean"]
act_color = UP if action == "BUY CALL" else DOWN if action == "BUY PUT" else WARN
tone_color = {"bull": UP, "bear": DOWN, "warn": WARN}.get(reg["tone"], INFO)
now_dt = datetime.now(IST)
market_open = now_dt.weekday() < 5 and (9, 15) <= (now_dt.hour, now_dt.minute) <= (15, 30)
run_age = (now_dt.timestamp() - J["run_ts"]) / 60 if J.get("run_ts") else None

if J.get("agent_error"):
    st.error(f"Agent error at {J.get('error_ts', '')}: {J['agent_error']}. Showing the last good data.")
if J.get("chain_error"):
    st.warning(f"Option chain: {J['chain_error']}. The AI is running without chain data (confidence capped).")
if market_open and run_age is not None and run_age > 5:
    st.warning(f"The agent has not updated for {run_age:.0f} minutes. Check your internet, or press Run agent now.")

chips = [chip("Market open" if market_open else "Market closed", UP if market_open else WARN, True),
         chip(f"Regime: {reg['label']}", tone_color, True), chip(f"Volatility {reg['vol_state'].lower()}", INFO),
         chip(f"Session: {reg['phase']}", MUTED)]
if vix:
    chips.append(chip(f"India VIX {vix['last']:.1f} ({vix['change_pct']:+.1f}%)", DOWN if vix["change_pct"] > 3 else MUTED))
if J.get("candle_age_min") is not None and market_open:
    chips.append(chip(f"Price data {J['candle_age_min']:.0f} min old", UP if J["candle_age_min"] <= 8 else WARN))
chips.append(chip("Claude review on" if (J.get("llm") or {}).get("ok") else "Built-in news AI", INFO))
st.markdown("".join(chips), unsafe_allow_html=True)

# ------------------------------------------------------------------ main row: chart | verdict
col_chart, col_dec = st.columns([2.2, 1])

with col_dec:
    pos = 50 + max(-1, min(1, (dec["ev_long"] - dec["ev_short"]) / 0.3)) * 50
    reasons_html = pts([(r["text"], UP if r["kind"] == "good" else DOWN if r["kind"] == "bad" else MUTED) for r in dec["reasons"][:6]]) \
        or '<div class="muted txt">No strong drivers right now.</div>'
    block_html = pts([(b, WARN) for b in dec["blockers"]])
    st.markdown(
        f'<div class="card verdict" style="--c:{act_color}"><div class="muted" style="font-size:.85rem">AI decision for {esc(INAME)}</div>'
        f'<div class="act">{esc(action)}</div>'
        f'<div class="sub"><span class="num">Confidence {dec["confidence"]}%</span> &nbsp; Grade {dec["grade"]} &nbsp; '
        f'<span class="num">Edge {dec["ev"]:+.2f}R</span></div>'
        f'<div class="meter"><div class="dot" style="left:{pos:.0f}%"></div></div>'
        f'<div class="meter-l"><span>PUT favoured</span><span>Lean: {lean}</span><span>CALL favoured</span></div>'
        f'<div class="txt">{esc(dec["summary"])}</div>'
        f'<div style="margin-top:10px">{block_html}{reasons_html}</div></div>', unsafe_allow_html=True)

    if action != "WAIT":
        o = plan.get("option")
        rows = (kv("Entry (index)", f"{plan['entry']:,.1f}") + kv("Stop", f"{plan['stoploss']:,.1f}  ({plan['sl_pts']:.0f} pts)", DOWN)
                + kv("Target 1", f"{plan['target1']:,.1f}  ({plan['t1_pts']:.0f} pts)", UP) + kv("Target 2", f"{plan['target2']:,.1f}  ({plan['t2_pts']:.0f} pts)", UP))
        if o:
            rows += kv(f"ATM {o['type']} {o['strike']:,.0f}", f"Rs {o['premium']:,.1f}") + kv("Premium stop / T1 (approx)", f"{o['sl_prem']:,.1f} / {o['t1_prem']:,.1f}")
        if o and o.get("gamma") is not None:
            rows += (kv("Delta / Gamma", f"{o['delta']:.2f} / {o['gamma']:.5f}")
                     + kv("Theta per day / Vega per 1% IV", f"{o['theta']:,.1f} / {o['vega']:,.1f} (premium pts)"))
        rows += kv("Max hold", f"{plan['max_bars']} candles (1 hour)") + kv("Position size", f"x{dec['size_factor']} of normal")
        st.markdown(f'<div class="card"><div class="muted" style="font-size:.85rem;margin-bottom:4px">Trade plan</div>{rows}'
                    f'<div class="muted" style="font-size:.8rem;margin-top:8px">Book half at Target 1, move the stop to entry, exit by the time limit.</div></div>',
                    unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="card"><div class="muted" style="font-size:.85rem">If a setup appears</div>'
                    f'<div class="txt" style="margin-top:6px">Likely side: <b>{lean}</b>. Expected edge now {dec["ev"]:+.2f}R; '
                    f'a trade needs {dec["thresholds"]["ev_min"]:+.2f}R or more. Stop would be {plan["sl_pts"]:.0f} pts, target {plan["t1_pts"]:.0f} pts.</div></div>',
                    unsafe_allow_html=True)
        if not dec["blockers"]:
            st.caption("The model sees no big enough edge right now, so it waits. Sensitivity 'Active' (Settings) allows weaker setups; "
                       "`python backtest.py` shows how often and how well it would have traded.")

with col_chart:
    chart_mode, opt_type, opt_strike, prem_src = INAME, "CE", None, "Auto"
    sel_exp, sel = None, {}
    if chain_data and chain_data.get("expiries"):
        exps = chain_data["expiries"][:10]
        c1, c2, c3, c4 = st.columns([1.3, 1.1, 0.8, 1.1])
        chart_mode = c1.radio("Chart", [INAME, "Option contract"], horizontal=True, key=f"cm_{INST}", label_visibility="collapsed")
        if chart_mode == "Option contract":
            di = exps.index(chain_data.get("nearest")) if chain_data.get("nearest") in exps else 0
            sel_exp = c2.selectbox("Expiry", exps, index=di, key=f"ex_{INST}", label_visibility="collapsed")
            sel = chain_data["stats"][sel_exp]
            opt_type = c3.radio("Type", ["CE", "PE"], horizontal=True, key=f"ot_{INST}", label_visibility="collapsed")
            rows_k = pd.DataFrame(chain_data["chain"][sel_exp]).sort_values("strike").reset_index(drop=True)
            ai_ = int((rows_k["strike"] - sel["atm"]).abs().idxmin())
            view_k = [float(x) for x in rows_k["strike"].iloc[max(ai_ - 12, 0): ai_ + 13]]
            opt_strike = c4.selectbox("Strike", view_k, index=view_k.index(float(rows_k["strike"].iloc[ai_])), key=f"os_{INST}",
                                      format_func=lambda x: f"{x:,.0f}", label_visibility="collapsed")

    candles = [dict(time=ts(i), open=float(o), high=float(h), low=float(l), close=float(c))
               for i, o, h, l, c in zip(data.index, data["Open"], data["High"], data["Low"], data["Close"]) if pd.notna(c)]
    lines = []
    if show_ema:
        mk = lambda col, name, color, dashed=False: dict(name=name, color=color, dashed=dashed, width=1,
                                                         data=[dict(time=ts(i), value=float(v)) for i, v in data[col].items() if pd.notna(v)])
        lines = [mk("ema20", "EMA 20", WARN), mk("ema50", "EMA 50", INFO), mk("sess_mean", "Session average", MUTED, True)]
    markers, levels, vol_data, note = [], [], [], ""
    c_times = sorted({c["time"] for c in candles})
    if show_marks:
        for h_ in hist:
            try:
                t_ = ts(datetime.strptime(h_.get("candle_time") or h_["time"], "%d-%m-%Y %H:%M:%S"))
            except Exception:
                continue
            k_ = bisect.bisect_right(c_times, t_) - 1       # snap to a candle that exists on the chart
            if k_ < 0:
                continue
            t_ = c_times[k_]
            is_call = h_["signal"] == "BUY CALL"
            st_ = h_.get("status", "PENDING")
            col = UP if st_ == "WIN" else DOWN if st_ == "LOSS" else INFO
            tag = {"WIN": f" +{h_.get('r', 0):.1f}R", "LOSS": " -1R", "TIMEOUT": f" {h_.get('r', 0):+.1f}R"}.get(st_, "")
            markers.append(dict(time=t_, position="belowBar" if is_call else "aboveBar", color=col,
                                shape="arrowUp" if is_call else "arrowDown", size=2, text=("CALL" if is_call else "PUT") + tag))
        if action != "WAIT" and c_times and not any(m["time"] == c_times[-1] for m in markers):
            now_call = action == "BUY CALL"
            markers.append(dict(time=c_times[-1], position="belowBar" if now_call else "aboveBar", color=UP if now_call else DOWN,
                                shape="arrowUp" if now_call else "arrowDown", size=2, text="CALL now" if now_call else "PUT now"))
        markers.sort(key=lambda m: m["time"])
        if not markers:
            note = ("No BUY/SELL arrows yet. An arrow is drawn when the AI gives BUY CALL (green, up) or BUY PUT (red, down) "
                    "during market hours, and the journal keeps it on the chart afterwards.")
    if show_levels:
        if action != "WAIT":
            levels += [dict(price=plan["stoploss"], title="Stop", color=DOWN), dict(price=plan["target1"], title="Target 1", color=UP),
                       dict(price=plan["target2"], title="Target 2", color=UP)]
        for v_, n_, c_ in ((reg.get("pdh"), "Prev day high", MUTED), (reg.get("pdl"), "Prev day low", MUTED),
                           (ch.get("support"), "OI support", UP), (ch.get("resistance"), "OI resistance", DOWN)):
            if v_:
                levels.append(dict(price=float(v_), title=n_, color=c_))
    title = f"{INAME}  |  5-minute"
    if chart_mode == "Option contract" and opt_strike is not None:
        p_ = "ce" if opt_type == "CE" else "pe"
        rowk = rows_k[rows_k["strike"] == float(opt_strike)].iloc[0]
        title = f"{INAME} {opt_strike:,.0f} {opt_type}  |  {sel_exp}"
        try:
            tk = pd.read_csv(P["ticks"], parse_dates=["ts"])
            tk = tk[(tk["expiry"] == sel_exp) & (tk["strike"] == float(opt_strike)) & (tk["type"] == opt_type) & (tk["ltp"] > 0)]
        except Exception:
            tk = pd.DataFrame()
        o_ = pd.DataFrame()
        if len(tk) >= 3:
            s_ = tk.set_index("ts")
            o_ = s_["ltp"].resample("5min").ohlc().dropna()
        if len(o_) >= 3:
            v_ = s_["vol"].resample("5min").last().ffill().diff().clip(lower=0).reindex(o_.index).fillna(0)
            candles = [dict(time=ts(i), open=float(r.open), high=float(r.high), low=float(r.low), close=float(r.close)) for i, r in o_.iterrows()]
            vol_data = [dict(time=ts(i), value=float(v), color=UP if r.close >= r.open else DOWN) for (i, r), v in zip(o_.iterrows(), v_)]
            lines, markers, levels = [], [], []
            note = f"Real traded premium: {len(o_)} candles recorded by the agent."
        else:
            note = (f"Premium history for this contract is still building ({len(o_)}/3 candles). It fills while the agent runs in market hours. "
                    f"Showing the index chart meanwhile. Last premium Rs {rowk[p_ + '_ltp']:,.2f}, OI {n0(rowk[p_ + '_oi'])}, IV {rowk[p_ + '_iv']:.1f}%.")
    components.html(chart_html(candles, lines, markers, levels, vol_data, title, chart_h, 13 if font_px < 18 else 14, chart_bars,
                               dict(UP=UP, DOWN=DOWN, BG=BG, MUTED=MUTED, GRID=GRID, BORDER=BORDER)), height=chart_h + 6)
    if note:
        st.markdown(f'<div class="muted" style="font-size:.85rem">{esc(note)}</div>', unsafe_allow_html=True)

# ------------------------------------------------------------------ market read
section("Market read")
arrow = lambda a: ("▲ up", UP) if a == "up" else ("▼ down", DOWN) if a == "down" else ("■ flat", MUTED)
a5, a15, a60 = arrow(reg["arrows"]["m5"]), arrow(reg["arrows"]["m15"]), arrow(reg["arrows"]["m60"])
m1, m2, m3, m4, m5_ = st.columns(5)
m1.markdown(stat("Regime", reg["label"], f"Efficiency {reg['er']:.2f}, ADX {reg['adx']:.0f}", tone_color), unsafe_allow_html=True)
m2.markdown(stat("Trend by timeframe", f"{a5[0][0]} {a15[0][0]} {a60[0][0]}", "5m  15m  60m", UP if reg["agree"] >= 2.5 else DOWN if reg["agree"] <= -2.5 else WARN), unsafe_allow_html=True)
m3.markdown(stat("Volatility", f"{reg['atr_ratio']:.2f}x normal", f"ATR {reg['atr']:.1f} pts, {reg['vol_state'].lower()}", WARN if reg["vol_state"] != "Normal" else TEXT), unsafe_allow_html=True)
ru = reg.get("range_used")
m4.markdown(stat("Day range used", f"{ru * 100:.0f}%" if ru is not None else "N/A", "of recent average day" + (f", {reg['exp_used']:.1f}x implied move" if reg.get("exp_used") else ""), WARN if (ru or 0) >= 1.1 else TEXT), unsafe_allow_html=True)
orb = reg.get("orb")
m5_.markdown(stat("Opening range", (orb["state"].title() if orb else "N/A"), f"{orb['low']:,.0f} to {orb['high']:,.0f}" if orb else "", UP if orb and orb["state"] == "above" else DOWN if orb and orb["state"] == "below" else TEXT), unsafe_allow_html=True)
st.markdown(f'<div class="card" style="margin-top:10px"><div class="txt">{esc(reg["read"])}</div></div>', unsafe_allow_html=True)

# ------------------------------------------------------------------ tabs
tab_why, tab_news, tab_chain, tab_journal, tab_size, tab_sys = st.tabs(
    ["Why this call", "News and events", "Option chain", "Journal", "Position size", "System"])

with tab_why:
    w1, w2 = st.columns([1.15, 1])
    with w1:
        section("What the learning model is looking at")
        tf = mdl.get("top_features") or []
        if tf:
            tf = tf[:10][::-1]
            fig = go.Figure(go.Bar(x=[x["value"] for x in tf], y=[x["name"] for x in tf], orientation="h",
                                   marker_color=[UP if x["value"] > 0 else DOWN for x in tf]))
            fig.update_layout(title=dict(text=f"Contribution to the {lean} edge (right = supports {lean})", font=dict(size=14)))
            pchart(style_fig(fig, 360), f"feat_{INST}")
        else:
            st.info("The model is not ready yet (it needs about 300 labelled candles).")
    with w2:
        section("Can the model be trusted right now?")
        rel = mdl.get("rel", 0)
        rel_c = UP if rel >= 0.6 else WARN if rel >= 0.25 else DOWN
        rows = (kv("Trained on", f"{mdl.get('n_train', 0):,} past candles") + kv("Tested on unseen", f"{mdl.get('n_test', 0):,} candles")
                + kv("Predictive power (unseen)", f"{mdl.get('ic', 0):+.3f}", rel_c)
                + kv("Top-fifth setups, avg result", f"{mdl['top_mean_r']:+.2f}R ({mdl['top_n']} cases)" if mdl.get("top_mean_r") is not None else "N/A"))
        st.markdown(f'<div class="card"><div class="row"><span class="k">Model reliability</span><span class="num" style="color:{rel_c}">{int(rel * 100)}%</span></div>'
                    f'<div class="bar" style="--c:{rel_c}"><div style="width:{int(rel * 100)}%"></div></div>{rows}'
                    f'<div class="muted" style="font-size:.82rem;margin-top:8px">{esc(mdl.get("note") or "Reliability is measured on candles the model never saw. Low reliability means its vote is down-weighted automatically.")}</div></div>',
                    unsafe_allow_html=True)
        section("Outside context (chain, news, GIFT)")
        if ctx["parts"]:
            body = "".join(f'<tr><td>{esc(p["name"])}<div class="muted" style="font-size:.8rem">{esc(p["detail"])}</div></td>'
                           f'<td class="num" style="color:{UP if p["value"] > 0 else DOWN if p["value"] < 0 else MUTED}">{p["value"]:+.2f}</td></tr>' for p in ctx["parts"])
            st.markdown(f'<div class="wrap"><table class="t"><tr><th>Input</th><th>Lean (+ bullish)</th></tr>{body}</table></div>'
                        f'<div class="muted" style="font-size:.82rem;margin-top:6px">Net tilt {ctx["tilt"]:+.2f}. It can move the edge by at most {ai.TILT_R:.2f}R.</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="muted txt">No outside context available (no option chain, GIFT or news).</div>', unsafe_allow_html=True)
    for n_ in dec.get("notes", []):
        st.markdown(f'<div class="muted txt">{esc(n_)}</div>', unsafe_allow_html=True)

with tab_news:
    risk_c = {"HIGH": DOWN, "MEDIUM": WARN, "LOW": UP}.get(news["event_risk"], MUTED)
    tone_c = UP if news["tone"] == "POSITIVE" else DOWN if news["tone"] == "NEGATIVE" else WARN
    st.markdown(chip(f"Tone: {news['tone'].title()} ({news['score']:+.2f})", tone_c, True) + chip(f"Event risk: {news['event_risk'].title()}", risk_c, True)
                + chip(f"{news['count']} headlines", MUTED) + chip(f"Engine: {news['engine']}", INFO), unsafe_allow_html=True)
    if news.get("events"):
        st.markdown("".join(chip(f"{e['name']} x{e['count']}", WARN if e["high"] else MUTED) for e in news["events"]), unsafe_allow_html=True)
    llm = J.get("llm") or {}
    if llm.get("ok"):
        st.markdown(f'<div class="card"><div class="muted" style="font-size:.85rem">Claude review ({esc(llm.get("model", ""))})</div>'
                    f'<div class="txt" style="margin-top:4px">{esc(llm.get("summary", ""))}</div>'
                    f'<div class="muted" style="margin-top:6px;font-size:.88rem">Bias {esc(llm["market_bias"])}, event risk {esc(llm["event_risk"])}'
                    f'{", VETO: " + esc(llm["veto_reason"]) if llm.get("veto") else ""}</div></div>', unsafe_allow_html=True)
    elif os.environ.get("ANTHROPIC_API_KEY"):
        st.markdown(f'<div class="muted txt">Claude review is on but returned nothing: {esc(str(llm.get("reason", "waiting for first run")))}</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="muted txt">Using the built-in news analyser. Set ANTHROPIC_API_KEY to add a Claude review that can read context and veto risky trades.</div>', unsafe_allow_html=True)
    if news.get("items"):
        body = "".join(f'<tr><td>{esc(i["title"])}<div class="muted" style="font-size:.78rem">{esc(i.get("source", ""))}'
                       f'{" | " + str(i["age_h"]) + "h ago" if i.get("age_h") is not None else ""}</div></td>'
                       f'<td class="num" style="color:{UP if i["score"] > 0 else DOWN if i["score"] < 0 else MUTED}">{i["score"]:+.2f}</td></tr>' for i in news["items"])
        st.markdown(f'<div class="wrap" style="margin-top:10px"><table class="t"><tr><th>Headline</th><th>Tone</th></tr>{body}</table></div>', unsafe_allow_html=True)
    else:
        st.info("No headlines received yet. The agent fetches Google News every 15 minutes.")

with tab_chain:
    if not ch or not chain_data:
        st.info(f"{INAME} has no option chain source here (NSE chain is available for NIFTY only). The AI uses price data, news and GIFT/VIX.")
    else:
        exps = chain_data["expiries"][:10]
        di = exps.index(chain_data.get("nearest")) if chain_data.get("nearest") in exps else 0
        view_exp = st.selectbox("Expiry", exps, index=di, key=f"cx_{INST}")
        s = chain_data["stats"][view_exp]
        pcr_c = UP if s["pcr_near"] > 1.1 else DOWN if s["pcr_near"] < 0.9 else WARN
        cols = st.columns(6)
        cells = [("Days to expiry", s["dte"], view_exp, INFO), ("PCR near / full", f"{s['pcr_near']:.2f} / {s['pcr_full']:.2f}", s["buildup"].title(), pcr_c),
                 ("Max pain", n0(s["max_pain"]), f"{chain_data['spot'] - s['max_pain']:+,.0f} pts from spot", WARN),
                 ("ATM straddle", f"{s['straddle']:,.1f}", f"Strike {n0(s['atm'])}", TEXT),
                 ("Support / resistance", f"{n0(s['support'])} / {n0(s['resistance'])}", "Highest put / call OI", TEXT),
                 ("ATM IV", f"{s['ce_iv']:.1f} / {s['pe_iv']:.1f}" if (s["ce_iv"] or s["pe_iv"]) else "N/A", "0 when market is closed", INFO)]
        for col, (l_, v_, s_, c_) in zip(cols, cells):
            col.markdown(stat(l_, v_, s_, c_), unsafe_allow_html=True)
        fl = J.get("flow")
        if fl and fl.get("ok"):
            iv_c = DOWN if fl["iv_state"] == "Falling" else UP if fl["iv_state"] == "Rising" else MUTED
            g1, g2, g3, g4 = st.columns(4)
            g1.markdown(stat(f"OI velocity ({fl['window_min']:.0f} min)", f"{fl['oi_vel_pct']:+.2f}%", "puts minus calls, % of OI", UP if fl["oi_vel_pct"] > 0 else DOWN), unsafe_allow_html=True)
            g2.markdown(stat("ATM call / put premium", f"{fl['ce_prem_pct']:+.1f}% / {fl['pe_prem_pct']:+.1f}%", "change in window", TEXT), unsafe_allow_html=True)
            g3.markdown(stat("IV velocity", f"{fl['iv_vel']:+.2f} pts", f"per 15 min, {fl['iv_state'].lower()}", iv_c), unsafe_allow_html=True)
            g4.markdown(stat("Flow snapshots", fl["snapshots"], "recorded by the agent", MUTED), unsafe_allow_html=True)
        elif fl:
            st.markdown(f'<div class="muted txt" style="margin-top:8px">Option flow: {esc(fl.get("reason", ""))}</div>', unsafe_allow_html=True)
        full = pd.DataFrame(chain_data["chain"][view_exp]).sort_values("strike").reset_index(drop=True)
        atm_i = int((full["strike"] - s["atm"]).abs().idxmin())
        span = st.slider("Strikes around ATM", 5, 40, 14, key=f"sp_{INST}")
        v = full.iloc[max(atm_i - span, 0): atm_i + span + 1]
        f1, f2 = st.columns(2)

        def oi_fig(a, b, title):
            fig = go.Figure()
            fig.add_trace(go.Bar(x=v["strike"], y=v[a[0]], name=a[1], marker_color=DOWN))
            fig.add_trace(go.Bar(x=v["strike"], y=v[b[0]], name=b[1], marker_color=UP))
            fig.add_vline(x=chain_data["spot"], line=dict(color=INFO, width=1, dash="dot"))
            fig.update_layout(barmode="group", title=dict(text=title, font=dict(size=14)))
            return style_fig(fig, 320)

        with f1:
            pchart(oi_fig(("ce_oi", "Call OI"), ("pe_oi", "Put OI"), "Open interest"), f"oi1_{INST}")
        with f2:
            pchart(oi_fig(("ce_chg_oi", "Call OI change"), ("pe_chg_oi", "Put OI change"), "Change in open interest"), f"oi2_{INST}")
        body = "".join(
            f'<tr{" class=hl" if r["strike"] == s["atm"] else ""}><td class="num">{r["ce_oi"]:,.0f}</td><td class="num">{r["ce_chg_oi"]:+,.0f}</td>'
            f'<td class="num">{r["ce_ltp"]:,.2f}</td><td class="num"><b>{r["strike"]:,.0f}</b></td><td class="num">{r["pe_ltp"]:,.2f}</td>'
            f'<td class="num">{r["pe_chg_oi"]:+,.0f}</td><td class="num">{r["pe_oi"]:,.0f}</td></tr>' for _, r in v.iterrows())
        st.markdown(f'<div class="wrap"><table class="t"><tr><th>Call OI</th><th>OI chg</th><th>Call premium</th><th>Strike</th><th>Put premium</th><th>OI chg</th><th>Put OI</th></tr>{body}</table></div>', unsafe_allow_html=True)

with tab_journal:
    stt = ai.journal_stats(hist)
    j1, j2, j3, j4, j5 = st.columns(5)
    j1.markdown(stat("Closed signals", stt["n"], f"{stt['pending']} still open", INFO), unsafe_allow_html=True)
    j2.markdown(stat("Win rate", f"{stt['win_rate']:.0f}%" if stt["win_rate"] is not None else "N/A", f"{stt['target_hits']} targets, {stt['stops']} stops", UP if (stt["win_rate"] or 0) >= 45 else WARN), unsafe_allow_html=True)
    j3.markdown(stat("Average result", f"{stt['avg_r']:+.2f}R" if stt["avg_r"] is not None else "N/A", "per signal, before costs", UP if (stt["avg_r"] or 0) > 0 else DOWN), unsafe_allow_html=True)
    j4.markdown(stat("Total", f"{stt['total_r']:+.1f}R", "sum of all closed signals", UP if stt["total_r"] > 0 else DOWN), unsafe_allow_html=True)
    j5.markdown(stat("Break-even win rate", "40%", "for stop 1R / target 1.5R, before costs", MUTED), unsafe_allow_html=True)
    pc1, pc2, pc3 = st.columns(3)
    paper_cap = pc1.number_input("Paper capital (Rs)", min_value=1000, value=100000, step=5000, key=f"pcap_{INST}")
    paper_risk = pc2.selectbox("Risk per trade (%)", [0.5, 1.0, 1.5, 2.0], index=1, key=f"prisk_{INST}")
    paper_pnl = stt["total_r"] * paper_cap * paper_risk / 100
    pc3.markdown(stat("Paper P&L", f"Rs {paper_pnl:+,.0f}", f"{paper_pnl / paper_cap * 100:+.2f}% of capital (R x risk)", UP if paper_pnl >= 0 else DOWN), unsafe_allow_html=True)
    try:
        import costs as costmod
        c_rows, c_eq, c_skip = costmod.replay(hist, lot_size=int(LOTS[INST]), lots=1, slippage_ticks=2)
    except Exception:
        c_rows, c_eq, c_skip = [], [], 0
    if c_rows:
        cs = costmod.summary(c_rows)
        k1, k2, k3, k4 = st.columns(4)
        k1.markdown(stat("Net P&L, 1 lot", f"Rs {cs['net']:+,.0f}", f"{cs['n']} trades, after costs and 2-tick slippage", UP if cs["net"] >= 0 else DOWN), unsafe_allow_html=True)
        k2.markdown(stat("Costs paid", f"Rs {cs['costs']:,.0f}", "brokerage, STT 0.15%, fees, GST, stamp", DOWN), unsafe_allow_html=True)
        k3.markdown(stat("Avg R: gross to net", f"{cs['avg_r_gross']:+.2f} to {cs['avg_r_net']:+.2f}", "costs shrink the edge", UP if cs["avg_r_net"] > 0 else DOWN), unsafe_allow_html=True)
        st_rows = "".join(f'<tr><td>x{x["mult"]:.1f}</td><td class="num" style="color:{UP if x["total"] >= 0 else DOWN}">Rs {x["total"]:+,.0f}</td></tr>' for x in costmod.stress(c_rows))
        k4.markdown(f'<div class="stat"><div class="l">If real costs are higher</div><table class="t">{st_rows}</table></div>', unsafe_allow_html=True)
        if c_skip:
            st.caption(f"{c_skip} older closed signals have no stored option premium and are left out of the net figures.")
    try:
        import database as tradedb
        reg_rows = tradedb.by_regime(P["dir"])
    except Exception:
        reg_rows = []
    if reg_rows:
        body = "".join(f'<tr><td>{esc(r["regime"])}</td><td class="num">{r["n"]}</td><td class="num">{r["win_rate"]:.0f}%</td>'
                       f'<td class="num" style="color:{UP if r["avg_r"] > 0 else DOWN}">{r["avg_r"]:+.2f}R</td></tr>' for r in reg_rows)
        st.markdown(f'<div class="wrap" style="max-height:220px;margin-top:10px"><table class="t"><tr><th>Market regime</th><th>Closed</th><th>Win rate</th><th>Avg result</th></tr>{body}</table></div>', unsafe_allow_html=True)
    if stt["equity"]:
        fig = go.Figure(go.Scatter(y=stt["equity"], mode="lines+markers", line=dict(color=UP if stt["total_r"] >= 0 else DOWN, width=2)))
        fig.update_layout(title=dict(text="Cumulative result (R)", font=dict(size=14)))
        pchart(style_fig(fig, 280), f"eq_{INST}")
    if hist:
        body = "".join(
            f'<tr><td>{esc(h_["time"])}</td><td style="color:{UP if h_["signal"] == "BUY CALL" else DOWN}">{esc(h_["signal"])}</td>'
            f'<td class="num">{h_.get("entry", h_.get("price", 0)):,.1f}</td><td class="num">{h_.get("confidence", "")}</td>'
            f'<td>{esc(h_.get("regime", ""))}</td><td>{esc(h_.get("status", "PENDING").title())}</td>'
            f'<td class="num">{h_["r"]:+.2f}R</td></tr>' if "r" in h_ else
            f'<tr><td>{esc(h_["time"])}</td><td style="color:{UP if h_["signal"] == "BUY CALL" else DOWN}">{esc(h_["signal"])}</td>'
            f'<td class="num">{h_.get("entry", h_.get("price", 0)):,.1f}</td><td class="num">{h_.get("confidence", "")}</td>'
            f'<td>{esc(h_.get("regime", ""))}</td><td>{esc(h_.get("status", "PENDING").title())}</td><td>-</td></tr>'
            for h_ in reversed(hist[-30:]))
        st.markdown(f'<div class="wrap"><table class="t"><tr><th>Time</th><th>Signal</th><th>Entry</th><th>Confidence</th><th>Regime</th><th>Status</th><th>Result</th></tr>{body}</table></div>', unsafe_allow_html=True)
        d1, d2 = st.columns(2)
        d1.download_button("Download journal", json.dumps(hist, indent=2), file_name=f"{INST.lower()}_journal.json")
        d2.download_button("Download candles with indicators", data.to_csv(), file_name=f"{INST.lower()}_market_data.csv")
    else:
        st.info("No signals yet. Every signal the AI gives is recorded here and judged automatically against the candles that follow. "
                "Trust the AI only after this table shows a positive total over a few weeks.")

with tab_size:
    s1, s2 = st.columns([1, 1])
    with s1:
        o = plan.get("option") or {}
        side_ = plan["side"]
        default_prem = float(o.get("premium") or (ch.get("ce_ltp") if side_ == "CALL" else ch.get("pe_ltp")) or 100.0)
        capital = st.number_input("Capital (Rs)", min_value=1000, value=100000, step=5000)
        lot = st.number_input("Lot size (verify with exchange)", min_value=1, value=LOTS[INST], step=1)
        prem = st.number_input(f"{side_} premium (Rs)", min_value=0.5, value=round(default_prem, 2), step=1.0)
        risk_pct = st.selectbox("Max loss per trade (% of capital)", [0.5, 1.0, 1.5, 2.0], index=1)
    with s2:
        sl_prem = float(o.get("sl_prem") or max(prem - 0.5 * plan["sl_pts"], prem * 0.15))
        loss_lot = max(prem - sl_prem, 0.01) * lot
        by_risk = int((capital * risk_pct / 100) // loss_lot)
        by_cap = int(capital // (prem * lot))
        lots = int(min(by_risk, by_cap) * dec["size_factor"]) if action != "WAIT" else min(by_risk, by_cap)
        qty = lots * lot
        r1, r2 = st.columns(2)
        r1.markdown(stat("Lots", lots, f"1 lot costs Rs {prem * lot:,.0f}", INFO), unsafe_allow_html=True)
        r2.markdown(stat("Quantity", f"{qty:,}", f"{lots} x {lot}", UP), unsafe_allow_html=True)
        r3, r4 = st.columns(2)
        r3.markdown(stat("Capital used", f"Rs {qty * prem:,.0f}", f"{qty * prem / capital * 100:.1f}% of capital", TEXT), unsafe_allow_html=True)
        r4.markdown(stat("Loss if stopped", f"Rs {lots * loss_lot:,.0f}", f"{lots * loss_lot / capital * 100:.2f}% of capital", DOWN), unsafe_allow_html=True)
        st.markdown(f'<div class="muted" style="font-size:.85rem;margin-top:8px">Lots are limited by your risk %, by capital, and by the AI size factor (x{dec["size_factor"]}). '
                    f'Premium stop is approximate (delta based). Use your broker\'s live premium before ordering.</div>', unsafe_allow_html=True)
        if lots == 0:
            st.warning("Not even one lot fits this risk limit. Raise the risk % or capital, or skip the trade.")

with tab_sys:
    def age(p):
        return (now_dt.timestamp() - os.path.getmtime(p)) / 60 if os.path.exists(p) else None

    rows = ""
    for name, a_ in (("Last agent run", run_age), ("signals.json", age(P["signals"])), ("Candles file", age(P["market"])), ("Option chain file", age(P["chain"]))):
        ok_ = a_ is not None and (a_ < 5 or not market_open)
        rows += kv(name, "N/A" if a_ is None else f"{a_:.1f} min ago", UP if ok_ else WARN if a_ is not None else MUTED)
    rows += kv("Last closed candle", J["candle_time"]) + kv("Option chain timestamp", J.get("chain_timestamp") or "not used")
    rows += kv("Yahoo vs NSE spot", f"{abs(spot - J['nse_spot']):,.1f} pts" if J.get("nse_spot") else "N/A")
    rows += kv("Sensitivity", dec["sensitivity"]) + kv("Claude review", "on" if llm.get("ok") else "off")
    rows += kv("Telegram alerts", "configured" if (fa.TELEGRAM_TOKEN and fa.TELEGRAM_CHAT_ID) else "not configured")
    st.markdown(f'<div class="card">{rows}</div>', unsafe_allow_html=True)
    st.download_button("Download signals.json", json.dumps(J, indent=2), file_name=f"{INST.lower()}_signals.json")

st.markdown(f'<div class="muted" style="font-size:.82rem;margin-top:26px">For analysis and education only, not investment advice. Option buying can lose the whole premium. '
            f'Agent updated {esc(J["timestamp"])} IST. Paper-trade first and trust the AI only when the Journal tab proves it.</div>', unsafe_allow_html=True)

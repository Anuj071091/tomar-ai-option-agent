from ta.trend import MACD
from ta.momentum import RSIIndicator
from ta.volatility import AverageTrueRange

import yfinance as yf

# ==================================
# DOWNLOAD NIFTY DATA
# ==================================

data = yf.download(
    "^NSEI",
    period="10d",
    interval="15m",
    auto_adjust=True
)

close = data["Close"].squeeze()
high = data["High"].squeeze()
low = data["Low"].squeeze()
volume = data["Volume"].squeeze()

# ==================================
# PRICE
# ==================================

current_price = float(close.iloc[-1])

# ==================================
# EMA
# ==================================

ema20 = close.ewm(span=20).mean()
ema50 = close.ewm(span=50).mean()

current_ema20 = float(ema20.iloc[-1])
current_ema50 = float(ema50.iloc[-1])

# ==================================
# RSI
# ==================================

rsi = RSIIndicator(close)
rsi_value = float(rsi.rsi().iloc[-1])

# ==================================
# MACD
# ==================================

macd = MACD(close)

macd_line = float(macd.macd().iloc[-1])
macd_signal = float(macd.macd_signal().iloc[-1])

# ==================================
# ATR
# ==================================

atr = AverageTrueRange(
    high=high,
    low=low,
    close=close
)

atr_value = float(
    atr.average_true_range().iloc[-1]
)

# ==================================
# VWAP FIX
# ==================================

if volume.sum() > 0:

    vwap = (
        (close * volume).cumsum()
        /
        volume.cumsum()
    )

    current_vwap = float(vwap.iloc[-1])

else:

    current_vwap = current_price

# ==================================
# SUPPORT / RESISTANCE
# ==================================

support = float(low.tail(50).min())
resistance = float(high.tail(50).max())

# ==================================
# TREND
# ==================================

if current_ema20 > current_ema50 and current_price > current_ema50:

    trend = "STRONG BULLISH"

elif current_ema20 > current_ema50:

    trend = "BULLISH"

elif current_ema20 < current_ema50 and current_price < current_ema50:

    trend = "STRONG BEARISH"

else:

    trend = "BEARISH"

# ==================================
# SCORE ENGINE
# ==================================

score = 0
reasons = []

# EMA

if current_ema20 > current_ema50:

    score += 30
    reasons.append("EMA Bullish")

else:

    score -= 30
    reasons.append("EMA Bearish")

# RSI

if rsi_value > 60:

    score += 20
    reasons.append("RSI Strong")

elif rsi_value < 40:

    score -= 20
    reasons.append("RSI Weak")

# MACD

if macd_line > macd_signal:

    score += 20
    reasons.append("MACD Bullish")

else:

    score -= 20
    reasons.append("MACD Bearish")

# PRICE VS EMA20

if current_price > current_ema20:

    score += 15
    reasons.append("Price Above EMA20")

else:

    score -= 15
    reasons.append("Price Below EMA20")

# PRICE VS EMA50

if current_price > current_ema50:

    score += 15
    reasons.append("Price Above EMA50")

else:

    score -= 15
    reasons.append("Price Below EMA50")

# VWAP

if current_price > current_vwap:

    score += 20
    reasons.append("Above VWAP")

elif current_price < current_vwap:

    score -= 20
    reasons.append("Below VWAP")

else:

    reasons.append("At VWAP")

# ==================================
# CONFIDENCE
# ==================================

confidence = min(abs(score) * 2, 100)

# ==================================
# MARKET BIAS
# ==================================

if score >= 40:

    bias = "BULLISH"

elif score <= -40:

    bias = "BEARISH"

else:

    bias = "SIDEWAYS"

# ==================================
# SIGNAL
# ==================================

if score >= 40:

    signal = "BUY CALL"

elif score <= -40:

    signal = "BUY PUT"

else:

    signal = "NO TRADE"

# ==================================
# GRADE
# ==================================

if confidence >= 80:

    grade = "A+"

elif confidence >= 60:

    grade = "A"

elif confidence >= 40:

    grade = "B"

else:

    grade = "C"

# ==================================
# TARGET SL
# ==================================

if signal == "BUY CALL":

    stoploss = round(
        current_price - atr_value * 1.5,
        2
    )

    target1 = round(
        current_price + atr_value * 2,
        2
    )

    target2 = round(
        current_price + atr_value * 3,
        2
    )

elif signal == "BUY PUT":

    stoploss = round(
        current_price + atr_value * 1.5,
        2
    )

    target1 = round(
        current_price - atr_value * 2,
        2
    )

    target2 = round(
        current_price - atr_value * 3,
        2
    )

else:

    stoploss = "N/A"
    target1 = "N/A"
    target2 = "N/A"

# ==================================
# RISK REWARD
# ==================================

if signal != "NO TRADE":

    risk = abs(current_price - stoploss)

    reward = abs(target1 - current_price)

    rr = round(reward / risk, 2)

else:

    rr = "N/A"

# ==================================
# OUTPUT
# ==================================

print("\n")
print("=" * 70)
print("              NIFTY OPTION ANALYSIS AGENT")
print("=" * 70)

print(f"\nCurrent Price : {current_price:.2f}")

print("\nINDICATORS")
print("-" * 70)

print(f"EMA20         : {current_ema20:.2f}")
print(f"EMA50         : {current_ema50:.2f}")
print(f"VWAP          : {current_vwap:.2f}")
print(f"RSI           : {rsi_value:.2f}")
print(f"MACD          : {macd_line:.2f}")
print(f"MACD Signal   : {macd_signal:.2f}")
print(f"ATR           : {atr_value:.2f}")

print("\nLEVELS")
print("-" * 70)

print(f"Support       : {support:.2f}")
print(f"Resistance    : {resistance:.2f}")

print("\nANALYSIS")
print("-" * 70)

print(f"Trend         : {trend}")
print(f"Market Bias   : {bias}")
print(f"Raw Score     : {score}")
print(f"Signal        : {signal}")
print(f"Confidence    : {confidence}%")
print(f"Trade Grade   : {grade}")

print("\nREASONS")
print("-" * 70)

for r in reasons:
    print("✓", r)

print("\nTRADE PLAN")
print("-" * 70)

print(f"Target 1      : {target1}")
print(f"Target 2      : {target2}")
print(f"Stoploss      : {stoploss}")
print(f"Risk Reward   : {rr}")

print("=" * 70)
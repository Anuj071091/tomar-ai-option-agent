"""apply_patches.py - adds greeks, option-flow, SQLite journal and journal option premiums to YOUR final_agent.py / ai_engine.py.

Run once from the project folder:   python apply_patches.py
Safe to re-run (already-applied edits are skipped). Originals are saved as *.bak. If an anchor line is not found
(your file differs from what this script expects) nothing is written for that file and it says which edit failed.
"""
import os
import shutil
import sys

NEW_FILES = ["greeks.py", "database.py", "flow_engine.py", "costs.py"]  # diagnose.py and backtest.py are optional tools

FINAL_AGENT = [
    ("import ai_engine as ai\n",
     "import ai_engine as ai\nimport database as tradedb\nfrom flow_engine import compute_flow\n",
     "from flow_engine import compute_flow"),
    ("    # ---- the AI read + decision\n",
     "    # ---- option flow (OI / premium / IV velocity from recorded snapshots)\n"
     "    flow = None\n    if ch:\n        try:\n            flow = compute_flow(P[\"ticks\"], ch, now_n)\n"
     "        except Exception as e:\n            print(\"Flow engine error:\", type(e).__name__, e)\n\n"
     "    # ---- the AI read + decision\n",
     "compute_flow(P["),
    ('                   llm=llm_res, inst_name=icfg["name"])',
     '                   llm=llm_res, inst_name=icfg["name"], flow=flow)',
     'inst_name=icfg["name"], flow=flow)'),
    ('status="PENDING", telegram=tg_sent))',
     'status="PENDING", telegram=tg_sent,\n                         option=plan.get("option")))',
     'option=plan.get("option")'),
    ("    # ---- files for the dashboard\n",
     "    try:\n        tradedb.sync(P[\"dir\"], hist)\n    except Exception as e:\n        print(\"Trade DB error:\", type(e).__name__, e)\n\n"
     "    # ---- files for the dashboard\n",
     "tradedb.sync("),
    ("llm=llm_res, settings=S,", "llm=llm_res, flow=flow, settings=S,", "flow=flow, settings=S,"),
    ('    d = yf.download(INSTRUMENTS[inst]["yf"], period=CFG["period"], interval=CFG["interval"], auto_adjust=True, progress=False)\n    if d is None or d.empty:\n        raise RuntimeError(f"No candles received for {inst} from Yahoo")\n    return d\n',
     '    sym, d = INSTRUMENTS[inst]["yf"], None\n    for _attempt in range(2):\n        try:\n            d = yf.download(sym, period=CFG["period"], interval=CFG["interval"], auto_adjust=True, progress=False)\n        except Exception as e:\n            print(f"yfinance download failed for {sym}:", type(e).__name__, e)\n        if d is not None and not d.empty:\n            return d\n        time.sleep(1.5)\n    try:                                            # second route: Ticker.history() often works when download() comes back empty\n        d = yf.Ticker(sym).history(period=CFG["period"], interval=CFG["interval"], auto_adjust=True)\n        if d is not None and not d.empty:\n            return d\n    except Exception as e:\n        print(f"yfinance history failed for {sym}:", type(e).__name__, e)\n    raise RuntimeError(f"No candles received for {inst} ({sym}) from Yahoo. Yahoo sometimes has no 5-minute data for this index; "\n                       f"try again in a few minutes or run python diagnose.py")\n',
     'yf.Ticker(sym).history('),
]

AI_ENGINE = [
    ('t1_prem=prem + dl * plan["t1_pts"], t2_prem=prem + dl * plan["t2_pts"], expiry=chain.get("expiry"))\n',
     't1_prem=prem + dl * plan["t1_pts"], t2_prem=prem + dl * plan["t2_pts"], expiry=chain.get("expiry"))\n'
     '            try:\n                from greeks import bs_greeks\n'
     '                g = bs_greeks(px, chain["atm"], chain.get("dte"), iv, side == "CALL")\n'
     '                plan["option"].update(gamma=g["gamma"], theta=g["theta"], vega=g["vega"])\n'
     '            except Exception:\n                pass\n',
     "from greeks import bs_greeks"),
    ("def external_tilt(spot, atr, chain, gift, news, now):",
     "def external_tilt(spot, atr, chain, gift, news, now, flow=None):",
     "def external_tilt(spot, atr, chain, gift, news, now, flow=None):"),
    ('    sw = sum(p["weight"] for p in parts)\n',
     '    if flow and flow.get("ok"):\n        for p in flow.get("parts", []):\n            add(p["name"], p["detail"], p["value"], p["weight"])\n'
     '    sw = sum(p["weight"] for p in parts)\n',
     'for p in flow.get("parts", [])'),
    ('inst_name="Index", min_rows=300):', 'inst_name="Index", min_rows=300, flow=None):', "min_rows=300, flow=None):"),
    ("tilt, parts = external_tilt(px, atr, chain, gift, news, now_n)",
     "tilt, parts = external_tilt(px, atr, chain, gift, news, now_n, flow)",
     "external_tilt(px, atr, chain, gift, news, now_n, flow)"),
    ('                 dte=(chain or {}).get("dte"))\n    side = dec["lean"]',
     '                 dte=(chain or {}).get("dte"))\n'
     '    if flow and flow.get("iv_crush") and dec["action"] != "WAIT":\n'
     '        dec["size_factor"] = round(dec["size_factor"] * 0.75, 2)\n'
     '        dec["notes"].append("Implied volatility is falling fast: premiums can shrink even if direction is right. Size reduced.")\n'
     '    side = dec["lean"]',
     'flow.get("iv_crush")'),
]


def patch(path, edits):
    if not os.path.exists(path):
        print(f"SKIP  {path}: not found in this folder")
        return False
    src = open(path, encoding="utf-8").read()
    out = src
    for i, (old, new, done) in enumerate(edits, 1):
        if done in out:
            print(f"  edit {i}: already applied")
            continue
        if out.count(old) != 1:
            print(f"FAIL  {path}: edit {i} anchor found {out.count(old)} times (need exactly 1):\n      {old.strip()[:90]!r}")
            return False
        out = out.replace(old, new)
        print(f"  edit {i}: applied")
    if out != src:
        shutil.copyfile(path, path + ".bak")
        open(path, "w", encoding="utf-8").write(out)
        print(f"OK    {path} updated (backup: {path}.bak)")
    else:
        print(f"OK    {path} already up to date")
    return True


if __name__ == "__main__":
    missing = [f for f in NEW_FILES if not os.path.exists(f)]
    if missing:
        sys.exit(f"Copy these files next to final_agent.py first: {', '.join(missing)}")
    ok = patch("final_agent.py", FINAL_AGENT)
    ok = patch("ai_engine.py", AI_ENGINE) and ok
    print("\nNext: python final_agent.py --demo" if ok else "\nSome edits failed - nothing was changed for those files. Send me the message above.")

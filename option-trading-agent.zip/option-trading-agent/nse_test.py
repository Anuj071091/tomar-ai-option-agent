
import warnings
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

import pandas as pd
import yfinance as yf

from ta.trend import MACD
from ta.momentum import RSIIndicator
from ta.volatility import AverageTrueRange

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# NIFTY OPTIONS ANALYSIS AGENT - REFINED VERSION
# Analysis only. No live orders are placed.
# ============================================================

SYMBOL = "^NSEI"
PERIOD = "10d"
INTERVAL = "15m"

RSI_PERIOD = 14
ATR_PERIOD = 14
ATM_RANGE = 500

SIGNAL_THRESHOLD = 40
MAX_LIVE_CANDLE_AGE_MINUTES = 30
MAX_SPOT_DIFFERENCE = 50

IST = ZoneInfo("Asia/Kolkata")


# ============================================================
# HELPERS
# ============================================================

def safe_float(value, default=None):
    try:
        result = float(value)
        if pd.isna(result):
            return default
        return result
    except (TypeError, ValueError):
        return default


def fmt(value, decimals=2):
    if value is None:
        return "Unavailable"
    return f"{value:,.{decimals}f}"


def get_series(data, column):
    result = data[column]

    if isinstance(result, pd.DataFrame):
        if result.shape[1] == 0:
            raise ValueError(f"No data for {column}")
        result = result.iloc[:, 0]

    return pd.to_numeric(result, errors="coerce")


def current_ist():
    return datetime.now(IST)


def parse_nse_timestamp(value):
    if not value:
        return None

    try:
        parsed = datetime.strptime(
            value, "%d-%b-%Y %H:%M:%S"
        )
        return parsed.replace(tzinfo=IST)
    except (ValueError, TypeError):
        return None


# ============================================================
# 1. MARKET SESSION / DATA FRESHNESS
# ============================================================

def check_market_session(now=None):
    if now is None:
        now = current_ist()

    # Weekends are not regular NSE trading sessions.
    # Exchange holidays must be checked separately.
    if now.weekday() >= 5:
        return False, "Weekend: regular NSE market is closed."

    if not (time(9, 15) <= now.time() <= time(15, 30)):
        return False, "Outside regular NSE market hours."

    return True, "Regular market hours."


def check_candle_freshness(last_candle):
    now = current_ist()

    candle_time = pd.Timestamp(last_candle)

    if candle_time.tzinfo is None:
        candle_time = candle_time.tz_localize(IST)
    else:
        candle_time = candle_time.tz_convert(IST)

    # A 15-minute candle labelled 15:15 normally ends at 15:30.
    candle_end = candle_time.to_pydatetime() + timedelta(minutes=15)

    age_minutes = (now - candle_end).total_seconds() / 60

    if age_minutes < -5:
        return False, "Latest candle timestamp is in the future."

    market_open, market_reason = check_market_session(now)

    if not market_open:
        return False, market_reason

    if age_minutes > MAX_LIVE_CANDLE_AGE_MINUTES:
        return False, (
            f"Stale candle: approximately {age_minutes:.0f} "
            "minutes old."
        )

    return True, "Candle freshness check passed."


# ============================================================
# 2. DOWNLOAD NIFTY DATA
# ============================================================

def download_nifty_data():
    print("Downloading NIFTY candles...")

    raw = yf.download(
        SYMBOL,
        period=PERIOD,
        interval=INTERVAL,
        auto_adjust=True,
        progress=False,
        threads=False
    )

    if raw is None or raw.empty:
        raise RuntimeError(
            "Yahoo Finance returned no NIFTY candles."
        )

    data = pd.DataFrame(index=raw.index)

    for col in ["Close", "High", "Low", "Volume"]:
        data[col] = get_series(raw, col)

    data["Volume"] = data["Volume"].fillna(0)

    data = data.dropna(subset=["Close", "High", "Low"])
    data = data[data["Close"] > 0]
    data = data.sort_index()
    data = data[~data.index.duplicated(keep="last")]

    if len(data) < 60:
        raise RuntimeError(
            f"Only {len(data)} valid candles received; "
            "at least 60 are required."
        )

    if (data["High"] < data["Low"]).any():
        raise RuntimeError("Invalid candle: High is below Low.")

    if (data["Close"] > data["High"]).any():
        raise RuntimeError("Invalid candle: Close is above High.")

    if (data["Close"] < data["Low"]).any():
        raise RuntimeError("Invalid candle: Close is below Low.")

    return data


# ============================================================
# 3. TECHNICAL ANALYSIS
# ============================================================

def technical_analysis(data):
    close = data["Close"]
    high = data["High"]
    low = data["Low"]
    volume = data["Volume"]

    price = safe_float(close.iloc[-1])

    # EMA
    ema20 = close.ewm(
        span=20, adjust=False
    ).mean()

    ema50 = close.ewm(
        span=50, adjust=False
    ).mean()

    ema20_now = safe_float(ema20.iloc[-1])
    ema50_now = safe_float(ema50.iloc[-1])

    # RSI
    rsi_series = RSIIndicator(
        close=close,
        window=RSI_PERIOD
    ).rsi()

    rsi_value = safe_float(rsi_series.iloc[-1])

    # MACD
    macd_obj = MACD(
        close=close,
        window_slow=26,
        window_fast=12,
        window_sign=9
    )

    macd_line = safe_float(macd_obj.macd().iloc[-1])
    macd_signal = safe_float(
        macd_obj.macd_signal().iloc[-1]
    )
    macd_hist = safe_float(
        macd_obj.macd_diff().iloc[-1]
    )

    # ATR
    atr_series = AverageTrueRange(
        high=high,
        low=low,
        close=close,
        window=ATR_PERIOD
    ).average_true_range()

    atr_value = safe_float(atr_series.iloc[-1])

    # Session-wise VWAP.
    # Index volume is often missing or zero.
    typical_price = (high + low + close) / 3

    session_keys = pd.Series(
        data.index.date,
        index=data.index
    )

    cumulative_pv = (
        (typical_price * volume)
        .groupby(session_keys)
        .cumsum()
    )

    cumulative_volume = (
        volume.groupby(session_keys).cumsum()
    )

    vwap_series = (
        cumulative_pv /
        cumulative_volume.replace(0, float("nan"))
    )

    vwap_value = safe_float(vwap_series.iloc[-1])

    # Recent 50-candle range
    support = safe_float(low.tail(50).min())
    resistance = safe_float(high.tail(50).max())

    # --------------------------------------------------------
    # FIXED TREND CLASSIFICATION
    # --------------------------------------------------------

    if ema20_now > ema50_now and price > ema50_now:
        trend = "STRONG BULLISH"

    elif ema20_now > ema50_now and price <= ema50_now:
        trend = "BULLISH - PULLBACK"

    elif ema20_now < ema50_now and price < ema50_now:
        trend = "STRONG BEARISH"

    elif ema20_now < ema50_now and price > ema50_now:
        trend = "MIXED / RECOVERY"

    else:
        trend = "NEUTRAL"

    # --------------------------------------------------------
    # TECHNICAL SCORE
    # --------------------------------------------------------

    score = 0
    reasons = []

    if ema20_now > ema50_now:
        score += 25
        reasons.append("EMA20 above EMA50")

    elif ema20_now < ema50_now:
        score -= 25
        reasons.append("EMA20 below EMA50")

    if price > ema20_now:
        score += 10
        reasons.append("Price above EMA20")

    elif price < ema20_now:
        score -= 10
        reasons.append("Price below EMA20")

    if price > ema50_now:
        score += 10
        reasons.append("Price above EMA50")

    elif price < ema50_now:
        score -= 10
        reasons.append("Price below EMA50")

    if rsi_value is not None:
        if rsi_value > 60:
            score += 15
            reasons.append("RSI bullish momentum")

        elif rsi_value < 40:
            score -= 15
            reasons.append("RSI bearish momentum")

        else:
            reasons.append("RSI neutral")

    if macd_line is not None and macd_signal is not None:
        if macd_line > macd_signal:
            score += 15
            reasons.append("MACD above signal")

        elif macd_line < macd_signal:
            score -= 15
            reasons.append("MACD below signal")

    # VWAP is optional. Never substitute spot price for VWAP.
    if vwap_value is not None:
        if price > vwap_value:
            score += 10
            reasons.append("Price above session VWAP")

        elif price < vwap_value:
            score -= 10
            reasons.append("Price below session VWAP")

    else:
        reasons.append("VWAP unavailable; no VWAP score added")

    return {
        "price": price,
        "ema20": ema20_now,
        "ema50": ema50_now,
        "rsi": rsi_value,
        "macd": macd_line,
        "macd_signal": macd_signal,
        "macd_hist": macd_hist,
        "atr": atr_value,
        "vwap": vwap_value,
        "support": support,
        "resistance": resistance,
        "trend": trend,
        "score": score,
        "reasons": reasons,
        "last_candle": data.index[-1]
    }


# ============================================================
# 4. FETCH AND VALIDATE OPTION CHAIN
# ============================================================

def fetch_option_chain():
    print("Fetching NSE option chain...")

    from nsepython import nse_optionchain_scrapper

    response = nse_optionchain_scrapper("NIFTY")

    if not isinstance(response, dict):
        raise RuntimeError("Unexpected NSE response.")

    records = response.get("data")

    if records is None:
        records = response.get("records", {}).get("data")

    if not isinstance(records, list) or not records:
        raise RuntimeError(
            "Option-chain data missing or NSE response changed."
        )

    return response, records


def option_chain_analysis():
    response, records = fetch_option_chain()

    # Collect CE and PE expiries independently.
    expiries = set()

    for row in records:
        for side in ("CE", "PE"):
            contract = row.get(side)

            if contract and contract.get("expiryDate"):
                expiries.add(contract["expiryDate"])

    valid_expiries = []

    for expiry in expiries:
        try:
            expiry_date = datetime.strptime(
                expiry, "%d-%b-%Y"
            ).date()

            valid_expiries.append((expiry_date, expiry))

        except (ValueError, TypeError):
            continue

    today = current_ist().date()

    future_expiries = [
        item for item in valid_expiries
        if item[0] >= today
    ]

    if not future_expiries:
        raise RuntimeError("No valid upcoming expiry found.")

    nearest_expiry = min(future_expiries)[1]

    # Find underlying spot.
    spot_price = None

    for row in records:
        for side in ("CE", "PE"):
            contract = row.get(side)

            if contract:
                spot_price = safe_float(
                    contract.get("underlyingValue")
                )

                if spot_price is not None:
                    break

        if spot_price is not None:
            break

    if spot_price is None:
        raise RuntimeError("NSE spot price unavailable.")

    total_ce = 0
    total_pe = 0

    max_ce_oi = -1
    max_pe_oi = -1

    max_ce_strike = None
    max_pe_strike = None

    for row in records:
        strike = safe_float(row.get("strikePrice"))

        if strike is None:
            continue

        if abs(strike - spot_price) > ATM_RANGE:
            continue

        ce = row.get("CE")
        pe = row.get("PE")

        # FIX: Validate each side's expiry independently.
        if ce and ce.get("expiryDate") == nearest_expiry:
            ce_oi = safe_float(ce.get("openInterest"), 0) or 0

            total_ce += ce_oi

            if ce_oi > max_ce_oi:
                max_ce_oi = ce_oi
                max_ce_strike = strike

        if pe and pe.get("expiryDate") == nearest_expiry:
            pe_oi = safe_float(pe.get("openInterest"), 0) or 0

            total_pe += pe_oi

            if pe_oi > max_pe_oi:
                max_pe_oi = pe_oi
                max_pe_strike = strike

    if total_ce <= 0 or total_pe <= 0:
        pcr = None
        option_bias = "UNAVAILABLE"

    else:
        pcr = round(total_pe / total_ce, 2)

        if pcr > 1.1:
            option_bias = "BULLISH PCR"

        elif pcr < 0.9:
            option_bias = "BEARISH PCR"

        else:
            option_bias = "NEUTRAL PCR"

    return {
        "spot": spot_price,
        "expiry": nearest_expiry,
        "pcr": pcr,
        "option_bias": option_bias,
        "total_ce": total_ce,
        "total_pe": total_pe,
        "max_ce_oi": max(max_ce_oi, 0),
        "max_pe_oi": max(max_pe_oi, 0),
        "ce_strike": max_ce_strike,
        "pe_strike": max_pe_strike,
        "timestamp": response.get("timestamp"),
        "parsed_timestamp": parse_nse_timestamp(
            response.get("timestamp")
        )
    }


# ============================================================
# 5. DATA VALIDATION
# ============================================================

def validate_data(tech, chain):
    warnings_list = []

    candle_ok, candle_reason = check_candle_freshness(
        tech["last_candle"]
    )

    if not candle_ok:
        warnings_list.append(candle_reason)

    # Compare data-feed spot prices.
    price_difference = abs(tech["price"] - chain["spot"])

    if price_difference > MAX_SPOT_DIFFERENCE:
        warnings_list.append(
            f"Spot mismatch: Yahoo vs NSE differs by "
            f"{price_difference:.2f} points."
        )

    # Compare NSE timestamp with current time during market hours.
    now = current_ist()
    market_open, _ = check_market_session(now)

    nse_time = chain["parsed_timestamp"]

    if market_open:
        if nse_time is None:
            warnings_list.append(
                "NSE timestamp unavailable; freshness unverified."
            )

        else:
            age = (now - nse_time).total_seconds() / 60

            if age < -5:
                warnings_list.append(
                    "NSE timestamp is unexpectedly in the future."
                )

            elif age > MAX_LIVE_CANDLE_AGE_MINUTES:
                warnings_list.append(
                    f"NSE option chain is stale ({age:.0f} minutes old)."
                )

    # Missing required indicators must block a signal.
    required_values = [
        tech["price"],
        tech["ema20"],
        tech["ema50"],
        tech["rsi"],
        tech["macd"],
        tech["macd_signal"],
        tech["atr"]
    ]

    if any(value is None for value in required_values):
        warnings_list.append("One or more required indicators are missing.")

    if tech["atr"] is not None and tech["atr"] <= 0:
        warnings_list.append("ATR is invalid.")

    return {
        "valid_for_live_signal": (
            candle_ok and
            price_difference <= MAX_SPOT_DIFFERENCE and
            not any(
                "unavailable" in item.lower()
                or "stale" in item.lower()
                or "future" in item.lower()
                or "missing" in item.lower()
                or "invalid" in item.lower()
                for item in warnings_list
            )
        ),
        "warnings": warnings_list,
        "candle_ok": candle_ok,
        "candle_reason": candle_reason,
        "price_difference": price_difference
    }


# ============================================================
# 6. MASTER DECISION ENGINE
# ============================================================

def master_decision(tech, chain, validation):
    technical_score = tech["score"]

    # Option-chain contribution is deliberately limited.
    option_score = 0

    if chain["pcr"] is not None:
        if chain["pcr"] > 1.1:
            option_score = 15

        elif chain["pcr"] < 0.9:
            option_score = -15

    final_score = technical_score + option_score

    if not validation["valid_for_live_signal"]:
        signal = "NO TRADE"
        reason = "Data validation failed or market is not live."

    elif final_score >= SIGNAL_THRESHOLD:
        signal = "BUY CALL"
        reason = "Bullish score threshold reached."

    elif final_score <= -SIGNAL_THRESHOLD:
        signal = "BUY PUT"
        reason = "Bearish score threshold reached."

    else:
        signal = "NO TRADE"
        reason = "Score is inside the no-trade zone."

    # This is score strength, NOT a win probability.
    score_strength = min(abs(final_score), 100)

    price = tech["price"]
    atr = tech["atr"]

    # NIFTY INDEX levels only. Not option premium levels.
    if signal == "BUY CALL":
        stoploss = round(price - 1.5 * atr, 2)
        target1 = round(price + 2 * atr, 2)
        target2 = round(price + 3 * atr, 2)

    elif signal == "BUY PUT":
        stoploss = round(price + 1.5 * atr, 2)
        target1 = round(price - 2 * atr, 2)
        target2 = round(price - 3 * atr, 2)

    else:
        stoploss = None
        target1 = None
        target2 = None

    if signal != "NO TRADE":
        risk = abs(price - stoploss)
        reward = abs(target1 - price)

        rr = round(reward / risk, 2) if risk > 0 else None
    else:
        rr = None

    return {
        "technical_score": technical_score,
        "option_score": option_score,
        "final_score": final_score,
        "signal": signal,
        "reason": reason,
        "score_strength": score_strength,
        "stoploss": stoploss,
        "target1": target1,
        "target2": target2,
        "rr": rr
    }


# ============================================================
# 7. REPORT
# ============================================================

def print_report(tech, chain, validation, decision):
    print("\n" + "=" * 72)
    print("             NIFTY OPTIONS ANALYSIS AGENT")
    print("=" * 72)

    print(f"Analysis time     : {current_ist():%Y-%m-%d %H:%M:%S %Z}")
    print(f"Last candle       : {tech['last_candle']}")
    print(f"NIFTY spot        : {fmt(tech['price'])}")
    print(f"NSE chain spot    : {fmt(chain['spot'])}")
    print(f"Nearest expiry    : {chain['expiry']}")

    print("\nTECHNICAL INDICATORS")
    print("-" * 72)
    print(f"EMA20             : {fmt(tech['ema20'])}")
    print(f"EMA50             : {fmt(tech['ema50'])}")
    print(f"VWAP              : {fmt(tech['vwap'])}")
    print(f"RSI               : {fmt(tech['rsi'])}")
    print(f"MACD              : {fmt(tech['macd'])}")
    print(f"MACD Signal       : {fmt(tech['macd_signal'])}")
    print(f"MACD Histogram    : {fmt(tech['macd_hist'])}")
    print(f"ATR               : {fmt(tech['atr'])}")
    print(f"Trend             : {tech['trend']}")

    print("\nTECHNICAL LEVELS")
    print("-" * 72)
    print(f"Recent support    : {fmt(tech['support'])}")
    print(f"Recent resistance : {fmt(tech['resistance'])}")

    print("\nOPTION CHAIN")
    print("-" * 72)
    print(f"PCR               : {fmt(chain['pcr'])}")
    print(f"Option bias       : {chain['option_bias']}")
    print(f"Total CE OI       : {chain['total_ce']:,}")
    print(f"Total PE OI       : {chain['total_pe']:,}")
    print(f"Highest CE OI     : {chain['max_ce_oi']:,}")
    print(f"CE OI strike      : {fmt(chain['ce_strike'])}")
    print(f"Highest PE OI     : {chain['max_pe_oi']:,}")
    print(f"PE OI strike      : {fmt(chain['pe_strike'])}")
    print(f"NSE timestamp     : {chain['timestamp'] or 'Unavailable'}")

    print("\nDATA VALIDATION")
    print("-" * 72)
    print(f"Candle check      : {validation['candle_reason']}")
    print(f"Spot difference   : {validation['price_difference']:.2f} points")
    print(
        "Live signal valid: "
        f"{'YES' if validation['valid_for_live_signal'] else 'NO'}"
    )

    if validation["warnings"]:
        for warning in validation["warnings"]:
            print(f"WARNING: {warning}")
    else:
        print("No data-validation warnings.")

    print("\nSCORING AND DECISION")
    print("-" * 72)
    print(f"Technical score   : {decision['technical_score']}")
    print(f"Option-chain score: {decision['option_score']}")
    print(f"Final score       : {decision['final_score']}")
    print(f"Signal            : {decision['signal']}")
    print(f"Score strength    : {decision['score_strength']}/100")
    print(f"Reason            : {decision['reason']}")

    print("\nTECHNICAL REASONS")
    print("-" * 72)

    for reason in tech["reasons"]:
        print(f"- {reason}")

    print("\nINDEX-LEVEL ATR PLAN")
    print("-" * 72)
    print(f"Stop-loss         : {fmt(decision['stoploss'])}")
    print(f"Target 1          : {fmt(decision['target1'])}")
    print(f"Target 2          : {fmt(decision['target2'])}")
    print(f"Risk/reward       : {fmt(decision['rr'])}")

    print("\nIMPORTANT WARNINGS")
    print("-" * 72)
    print("- Score strength is not the probability of winning.")
    print("- OI levels are potential zones, not guaranteed support/resistance.")
    print("- Index ATR levels are NOT option premium stop-loss levels.")
    print("- This script does not select an option strike or place orders.")
    print("- Verify option premium, bid/ask spread, liquidity and position risk.")
    print("- Exchange holidays require an official trading calendar.")
    print("- Backtest and paper-trade before using real capital.")

    print("=" * 72)


# ============================================================
# 8. MAIN
# ============================================================

def main():
    try:
        data = download_nifty_data()

        print("Calculating technical indicators...")
        tech = technical_analysis(data)

        chain = option_chain_analysis()

        validation = validate_data(tech, chain)

        decision = master_decision(
            tech,
            chain,
            validation
        )

        print_report(
            tech,
            chain,
            validation,
            decision
        )

    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user.")

    except Exception as exc:
        print("\nANALYSIS FAILED")
        print("-" * 72)
        print(f"Error: {type(exc).__name__}: {exc}")
        print(
            "No trade decision generated. Check internet connectivity, "
            "library versions and the current data-provider response."
        )


if __name__ == "__main__":
    main()

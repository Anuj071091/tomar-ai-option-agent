"""diagnose.py - shows exactly why SENSEX/NIFTY data fails or why the AI says WAIT.   Run:  python diagnose.py"""
import json
import os
import sys

print("Python", sys.version.split()[0])
for mod in ("streamlit", "yfinance", "pandas", "numpy", "plotly"):
    try:
        m = __import__(mod)
        print(f"  {mod} {getattr(m, '__version__', '?')}")
    except Exception as e:
        print(f"  {mod} MISSING ({e})")

print("\n== Yahoo data (5-minute candles, last 5 days) ==")
try:
    import yfinance as yf
    for name, sym in (("NIFTY", "^NSEI"), ("SENSEX", "^BSESN")):
        for route in ("download", "Ticker.history"):
            try:
                d = (yf.download(sym, period="5d", interval="5m", progress=False, auto_adjust=True) if route == "download"
                     else yf.Ticker(sym).history(period="5d", interval="5m", auto_adjust=True))
                n = 0 if d is None else len(d)
                last = d.index[-1] if n else None
                print(f"  {name:6} {sym:7} via {route:14}: {n} candles, last = {last}")
            except Exception as e:
                print(f"  {name:6} {sym:7} via {route:14}: ERROR {type(e).__name__}: {e}")
except Exception as e:
    print("  yfinance not usable:", e)

print("\n== Agent output per instrument ==")
try:
    import final_agent as fa
    root = os.environ.get("NIFTY_DATA_DIR") or fa.BASE
    print("  data folder:", root, "| settings:", fa.load_settings(root))
    for inst in fa.INSTRUMENTS:
        P = fa.get_paths(root, inst)
        print(f"\n  [{inst}] signals.json: {os.path.exists(P['signals'])}  market_data.csv: {os.path.exists(P['market'])}  lock file: {os.path.exists(P['lock'])}")
        J = fa.read_json(P["signals"], {})
        if not J:
            print("    nothing written yet")
            continue
        if J.get("agent_error"):
            print("    LAST AGENT ERROR:", J["agent_error"], "at", J.get("error_ts"))
        dec = J.get("decision")
        if dec:
            print(f"    decision {dec['action']} (lean {dec['lean']}) | edge {dec['ev']:+.3f}R, needs {dec['thresholds']['ev_min']:+.3f}R "
                  f"| call {dec['ev_long']:+.3f}R vs put {dec['ev_short']:+.3f}R | sensitivity {dec['sensitivity']}")
            print("    blockers:", dec["blockers"] or "none")
            m = J.get("model", {})
            print(f"    model reliability {int(m.get('rel', 0) * 100)}% | predictive power {m.get('ic', 0):+.3f} | status {m.get('status')}")
            print("    summary:", dec["summary"])
except Exception as e:
    print("  could not read agent output:", type(e).__name__, e)

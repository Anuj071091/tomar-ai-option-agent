"""final_agent.py - AI option-signal agent for NIFTY / SENSEX (v4).

No fixed strategy. All decisions come from ai_engine.analyze(): a model that learns from recent candles and is
tested on unseen data, plus market reading, news analysis and (optionally) a Claude review.
This file only does data fetching, safety checks, journaling, alerts and writing the files the dashboard reads.

Run once:        python final_agent.py
Run as service:  python final_agent.py --loop 60
Demo (offline):  python final_agent.py --demo
Optional env:    ANTHROPIC_API_KEY (Claude review), TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, NIFTY_DATA_DIR
"""
import argparse
import json
import os
import time
import traceback
import warnings
import xml.etree.ElementTree as ET
from datetime import datetime, time as dtime, timedelta
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import requests

import ai_engine as ai
import database as tradedb
from flow_engine import compute_flow

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
IST = ZoneInfo("Asia/Kolkata")
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

CFG = dict(period="30d", interval="5m", candle_minutes=5, keep_days=5, market_open=(9, 15), market_close=(15, 30),
           first_trade="09:25", last_trade="15:05", max_candle_age_min=15, max_chain_age_min=30,
           chain_store_window=1500, max_expiries=8, pcr_window=500, tick_window=600, tick_max_bytes=20_000_000,
           tick_keep_days=5, news_ttl_sec=900, gift_ttl_sec=300, vix_ttl_sec=300, llm_ttl_sec=300)

INSTRUMENTS = {
    "NIFTY": dict(name="NIFTY 50", yf="^NSEI", chain="nse", news=["nifty", "nifty 50 outlook"]),
    "SENSEX": dict(name="SENSEX", yf="^BSESN", chain=None, news=["sensex", "bse sensex"]),
}
MARKET_NEWS = ["indian stock market", "RBI", "FII DII flows", "Wall Street stocks", "crude oil price"]

DEFAULT_SETTINGS = dict(sensitivity="Balanced", use_llm=True, max_signals_day=3, stop_after_losses=2,
                        alert_cooldown_min=15, bg_agent=True, agent_interval=60)


# ----------------------------------------------------------------------------- small utils
def get_paths(data_dir=None, inst="NIFTY"):
    root = data_dir or os.environ.get("NIFTY_DATA_DIR") or BASE
    d = os.path.join(root, inst.lower())
    os.makedirs(d, exist_ok=True)
    return dict(dir=d, signals=os.path.join(d, "signals.json"), chain=os.path.join(d, "option_chain.json"),
                market=os.path.join(d, "market_data.csv"), history=os.path.join(d, "signal_history.json"),
                ticks=os.path.join(d, "option_ticks.csv"), ticks_state=os.path.join(d, "option_ticks.state"),
                lock=os.path.join(d, "agent.lock"), root=root)


def _json_default(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return None if np.isnan(o) else float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, (pd.Timestamp, datetime)):
        return o.strftime("%d-%m-%Y %H:%M:%S")
    return str(o)


def _nan_to_none(o):
    if isinstance(o, float):
        return None if (o != o or o in (float("inf"), float("-inf"))) else o
    if isinstance(o, dict):
        return {k: _nan_to_none(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_nan_to_none(v) for v in o]
    return o


def atomic_write_json(path, obj, indent=None):
    tmp = f"{path}.tmp{os.getpid()}"
    with open(tmp, "w") as f:
        json.dump(_nan_to_none(json.loads(json.dumps(obj, default=_json_default))), f, indent=indent, allow_nan=False)
    os.replace(tmp, path)


def read_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default


def is_market_open(now):
    return now.weekday() < 5 and CFG["market_open"] <= (now.hour, now.minute) <= CFG["market_close"]


def clean(v, nd=2):
    try:
        v = float(v)
        return None if np.isnan(v) else round(v, nd)
    except Exception:
        return None


def _hm(x):
    h, m = str(x).split(":")
    return int(h), int(m)


def settings_path(root=None):
    return os.path.join(root or os.environ.get("NIFTY_DATA_DIR") or BASE, "ai_settings.json")


def load_settings(root=None):
    out = dict(DEFAULT_SETTINGS)
    s = read_json(settings_path(root), {})
    if isinstance(s, dict):
        out.update({k: s[k] for k in DEFAULT_SETTINGS if k in s})
    if out["sensitivity"] not in ai.SENSITIVITY:
        out["sensitivity"] = "Balanced"
    return out


def save_settings(root, s):
    cur = read_json(settings_path(root), {})
    atomic_write_json(settings_path(root), {**(cur if isinstance(cur, dict) else {}), **s}, indent=2)


def _cached(path, ttl, fetch, max_stale_mult=6):
    """Use cached data within ttl; if fetching fails, fall back to older data (up to ttl * max_stale_mult)."""
    c, age = None, None
    try:
        with open(path) as f:
            c = json.load(f)
        age = time.time() - c["ts"]
        if age <= ttl:
            return c["data"]
    except Exception:
        c, age = None, None
    try:
        data = fetch()
        if data is not None:
            atomic_write_json(path, dict(ts=time.time(), data=data))
            return data
    except Exception as e:
        print("fetch failed:", type(e).__name__, e)
    if c is not None and age is not None and age <= ttl * max_stale_mult:
        return c["data"]
    return None


# ----------------------------------------------------------------------------- market data
def prepare_candles(d, now, drop_forming=True):
    d = d.copy()
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = d.columns.get_level_values(0)
    d = d[["Open", "High", "Low", "Close", "Volume"]].dropna(subset=["Close"])
    idx = d.index
    if idx.tz is None:
        idx = idx.tz_localize("UTC")
    d.index = idx.tz_convert("Asia/Kolkata").tz_localize(None)
    d.index.name = "Datetime"
    d = d[~d.index.duplicated(keep="last")].sort_index()
    now_n = now.replace(tzinfo=None)
    if drop_forming and len(d) > 1 and now_n < d.index[-1] + timedelta(minutes=CFG["candle_minutes"]):
        d = d.iloc[:-1]
    return d


def session_summary(d):
    day = d.index.normalize()
    last = day[-1]
    cur, prv = d[day == last], d[day < last]
    out = dict(date=last.strftime("%d-%m-%Y"), open=float(cur["Open"].iloc[0]), high=float(cur["High"].max()),
               low=float(cur["Low"].min()), close=float(cur["Close"].iloc[-1]), prev_open=None, prev_high=None,
               prev_low=None, prev_close=None, change=None, change_pct=None, gap_pct=None)
    if len(prv):
        pday = prv[prv.index.normalize() == prv.index.normalize()[-1]]
        pc = float(pday["Close"].iloc[-1])
        out.update(prev_open=float(pday["Open"].iloc[0]), prev_high=float(pday["High"].max()),
                   prev_low=float(pday["Low"].min()), prev_close=pc, change=out["close"] - pc,
                   change_pct=(out["close"] - pc) / pc * 100, gap_pct=(out["open"] - pc) / pc * 100)
    return out


def fetch_candles(inst="NIFTY"):
    import yfinance as yf
    sym, d = INSTRUMENTS[inst]["yf"], None
    for _attempt in range(2):
        try:
            d = yf.download(sym, period=CFG["period"], interval=CFG["interval"], auto_adjust=True, progress=False)
        except Exception as e:
            print(f"yfinance download failed for {sym}:", type(e).__name__, e)
        if d is not None and not d.empty:
            return d
        time.sleep(1.5)
    try:                                            # second route: Ticker.history() often works when download() comes back empty
        d = yf.Ticker(sym).history(period=CFG["period"], interval=CFG["interval"], auto_adjust=True)
        if d is not None and not d.empty:
            return d
    except Exception as e:
        print(f"yfinance history failed for {sym}:", type(e).__name__, e)
    raise RuntimeError(f"No candles received for {inst} ({sym}) from Yahoo. Yahoo sometimes has no 5-minute data for this index; "
                       f"try again in a few minutes or run python diagnose.py")


def fetch_vix():
    import yfinance as yf
    d = yf.download("^INDIAVIX", period="5d", interval="1d", auto_adjust=True, progress=False)
    if d is None or d.empty:
        return None
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = d.columns.get_level_values(0)
    cl = d["Close"].dropna()
    last, prev = float(cl.iloc[-1]), float(cl.iloc[-2]) if len(cl) > 1 else float(cl.iloc[-1])
    return dict(last=last, prev=prev, change_pct=(last - prev) / prev * 100 if prev else 0.0)


def fetch_gift():
    try:
        from nsepython import nsefetch
        gn = (nsefetch("https://www.nseindia.com/api/marketStatus") or {}).get("giftnifty") or {}
        num = lambda x: float(str(x).replace(",", "").strip())
        return dict(price=num(gn["LASTPRICE"]), change=num(gn.get("DAYCHANGE") or 0), change_pct=num(gn.get("PERCHANGE") or 0),
                    expiry=gn.get("EXPIRYDATE"), time=gn.get("TIMESTMP"))
    except Exception as e:
        print("GIFT Nifty fetch failed:", type(e).__name__, e)
        return None


def fetch_news_items(inst="NIFTY", per_query=12):
    """Google News RSS (no key needed), several queries, last 1 day. Returns [{title, source, ts}]."""
    items = []
    for q in INSTRUMENTS[inst]["news"] + MARKET_NEWS:
        try:
            r = requests.get("https://news.google.com/rss/search", timeout=8,
                             params={"q": f"{q} when:1d", "hl": "en-IN", "gl": "IN", "ceid": "IN:en"},
                             headers={"User-Agent": "Mozilla/5.0"})
            root = ET.fromstring(r.content)
            for it in list(root.iter("item"))[:per_query]:
                title = (it.findtext("title") or "").strip()
                src = (it.findtext("source") or "").strip()
                if src and title.endswith(" - " + src):
                    title = title[: -len(src) - 3]
                try:
                    ts = parsedate_to_datetime(it.findtext("pubDate")).timestamp()
                except Exception:
                    ts = None
                items.append(dict(title=title, source=src, ts=ts))
        except Exception as e:
            print(f"news query '{q}' failed:", type(e).__name__)
    return items


# ----------------------------------------------------------------------------- option chain (NSE)
def fetch_chain_raw(inst="NIFTY"):
    if INSTRUMENTS[inst]["chain"] != "nse":
        raise NotImplementedError(f"No option-chain source for {inst}")
    from nsepython import nse_optionchain_scrapper
    return nse_optionchain_scrapper("NIFTY")


def parse_chain(oc):
    rec = oc.get("records") if isinstance(oc.get("records"), dict) else oc
    rows, spot = [], None
    for r in rec.get("data") or []:
        ce, pe = r.get("CE") or {}, r.get("PE") or {}
        ref = ce or pe
        if not ref:
            continue
        exp = ref.get("expiryDate") or r.get("expiryDate")
        spot = spot or ref.get("underlyingValue")
        g = lambda x, k: float(x.get(k) or 0)
        rows.append(dict(expiry=exp, strike=float(r.get("strikePrice") or ref.get("strikePrice")),
                         ce_oi=g(ce, "openInterest"), ce_chg_oi=g(ce, "changeinOpenInterest"), ce_vol=g(ce, "totalTradedVolume"),
                         ce_iv=g(ce, "impliedVolatility"), ce_ltp=g(ce, "lastPrice"),
                         pe_oi=g(pe, "openInterest"), pe_chg_oi=g(pe, "changeinOpenInterest"), pe_vol=g(pe, "totalTradedVolume"),
                         pe_iv=g(pe, "impliedVolatility"), pe_ltp=g(pe, "lastPrice")))
    if not rows:
        raise RuntimeError("Option chain came back empty")
    df = pd.DataFrame(rows)
    df["exp_date"] = pd.to_datetime(df["expiry"], format="%d-%b-%Y").dt.date
    df = df.drop_duplicates(["expiry", "strike"], keep="last")
    spot = spot or rec.get("underlyingValue")
    return df, (float(spot) if spot else None), str(rec.get("timestamp") or oc.get("timestamp") or "")


def pick_nearest_expiry(df, now):
    exps = sorted(df["exp_date"].unique())
    for e in exps:
        if e > now.date() or (e == now.date() and now.time() <= dtime(*CFG["market_close"])):
            return e
    return exps[-1]


def expiry_stats(df, spot, today, window=None):
    window = window or CFG["pcr_window"]
    df = df.sort_values("strike").reset_index(drop=True)
    K = df["strike"].values.astype(float)
    ce, pe = df["ce_oi"].values.astype(float), df["pe_oi"].values.astype(float)
    diff = K[:, None] - K[None, :]
    pain = (np.maximum(diff, 0) * ce[None, :]).sum(1) + (np.maximum(-diff, 0) * pe[None, :]).sum(1)
    ai_ = int(np.abs(K - spot).argmin())
    near = np.abs(K - spot) <= window
    if not near.any():
        near = np.ones(len(K), bool)
    ce_n, pe_n = ce[near], pe[near]
    ce_chg, pe_chg = float(df["ce_chg_oi"].values[near].sum()), float(df["pe_chg_oi"].values[near].sum())
    if ce_chg > 0 and pe_chg <= 0:
        bu, bp = "SHORT BUILDUP", -10
    elif pe_chg > 0 and ce_chg <= 0:
        bu, bp = "LONG BUILDUP", 10
    elif ce_chg > 0 and pe_chg > 0:
        if pe_chg > ce_chg * 1.3:
            bu, bp = "PUT WRITING HEAVY", 5
        elif ce_chg > pe_chg * 1.3:
            bu, bp = "CALL WRITING HEAVY", -5
        else:
            bu, bp = "NEUTRAL", 0
    else:
        bu, bp = "UNWINDING", 0
    a = df.iloc[ai_]
    exp_date = df["exp_date"].iloc[0]
    return dict(expiry=str(df["expiry"].iloc[0]), dte=int((exp_date - today).days), atm=float(a["strike"]),
                ce_ltp=float(a["ce_ltp"]), pe_ltp=float(a["pe_ltp"]), ce_iv=float(a["ce_iv"]), pe_iv=float(a["pe_iv"]),
                straddle=float(a["ce_ltp"] + a["pe_ltp"]),
                pcr_full=round(float(pe.sum() / ce.sum()), 2) if ce.sum() else 0.0,
                pcr_near=round(float(pe_n.sum() / ce_n.sum()), 2) if ce_n.sum() else 0.0,
                max_pain=float(K[int(pain.argmin())]), support=float(K[near][int(pe_n.argmax())]),
                resistance=float(K[near][int(ce_n.argmax())]), ce_oi=int(ce.sum()), pe_oi=int(pe.sum()),
                ce_vol=int(df["ce_vol"].sum()), pe_vol=int(df["pe_vol"].sum()), ce_chg_near=int(ce_chg),
                pe_chg_near=int(pe_chg), buildup=bu, buildup_pts=bp, window=int(window))


def parse_chain_time(ts):
    for fmt in ("%d-%b-%Y %H:%M:%S", "%d-%b-%Y %H:%M"):
        try:
            return datetime.strptime(ts, fmt)
        except Exception:
            pass
    return None


def record_option_ticks(chain_file, P, now_n):
    """Append real premium snapshots so the dashboard can draw real option candles over time."""
    if not chain_file:
        return 0
    snap = parse_chain_time(chain_file.get("timestamp") or "") or now_n
    if not is_market_open(snap):
        return 0
    stamp = snap.strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(P["ticks_state"]) as f:
            if f.read().strip() == stamp:
                return 0
    except OSError:
        pass
    all_e = chain_file.get("expiries", [])
    dts = {e: datetime.strptime(e, "%d-%b-%Y") for e in all_e}
    wanted = set(all_e[:3])
    for ex in all_e:
        if dts[ex] == max(dts[o] for o in all_e if o[3:] == ex[3:]):
            wanted.add(ex)
        if len(wanted) >= 6:
            break
    ref = chain_file.get("spot") or 0
    lines = []
    for ex in wanted:
        for r in chain_file["chain"].get(ex, []):
            if abs(r["strike"] - ref) > CFG["tick_window"]:
                continue
            for typ, p in (("CE", "ce"), ("PE", "pe")):
                if (r.get(p + "_ltp") or 0) > 0:
                    lines.append(f'{stamp},{ex},{r["strike"]},{typ},{r[p + "_ltp"]},{r.get(p + "_oi", 0)},{r.get(p + "_vol", 0)},{r.get(p + "_iv", 0)}\n')
    new = not os.path.exists(P["ticks"])
    with open(P["ticks"], "a") as f:
        if new:
            f.write("ts,expiry,strike,type,ltp,oi,vol,iv\n")
        f.writelines(lines)
    with open(P["ticks_state"], "w") as f:
        f.write(stamp)
    if os.path.getsize(P["ticks"]) > CFG["tick_max_bytes"]:
        df_ = pd.read_csv(P["ticks"], parse_dates=["ts"])
        df_[df_["ts"] >= pd.Timestamp(snap) - pd.Timedelta(days=CFG["tick_keep_days"])].to_csv(P["ticks"], index=False)
    return len(lines)


# ----------------------------------------------------------------------------- alerts + locking
def send_telegram(text):
    if not (TELEGRAM_TOKEN and TELEGRAM_CHAT_ID):
        print("Telegram not configured - alert skipped")
        return False
    try:
        r = requests.post(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
                          json={"chat_id": TELEGRAM_CHAT_ID, "text": text}, timeout=10)
        return bool(r.ok)
    except Exception as e:
        print("Telegram error:", e)
        return False


def acquire_lock(path, stale_sec=180):
    for _ in range(2):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(path) > stale_sec:
                    os.remove(path)
                    continue
            except OSError:
                pass
            return False
    return False


def release_lock(path):
    try:
        os.remove(path)
    except OSError:
        pass


# ----------------------------------------------------------------------------- one run
def run_once(inst="NIFTY", candles=None, chain_raw=None, news_items=None, gift="auto", vix="auto", now=None,
             data_dir=None, send=True, settings=None, llm="auto"):
    icfg = INSTRUMENTS[inst]
    now = now or datetime.now(IST)
    now_n = now.replace(tzinfo=None)
    P = get_paths(data_dir, inst)
    prev = read_json(P["signals"], {})
    S = settings or load_settings(data_dir)

    # ---- price data
    raw = candles if candles is not None else fetch_candles(inst)
    session = session_summary(prepare_candles(raw, now, drop_forming=False))
    d = prepare_candles(raw, now)
    if len(d) < 120:
        raise ValueError(f"Only {len(d)} candles available, need at least 120")
    candle_time = d.index[-1]
    candle_age = max((now_n - (candle_time + timedelta(minutes=CFG["candle_minutes"]))).total_seconds() / 60, 0.0)
    mkt_open = is_market_open(now_n)

    # ---- option chain (NIFTY only)
    ch, chain_ts, nse_spot, chain_err, chain_file = None, "", None, None, None
    if icfg["chain"]:
        try:
            oc = chain_raw if chain_raw is not None else fetch_chain_raw(inst)
            cdf, nse_spot, chain_ts = parse_chain(oc)
            ref_spot = nse_spot or float(d["Close"].iloc[-1])
            stats, rows = {}, {}
            for e in sorted(cdf["exp_date"].unique())[:CFG["max_expiries"]]:
                sub = cdf[cdf["exp_date"] == e]
                es = expiry_stats(sub, ref_spot, now_n.date())
                stats[es["expiry"]] = es
                win = sub[(sub["strike"] - ref_spot).abs() <= CFG["chain_store_window"]].sort_values("strike")
                rows[es["expiry"]] = win.drop(columns=["expiry", "exp_date"]).round(2).to_dict("records")
            near_exp = pick_nearest_expiry(cdf, now_n)
            ch = stats[next(k for k in stats if pd.to_datetime(k, format="%d-%b-%Y").date() == near_exp)]
            chain_file = dict(spot=ref_spot, timestamp=chain_ts, fetched=now_n.strftime("%d-%m-%Y %H:%M:%S"),
                              nearest=ch["expiry"], expiries=list(stats.keys()), stats=stats, chain=rows)
        except Exception as e:
            chain_err = f"{type(e).__name__}: {e}"
            print("Option chain error:", chain_err)
    cts = parse_chain_time(chain_ts) if chain_ts else None
    chain_age = (now_n - cts).total_seconds() / 60 if cts else None
    if ch is not None and chain_age is not None and mkt_open and chain_age > CFG["max_chain_age_min"]:
        ch = None                                   # stale chain would mislead: ignore it
        chain_err = f"Option chain is {chain_age:.0f} min old and was ignored"

    # ---- context: gift, vix, news
    if isinstance(gift, str):
        gift = _cached(os.path.join(P["dir"], "gift_cache.json"), CFG["gift_ttl_sec"], fetch_gift) if inst == "NIFTY" else None
    if isinstance(vix, str):
        vix = _cached(os.path.join(P["dir"], "vix_cache.json"), CFG["vix_ttl_sec"], fetch_vix)
    if news_items is None:
        news_items = _cached(os.path.join(P["dir"], "news_cache.json"), CFG["news_ttl_sec"], lambda: fetch_news_items(inst)) or []
    news = ai.analyze_news(news_items, now.timestamp())

    # ---- optional Claude review (cached per candle)
    llm_res = None
    if isinstance(llm, dict):
        llm_res = llm
    elif llm == "auto" and S.get("use_llm") and os.environ.get("ANTHROPIC_API_KEY"):
        snap = dict(instrument=icfg["name"], time=now_n.strftime("%H:%M"), price=float(d["Close"].iloc[-1]),
                    session=dict(change_pct=session.get("change_pct"), gap_pct=session.get("gap_pct")),
                    vix=vix, gift=gift, news_tone=news["tone"], events=news["events"],
                    chain=None if not ch else {k: ch[k] for k in ("pcr_near", "buildup", "support", "resistance", "max_pain", "dte", "straddle")})
        llm_res = _cached(os.path.join(P["dir"], "llm_cache.json"), CFG["llm_ttl_sec"],
                          lambda: ai.llm_review(snap, news["headlines"] + [i["title"] for i in news["items"][:6]]))
    if llm_res and llm_res.get("ok"):
        news = ai.analyze_news(news_items, now.timestamp(), llm=llm_res)

    # ---- safety blockers (not strategy: data quality, timing, daily risk limits)
    hist = read_json(P["history"], [])
    if ai.resolve_journal(hist, d):
        atomic_write_json(P["history"], hist[-500:], indent=2)
    blockers = []
    end_min = (candle_time + timedelta(minutes=CFG["candle_minutes"]))
    hm = (now_n.hour, now_n.minute)
    if not mkt_open:
        blockers.append("Market is closed")
    else:
        if hm < _hm(CFG["first_trade"]):
            blockers.append("First 10 minutes: price discovery still settling")
        if hm > _hm(CFG["last_trade"]):
            blockers.append("No new trades after 15:05")
        if candle_age > CFG["max_candle_age_min"]:
            blockers.append(f"Price data is {candle_age:.0f} min old")
    blockers += ai.today_guard(hist, now_n.strftime("%d-%m-%Y"), int(S["max_signals_day"]), int(S["stop_after_losses"]))

    # ---- option flow (OI / premium / IV velocity from recorded snapshots)
    flow = None
    if ch:
        try:
            flow = compute_flow(P["ticks"], ch, now_n)
        except Exception as e:
            print("Flow engine error:", type(e).__name__, e)

    # ---- the AI read + decision
    A = ai.analyze(d, now_n, chain=ch, gift=gift, news=news, vix=vix, sens=S["sensitivity"], blockers=blockers,
                   llm=llm_res, inst_name=icfg["name"], flow=flow)
    dec, plan, regime = A["decision"], A["plan"], A["regime"]
    px = float(d["Close"].iloc[-1])
    action = dec["action"]

    # ---- alert + journal
    prev_action = prev.get("last_action", "WAIT")
    last_alert_sig, last_alert_ts = prev.get("last_alert_signal"), prev.get("last_alert_ts", 0) or 0
    cooldown_ok = (now.timestamp() - last_alert_ts) >= int(S["alert_cooldown_min"]) * 60
    fire = action != "WAIT" and action != prev_action and (action != last_alert_sig or cooldown_ok)
    tg_sent = False
    if fire:
        lines = [f"{icfg['name']}: {action}", f"Confidence {dec['confidence']}% ({dec['grade']}) | edge {dec['ev']:+.2f}R | size x{dec['size_factor']}",
                 f"Market: {regime['label']} | {regime['vol_state']} volatility",
                 f"Spot {px:,.1f} | SL {plan['stoploss']:,.1f} | T1 {plan['target1']:,.1f} | T2 {plan['target2']:,.1f}"]
        if plan.get("option"):
            o = plan["option"]
            lines.append(f"ATM {o['type']} {o['strike']:,.0f} premium ~Rs {o['premium']:,.1f} (SL ~{o['sl_prem']:,.1f}, T1 ~{o['t1_prem']:,.1f})")
        lines.append(dec["summary"])
        lines.append(f"Time {now_n.strftime('%d-%m-%Y %H:%M:%S')} IST")
        tg_sent = send_telegram("\n".join(lines)) if send else False
        hist.append(dict(time=now_n.strftime("%d-%m-%Y %H:%M:%S"), candle_time=candle_time.strftime("%d-%m-%Y %H:%M:%S"),
                         signal=action, price=px, entry=px, stoploss=plan["stoploss"], target1=plan["target1"],
                         target2=plan["target2"], confidence=dec["confidence"], ev=dec["ev"], regime=regime["label"],
                         max_bars=ai.HORIZON, status="PENDING", telegram=tg_sent,
                         option=plan.get("option")))
        atomic_write_json(P["history"], hist[-500:], indent=2)
        last_alert_sig, last_alert_ts = action, now.timestamp()
    print(f"[{now_n:%H:%M:%S}] {inst}: {action} | conf {dec['confidence']} | edge {dec['ev']:+.2f}R | {regime['label']} | alert={'sent' if tg_sent else 'no'}")

    try:
        tradedb.sync(P["dir"], hist)
    except Exception as e:
        print("Trade DB error:", type(e).__name__, e)

    # ---- files for the dashboard
    a = A["aux"]
    out_df = d.join(a[["ema20", "ema50", "sess_mean", "atr"]])
    days_ = sorted(set(out_df.index.normalize()))
    if len(days_) > CFG["keep_days"]:
        out_df = out_df[out_df.index.normalize() >= days_[-CFG["keep_days"]]]
    tmp_csv = f"{P['market']}.tmp{os.getpid()}"
    out_df.to_csv(tmp_csv)
    os.replace(tmp_csv, P["market"])
    if chain_file:
        atomic_write_json(P["chain"], chain_file)
        try:
            record_option_ticks(chain_file, P, now_n)
        except Exception as e:
            print("Premium recorder error:", e)

    result = dict(schema=4, instrument=inst, name=icfg["name"], mode="full" if icfg["chain"] else "no-chain",
                  timestamp=now_n.strftime("%d-%m-%Y %H:%M:%S"), run_ts=now.timestamp(), market_open=mkt_open,
                  decision=dec, regime=regime, model=A["model"], context=A["context"],
                  news=news, plan={k: (v if k in ("side", "confirmed", "rr", "option", "max_bars") else clean(v)) for k, v in plan.items()},
                  spot_price=px, nse_spot=nse_spot, candle_time=candle_time.strftime("%d-%m-%Y %H:%M"),
                  candle_age_min=round(candle_age, 1), chain_age_min=None if chain_age is None else round(chain_age, 1),
                  chain_timestamp=chain_ts, chain_error=chain_err, chain=ch, session=session, gift=gift, vix=vix,
                  tech={k: clean(v) for k, v in A["tech"].items()}, llm=llm_res, flow=flow, settings=S,
                  last_action=action, last_alert_signal=last_alert_sig, last_alert_ts=last_alert_ts, agent_error=None)
    atomic_write_json(P["signals"], result, indent=2)
    return result


def write_error(msg, data_dir=None, inst="NIFTY"):
    P = get_paths(data_dir, inst)
    cur = read_json(P["signals"], {})
    cur["agent_error"] = msg
    cur["error_ts"] = datetime.now(IST).strftime("%d-%m-%Y %H:%M:%S")
    atomic_write_json(P["signals"], cur, indent=2)


def safe_run(inst="NIFTY", **kw):
    P = get_paths(kw.get("data_dir"), inst)
    if not acquire_lock(P["lock"]):
        print(f"{inst}: another run is in progress - skipped")
        return None
    try:
        return run_once(inst=inst, **kw)
    except Exception as e:
        traceback.print_exc()
        write_error(f"{type(e).__name__}: {e}", kw.get("data_dir"), inst)
        return None
    finally:
        release_lock(P["lock"])


def run_all(only=None, gift="auto", **kw):
    if isinstance(gift, str):
        gift = _cached(os.path.join(get_paths(kw.get("data_dir"), "NIFTY")["dir"], "gift_cache.json"), CFG["gift_ttl_sec"], fetch_gift)
    return {inst: safe_run(inst=inst, gift=gift, **kw) for inst in INSTRUMENTS if not only or inst == only}


# ----------------------------------------------------------------------------- demo data (offline)
def make_demo_candles(end, days=30, seed=7, start_price=24500.0, phi=0.12):
    rng = np.random.default_rng(seed)
    idx = []
    for day in pd.bdate_range(end=pd.Timestamp(end).normalize(), periods=days):
        idx += list(pd.date_range(day + pd.Timedelta(hours=9, minutes=15), day + pd.Timedelta(hours=15, minutes=25), freq="5min"))
    idx = pd.DatetimeIndex([i for i in idx if i <= pd.Timestamp(end)])
    n = len(idx)
    e = rng.normal(0, 0.0006, n)
    r = np.zeros(n)
    for i in range(1, n):
        r[i] = phi * r[i - 1] + e[i]
    close = start_price * np.exp(np.cumsum(r))
    open_ = np.concatenate([[start_price], close[:-1]])
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.0002, n)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.0002, n)))
    return pd.DataFrame(dict(Open=open_, High=high, Low=low, Close=close, Volume=0.0), index=idx.tz_localize("Asia/Kolkata"))


def make_demo_chain(spot, now, pcr_tilt=1.0, seed=3):
    rng = np.random.default_rng(seed)
    base = round(spot / 50) * 50
    expiries, d0 = [], pd.Timestamp(now).normalize()
    while len(expiries) < 3:
        d0 += pd.Timedelta(days=1)
        if d0.weekday() == 1:
            expiries.append(d0)
    data = []
    for e in expiries:
        ed = e.strftime("%d-%b-%Y")
        for k in range(base - 2000, base + 2001, 50):
            w = np.exp(-((k - spot) / 600) ** 2)
            tv = max(4.0, 140 * np.exp(-((k - spot) / 250) ** 2))
            ce_oi = int(rng.integers(2, 9) * 1e5 * (0.3 + w) * (1.6 if k > spot else 0.7))
            pe_oi = int(rng.integers(2, 9) * 1e5 * (0.3 + w) * (1.6 if k < spot else 0.7) * pcr_tilt)
            iv = round(12 + abs(k - spot) / 400, 2)
            mk = lambda oi, ltp: dict(strikePrice=k, expiryDate=ed, underlyingValue=spot, openInterest=oi,
                                      changeinOpenInterest=int(rng.normal(0, 4e4)), totalTradedVolume=int(oi * 0.4),
                                      impliedVolatility=iv, lastPrice=round(ltp, 2))
            data.append(dict(strikePrice=k, expiryDate=ed, CE=mk(ce_oi, max(spot - k, 0) + tv), PE=mk(pe_oi, max(k - spot, 0) + tv)))
    return dict(records=dict(timestamp=pd.Timestamp(now).strftime("%d-%b-%Y %H:%M:%S"), underlyingValue=spot, data=data))


DEMO_NEWS = [dict(title="Nifty ends higher as banks rally; FII inflows return", source="Demo", ts=None),
             dict(title="Sensex gains 300 points on strong global cues", source="Demo", ts=None),
             dict(title="RBI policy outcome due this week; markets cautious", source="Demo", ts=None)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", type=int, default=0, help="run every N seconds (min 15)")
    ap.add_argument("--demo", action="store_true", help="synthetic data, no internet needed (./demo_data)")
    ap.add_argument("--only", choices=list(INSTRUMENTS), help="run a single instrument")
    a = ap.parse_args()

    def once():
        if a.demo:
            now = datetime.now(IST)
            now = now.replace(hour=11, minute=2, second=0) if now.weekday() < 5 else (now - timedelta(days=now.weekday() - 4)).replace(hour=11, minute=2)
            nn = now.replace(tzinfo=None)
            ddir = os.path.join(BASE, "demo_data")
            for inst, start, seed in (("NIFTY", 24500.0, 7), ("SENSEX", 80500.0, 11)):
                if a.only and inst != a.only:
                    continue
                c = make_demo_candles(nn, start_price=start, seed=seed)
                spot = float(c["Close"].iloc[-1])
                safe_run(inst=inst, candles=c, chain_raw=make_demo_chain(spot, nn) if inst == "NIFTY" else None,
                         news_items=DEMO_NEWS, now=now, data_dir=ddir, send=False, llm=None,
                         gift=dict(price=24550.0, change=38.5, change_pct=0.16, expiry="26NOV2026", time="demo") if inst == "NIFTY" else None,
                         vix=dict(last=13.8, prev=14.1, change_pct=-2.1))
            print(f"Demo ready. Dashboard: NIFTY_DATA_DIR={ddir} streamlit run dashboard.py")
            return
        run_all(only=a.only)

    if a.loop:
        while True:
            try:
                once()
            except Exception:
                traceback.print_exc()
            time.sleep(max(a.loop, 15))
    else:
        once()


if __name__ == "__main__":
    main()

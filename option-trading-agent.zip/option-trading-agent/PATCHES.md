# Patches (V4.1) - apply in this order

New files (put next to final_agent.py): greeks.py, database.py, flow_engine.py, backtest.py

---------------------------------------------------------------------------
## A. dashboard.py  (Settings not loading fix + new panels)
---------------------------------------------------------------------------

### A1. Add after `import streamlit.components.v1 as components`
```python
import inspect

_STRETCH_NEW = "width" in inspect.signature(st.button).parameters


def stretch():
    """Works on old Streamlit (use_container_width) and new Streamlit (width='stretch')."""
    return {"width": "stretch"} if _STRETCH_NEW else {"use_container_width": True}
```

### A2. REPLACE
```python
top_l, top_m, top_r = st.columns([1.2, 3.2, 0.9])
with top_r, st.popover("Settings", use_container_width=True):
    st.markdown("**Display**")
```
WITH
```python
top_l, top_m, top_r = st.columns([1.2, 3.2, 0.9])
force = top_r.button("Run agent now", key="run_now", **stretch())
settings_box = st.container()
with settings_box, st.expander("Settings", expanded=False):
    st.markdown("**Display**")
```

### A3. REPLACE this line (end of the settings block)
```python
    force = st.button("Run agent now", use_container_width=True)
```
WITH
```python
    st.caption("Changes are saved automatically.")
```

### A4. In the CSS block REPLACE
```python
[data-testid="stPopoverBody"] {{ background:{PANEL}; border:1px solid {BORDER}; min-width:340px; }}
```
WITH
```python
[data-testid="stExpander"] {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:10px; }}
[data-testid="stExpander"] summary p, [data-testid="stExpander"] summary {{ color:{TEXT} !important; }}
[data-testid="stPopoverBody"] {{ background:{PANEL}; border:1px solid {BORDER}; min-width:340px; }}
```

### A5. Trade plan: INSERT just BEFORE the line
`        rows += kv("Max hold", f"{plan['max_bars']} candles (1 hour)") + kv("Position size", ...`
```python
        if o and o.get("gamma") is not None:
            rows += (kv("Delta / Gamma", f"{o['delta']:.2f} / {o['gamma']:.5f}")
                     + kv("Theta per day / Vega per 1% IV", f"{o['theta']:,.1f} / {o['vega']:,.1f} (premium pts)"))
```

### A6. Option chain tab: INSERT right after the line
`            col.markdown(stat(l_, v_, s_, c_), unsafe_allow_html=True)`   (8 spaces of indent for the new block)
```python
        fl = J.get("flow")
        if fl and fl.get("ok"):
            iv_c = DOWN if fl["iv_state"] == "Falling" else UP if fl["iv_state"] == "Rising" else MUTED
            g1, g2, g3, g4 = st.columns(4)
            g1.markdown(stat(f"OI velocity ({fl['window_min']:.0f} min)", f"{fl['oi_vel_pct']:+.2f}%", "puts minus calls, % of OI", UP if fl["oi_vel_pct"] > 0 else DOWN), unsafe_allow_html=True)
            g2.markdown(stat("ATM call / put premium", f"{fl['ce_prem_pct']:+.1f}% / {fl['pe_prem_pct']:+.1f}%", "change in window", TEXT), unsafe_allow_html=True)
            g3.markdown(stat("IV velocity", f"{fl['iv_vel']:+.2f} pts", f"per 15 min, {fl['iv_state'].lower()}", iv_c), unsafe_allow_html=True)
            g4.markdown(stat("Flow snapshots", fl["snapshots"], "recorded by the agent", MUTED), unsafe_allow_html=True)
        elif fl:
            st.markdown(f'<div class="muted txt" style="margin-top:8px">Option flow: {esc(fl.get("reason", ""))}</div>', unsafe_allow_html=True)
```

### A7. Journal tab: INSERT right after the `j5.markdown(...)` line (4 spaces of indent)
```python
    pc1, pc2, pc3 = st.columns(3)
    paper_cap = pc1.number_input("Paper capital (Rs)", min_value=1000, value=100000, step=5000, key=f"pcap_{INST}")
    paper_risk = pc2.selectbox("Risk per trade (%)", [0.5, 1.0, 1.5, 2.0], index=1, key=f"prisk_{INST}")
    paper_pnl = stt["total_r"] * paper_cap * paper_risk / 100
    pc3.markdown(stat("Paper P&L", f"Rs {paper_pnl:+,.0f}", f"{paper_pnl / paper_cap * 100:+.2f}% of capital (R x risk)", UP if paper_pnl >= 0 else DOWN), unsafe_allow_html=True)
    try:
        import database as tradedb
        reg_rows = tradedb.by_regime(P["dir"])
    except Exception:
        reg_rows = []
    if reg_rows:
        body = "".join(f'<tr><td>{esc(r["regime"])}</td><td class="num">{r["n"]}</td><td class="num">{r["win_rate"]:.0f}%</td>'
                       f'<td class="num" style="color:{UP if r["avg_r"] > 0 else DOWN}">{r["avg_r"]:+.2f}R</td></tr>' for r in reg_rows)
        st.markdown(f'<div class="wrap" style="max-height:220px;margin-top:10px"><table class="t"><tr><th>Market regime</th><th>Closed</th><th>Win rate</th><th>Avg result</th></tr>{body}</table></div>', unsafe_allow_html=True)
```

---------------------------------------------------------------------------
## B. ai_engine.py
---------------------------------------------------------------------------

### B1. In build_plan(), right AFTER the `plan["option"] = dict(... expiry=chain.get("expiry"))` statement (same indent as that statement)
```python
            try:
                from greeks import bs_greeks
                g = bs_greeks(px, chain["atm"], chain.get("dte"), iv, side == "CALL")
                plan["option"].update(gamma=g["gamma"], theta=g["theta"], vega=g["vega"])
            except Exception:
                pass
```

### B2. external_tilt signature: REPLACE
`def external_tilt(spot, atr, chain, gift, news, now):`
WITH
`def external_tilt(spot, atr, chain, gift, news, now, flow=None):`

and INSERT just BEFORE the line `    sw = sum(p["weight"] for p in parts)`
```python
    if flow and flow.get("ok"):
        for p in flow.get("parts", []):
            add(p["name"], p["detail"], p["value"], p["weight"])
```

### B3. analyze(): REPLACE the signature
```python
def analyze(d, now_n, chain=None, gift=None, news=None, vix=None, sens="Balanced", blockers=None, llm=None,
            inst_name="Index", min_rows=300):
```
WITH
```python
def analyze(d, now_n, chain=None, gift=None, news=None, vix=None, sens="Balanced", blockers=None, llm=None,
            inst_name="Index", min_rows=300, flow=None):
```
REPLACE `    tilt, parts = external_tilt(px, atr, chain, gift, news, now_n)`
WITH    `    tilt, parts = external_tilt(px, atr, chain, gift, news, now_n, flow)`

INSERT right AFTER the `dec = decide(... dte=(chain or {}).get("dte"))` statement:
```python
    if flow and flow.get("iv_crush") and dec["action"] != "WAIT":
        dec["size_factor"] = round(dec["size_factor"] * 0.75, 2)
        dec["notes"].append("Implied volatility is falling fast: premiums can shrink even if direction is right. Size reduced.")
```

---------------------------------------------------------------------------
## C. final_agent.py
---------------------------------------------------------------------------

### C1. After `import ai_engine as ai`
```python
import database as tradedb
from flow_engine import compute_flow
```

### C2. INSERT just BEFORE the comment line `    # ---- the AI read + decision`
```python
    flow = None
    if ch:
        try:
            flow = compute_flow(P["ticks"], ch, now_n)
        except Exception as e:
            print("Flow engine error:", type(e).__name__, e)

```

### C3. REPLACE `                   llm=llm_res, inst_name=icfg["name"])`
WITH `                   llm=llm_res, inst_name=icfg["name"], flow=flow)`

### C4. INSERT just BEFORE the comment line `    # ---- files for the dashboard`
```python
    try:
        tradedb.sync(P["dir"], hist)
    except Exception as e:
        print("Trade DB error:", type(e).__name__, e)

```

### C5. In the `result = dict(...)` REPLACE `llm=llm_res, settings=S,`
WITH `llm=llm_res, flow=flow, settings=S,`

---------------------------------------------------------------------------
## Test order
1. `python final_agent.py --demo`   (must print "Demo ready")
2. `NIFTY_DATA_DIR=demo_data streamlit run dashboard.py`
3. `python backtest.py`  (real Yahoo data)

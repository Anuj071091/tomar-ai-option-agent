"""flow_engine.py - OI velocity, option-premium momentum and IV velocity from the agent's own recorded snapshots.

Reads option_ticks.csv (written by final_agent.record_option_ticks) and compares the latest snapshot with one
~15 minutes earlier, around the ATM strikes of the chosen expiry. Output feeds ai_engine.external_tilt as small,
bounded inputs (it can never move the edge by more than TILT_R), and the dashboard shows the raw numbers.
"""
import io
import os

import numpy as np
import pandas as pd

COLS = ["ts", "expiry", "strike", "type", "ltp", "oi", "vol", "iv"]


def _clip(x, lo=-1.0, hi=1.0):
    return float(max(lo, min(hi, x)))


def _read_tail(path, max_bytes=4_000_000):
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        if size > max_bytes:
            f.seek(size - max_bytes)
            f.readline()                                   # drop the partial first line
            txt, kw = f.read().decode("utf-8", "ignore"), dict(names=COLS, header=None)
        else:
            txt, kw = f.read().decode("utf-8", "ignore"), {}
    df = pd.read_csv(io.StringIO(txt), **kw)
    df["ts"] = pd.to_datetime(df["ts"], errors="coerce")
    for c in ("strike", "ltp", "oi", "iv"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.dropna(subset=["ts", "strike"])


def compute_flow(ticks_path, chain, now_n, window_min=15, near_pts=100, min_gap_min=5):
    """chain = nearest-expiry stats dict (needs 'expiry' and 'atm'). Returns dict with ok True/False."""
    if not chain or not os.path.exists(ticks_path):
        return dict(ok=False, reason="no recorded option snapshots yet")
    df = _read_tail(ticks_path)
    df = df[(df["expiry"] == chain["expiry"]) & ((df["strike"] - chain["atm"]).abs() <= near_pts)]
    df = df[(df["ts"].dt.date == now_n.date()) & (df["ts"] <= pd.Timestamp(now_n))]
    stamps = sorted(df["ts"].unique())
    if len(stamps) < 2:
        return dict(ok=False, reason="building history: fewer than 2 snapshots today")
    last = pd.Timestamp(stamps[-1])
    cands = [pd.Timestamp(s) for s in stamps if (last - pd.Timestamp(s)).total_seconds() >= min_gap_min * 60]
    if not cands:
        return dict(ok=False, reason=f"building history: need {min_gap_min}+ minutes of snapshots")
    target = last - pd.Timedelta(minutes=window_min)
    base_ts = min(cands, key=lambda s: abs((s - target).total_seconds()))
    window = (last - base_ts).total_seconds() / 60

    def side(typ):
        a = df[(df["ts"] == base_ts) & (df["type"] == typ)].set_index("strike")
        b = df[(df["ts"] == last) & (df["type"] == typ)].set_index("strike")
        j = a.join(b, lsuffix="0", rsuffix="1", how="inner")
        if j.empty:
            return None
        ok_p = (j["ltp0"] > 0) & (j["ltp1"] > 0)
        ok_i = (j["iv0"] > 0) & (j["iv1"] > 0)
        return dict(oi_chg=float((j["oi1"] - j["oi0"]).sum()), oi_base=float(j["oi0"].sum()),
                    prem_pct=float(((j["ltp1"] - j["ltp0"]) / j["ltp0"] * 100)[ok_p].median()) if ok_p.any() else 0.0,
                    iv_chg=float((j["iv1"] - j["iv0"])[ok_i].mean()) if ok_i.any() else 0.0)

    ce, pe = side("CE"), side("PE")
    if ce is None or pe is None:
        return dict(ok=False, reason="snapshots do not share strikes")
    oi_vel = (pe["oi_chg"] - ce["oi_chg"]) / max(pe["oi_base"] + ce["oi_base"], 1.0) * 100      # % of base OI
    prem_gap = ce["prem_pct"] - pe["prem_pct"]
    iv_vel = (ce["iv_chg"] + pe["iv_chg"]) / 2 * (15.0 / max(window, 1.0))                      # IV points per 15 min
    iv_state = "Rising" if iv_vel >= 0.4 else "Falling" if iv_vel <= -0.4 else "Stable"
    parts = [
        dict(name="OI velocity (ATM, recent)", detail=f"puts minus calls {oi_vel:+.2f}% of OI in {window:.0f} min",
             value=_clip(oi_vel / 1.5), weight=0.20),
        dict(name="Option premium momentum", detail=f"CE {ce['prem_pct']:+.1f}% vs PE {pe['prem_pct']:+.1f}% in {window:.0f} min",
             value=_clip(prem_gap / 8), weight=0.10),
    ]
    return dict(ok=True, window_min=round(window, 1), snapshots=len(stamps), oi_vel_pct=round(oi_vel, 3),
                ce_oi_chg=int(ce["oi_chg"]), pe_oi_chg=int(pe["oi_chg"]), ce_prem_pct=round(ce["prem_pct"], 2),
                pe_prem_pct=round(pe["prem_pct"], 2), iv_vel=round(iv_vel, 3), iv_state=iv_state,
                iv_crush=bool(iv_vel <= -0.6), parts=parts)

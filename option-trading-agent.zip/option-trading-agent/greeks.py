"""greeks.py - Black-Scholes greeks in pure Python (no py_vollib / scipy needed).

bs_greeks(spot, strike, dte, iv_pct, is_call) -> dict(delta, gamma, theta, vega)
  delta : signed (call +, put -)
  gamma : change of delta per 1 index point
  theta : premium lost per calendar day (negative number, in premium points)
  vega  : premium change per +1 percentage point of IV (premium points)
Uses the same conventions as ai_engine.bs_delta (r = 7%, minimum time 0.15 day).
"""
import math


def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _npdf(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def bs_greeks(spot, strike, dte, iv_pct, is_call=True, r=0.07):
    zero = dict(delta=0.0, gamma=0.0, theta=0.0, vega=0.0)
    try:
        if not (spot > 0 and strike > 0 and iv_pct and iv_pct > 0 and dte is not None):
            return zero
        T = max(float(dte), 0.15) / 365.0
        s = float(iv_pct) / 100.0
        sq = s * math.sqrt(T)
        d1 = (math.log(spot / strike) + (r + s * s / 2) * T) / sq
        d2 = d1 - sq
        pdf = _npdf(d1)
        disc = strike * math.exp(-r * T)
        if is_call:
            delta = _ncdf(d1)
            theta = -(spot * pdf * s) / (2 * math.sqrt(T)) - r * disc * _ncdf(d2)
        else:
            delta = _ncdf(d1) - 1
            theta = -(spot * pdf * s) / (2 * math.sqrt(T)) + r * disc * _ncdf(-d2)
        return dict(delta=round(delta, 4), gamma=round(pdf / (spot * sq), 6),
                    theta=round(theta / 365.0, 3), vega=round(spot * pdf * math.sqrt(T) / 100.0, 3))
    except Exception:
        return zero

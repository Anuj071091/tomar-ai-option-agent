# NIFTY Master Option Agent (starter)

**Educational / paper-trading only.** This project does not place broker orders and does not guarantee profitable signals.

## Files
- `final_agent.py`: downloads NIFTY candles, attempts to fetch the NIFTY option chain, calculates indicators and writes `signals.json`.
- `dashboard.py`: Streamlit dashboard that reads `signals.json`.
- `requirements.txt`: Python dependencies.

## Windows setup (PowerShell)
1. Install Python 3.11 or 3.12 (recommended for package compatibility) and Git.
2. Open PowerShell in this folder.
3. Create a virtual environment:
   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
   If `py -3.12` is not available, install Python 3.12 first. Python 3.14 may have compatibility gaps with some packages.
4. Test the agent once:
   ```powershell
   python final_agent.py --once
   ```
   Check `signals.json` and `final_agent.log`. NSE scraping can fail/rate-limit; on failure the agent deliberately writes `NO TRADE` with `data_status=UNAVAILABLE`.
5. Start the continuous agent in Terminal 1:
   ```powershell
   python final_agent.py
   ```
6. Open a second PowerShell terminal in the same folder, activate the venv again, and start dashboard:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   streamlit run dashboard.py
   ```
7. On the same PC open `http://localhost:8501`.

## Access from phone on the same Wi-Fi
1. Keep the PC and phone connected to the same trusted Wi-Fi.
2. Find PC IPv4 address:
   ```powershell
   ipconfig
   ```
   Find the Wi-Fi adapter's `IPv4 Address`, e.g. `192.168.1.25`.
3. Stop the dashboard with Ctrl+C, then restart:
   ```powershell
   streamlit run dashboard.py --server.address 0.0.0.0 --server.port 8501
   ```
4. On your phone browser open `http://192.168.1.25:8501` (replace with your PC's actual IPv4).
5. If Windows Firewall prompts, allow Python/Streamlit only on **Private networks**. Do not expose port 8501 directly to the public internet. This LAN method works only while PC and dashboard are running and usually only on the same Wi-Fi.

## Git / GitHub
From the project folder:
```powershell
git status
git add final_agent.py dashboard.py requirements.txt README.md
git commit -m "Add fixed NIFTY dashboard and signal agent"
git branch -M main
git remote -v
```
If the remote is not set yet, use the HTTPS URL of your own GitHub repository:
```powershell
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
If `origin` already exists, don't add it again; check `git remote -v` and use `git remote set-url origin YOUR-REPOSITORY-URL` only if needed.

Do **not** commit `signals.json`, `.venv/`, logs, API keys, Telegram bot tokens, or personal credentials. Add a `.gitignore` file with:
```gitignore
.venv/
__pycache__/
*.py[cod]
signals.json
signals.tmp
signals.tmp.json
final_agent.log
.env
```

## Important limitations
- Yahoo Finance intraday data may be delayed, incomplete, or unavailable. It is not a guaranteed real-time execution feed.
- `nsepython` is a third-party NSE scraper and can stop working or be rate-limited. If it fails, investigate the error rather than acting on stale values.
- PCR and max-OI strikes are context only, not standalone trade signals.
- The `signal_strength` is a rule score, not a probability of winning.
- ATR levels shown are for the underlying NIFTY index, not option-premium order prices.
- Backtest with realistic option premium history, brokerage, taxes, slippage, and out-of-sample data before considering live use.

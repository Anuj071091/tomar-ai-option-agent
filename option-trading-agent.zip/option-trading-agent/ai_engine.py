"""ai_engine.py - AI market reader for NIFTY / SENSEX option buying.

No fixed strategy and no preset rules. The engine:
  1. turns the last ~30 days of 5-minute candles into 14 unit-free features,
  2. labels every past candle with what a trade would really have earned (triple barrier: +1.5 ATR target,
     -1.0 ATR stop, 12 candles max) - separately for CALL (long) and PUT (short),
  3. trains a ridge-regression model on those outcomes and TESTS it on unseen data (walk-forward),
  4. trusts the model only as much as that unseen-data test supports,
  5. adds context (option chain, GIFT Nifty, news) as a small, bounded tilt,
  6. reads the market (regime, multi-timeframe trend, volatility, day structure) in plain language,
  7. decides BUY CALL / BUY PUT / WAIT from expected edge (in R, after costs).
Optional: a Claude review (needs ANTHROPIC_API_KEY) can read the news/context and veto a trade.
Pure functions, no file or network access except llm_review().
"""
import json
import math
import os
import re
from datetime import datetime

import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------- constants
HORIZON = 12            # max candles a trade is allowed to live (12 x 5m = 1 hour)
TARGET_ATR = 1.5        # target distance (ATR) -> +1.5R
STOP_ATR = 1.0          # stop distance (ATR)   -> -1.0R
T2_ATR = 2.5
COST_R = 0.04           # spread + theta + brokerage allowance, in R
TILT_R = 0.10           # max edge (R) the external context (chain/news/gift) may add or remove
FEATURES = ["r3", "r6", "r12", "r24", "ema_gap", "ema_dist", "macd_h", "rsi", "sess_dev", "day_pos",
            "persist", "htf", "vol_ratio", "pd_pos"]
FEATURE_LABELS = {
    "r3": "15-min momentum", "r6": "30-min momentum", "r12": "1-hour momentum", "r24": "2-hour momentum",
    "ema_gap": "Fast vs slow trend (5m)", "ema_dist": "Distance from 20-EMA", "macd_h": "MACD histogram",
    "rsi": "RSI", "sess_dev": "Price vs session average", "day_pos": "Position in day range",
    "persist": "Trend persistence", "htf": "15-min trend", "vol_ratio": "Volatility vs normal",
    "pd_pos": "Position vs yesterday's range",
}
SENSITIVITY = {
    "Conservative": dict(ev_min=0.10, floor=0.00, margin=0.06),
    "Balanced": dict(ev_min=0.06, floor=0.25, margin=0.04),
    "Active": dict(ev_min=0.035, floor=0.50, margin=0.03),
}


def clip(x, lo=-1.0, hi=1.0):
    return float(max(lo, min(hi, x)))


# ----------------------------------------------------------------------------- indicators
def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def true_range(h, l, c):
    pc = c.shift(1)
    return pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)


def atr_calc(h, l, c, n=14):
    return true_range(h, l, c).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def rsi_calc(c, n=14):
    d = c.diff()
    gain = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    loss = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rs = gain / loss.replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    return out.where(loss != 0, 100.0).where(gain.notna())


def adx_calc(h, l, c, n=14):
    up, dn = h.diff(), -l.diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=h.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=h.index)
    atr = atr_calc(h, l, c, n)
    pdi = 100 * pdm.ewm(alpha=1 / n, adjust=False, min_periods=n).mean() / atr
    mdi = 100 * mdm.ewm(alpha=1 / n, adjust=False, min_periods=n).mean() / atr
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def _groups(d):
    return d.index.normalize().values


# ----------------------------------------------------------------------------- features
def build_features(d):
    """d: closed 5m candles (naive IST index; Open/High/Low/Close/Volume). Returns (features, aux)."""
    c, h, l = d["Close"].astype(float), d["High"].astype(float), d["Low"].astype(float)
    atr = atr_calc(h, l, c, 14)
    a = atr.replace(0, np.nan)
    f = pd.DataFrame(index=d.index)
    for n in (3, 6, 12, 24):
        f[f"r{n}"] = (c - c.shift(n)) / (a * math.sqrt(n))
    e20, e50 = ema(c, 20), ema(c, 50)
    f["ema_gap"] = (e20 - e50) / a
    f["ema_dist"] = (c - e20) / a
    macd = ema(c, 12) - ema(c, 26)
    f["macd_h"] = (macd - ema(macd, 9)) / a
    f["rsi"] = (rsi_calc(c, 14) - 50) / 25

    g = _groups(d)
    tp = (h + l + c) / 3
    grp = tp.groupby(g)
    sess_mean = grp.cumsum() / (grp.cumcount() + 1)
    f["sess_dev"] = (c - sess_mean) / a
    day_hi, day_lo = h.groupby(g).cummax(), l.groupby(g).cummin()
    rng = day_hi - day_lo
    pos = ((c - day_lo) / rng.replace(0, np.nan)) * 2 - 1
    pos[grp.cumcount().values < 3] = 0.0
    f["day_pos"] = pos.fillna(0.0)

    net24 = c - c.shift(24)
    er = net24.abs() / c.diff().abs().rolling(24).sum().replace(0, np.nan)
    f["persist"] = er * np.sign(net24)

    ohlc = d[["Open", "High", "Low", "Close"]].astype(float)
    o15 = ohlc.resample("15min").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last"}).dropna()
    a15 = atr_calc(o15["High"], o15["Low"], o15["Close"], 14).replace(0, np.nan)
    gap15 = ((ema(o15["Close"], 20) - ema(o15["Close"], 50)) / a15).shift(1)      # last COMPLETED 15m bar only
    f["htf"] = gap15.reindex(d.index.floor("15min")).values

    med = atr.rolling(375, min_periods=100).median()
    f["vol_ratio"] = np.log(atr / med)

    day = pd.Series(d.index.normalize(), index=d.index)
    dh, dl = h.groupby(g).max(), l.groupby(g).min()
    ph = day.map(pd.Series(dh.values, index=pd.DatetimeIndex(dh.index)).shift(1))
    pl = day.map(pd.Series(dl.values, index=pd.DatetimeIndex(dl.index)).shift(1))
    f["pd_pos"] = ((c - pl) / (ph - pl).replace(0, np.nan)) * 2 - 1

    f = f.replace([np.inf, -np.inf], np.nan)
    f[["pd_pos"]] = f[["pd_pos"]].clip(-2, 2)
    other = [x for x in FEATURES if x != "pd_pos"]
    f[other] = f[other].clip(-3, 3)
    aux = pd.DataFrame({"atr": atr, "ema20": e20, "ema50": e50, "sess_mean": sess_mean}, index=d.index)
    return f[FEATURES], aux


# ----------------------------------------------------------------------------- labels (triple barrier, per direction)
def triple_barrier(d, atr, horizon=HORIZON, up=TARGET_ATR, dn=STOP_ATR):
    """R outcome of a CALL (long) and a PUT (short) opened at each candle close. Units: R (stop = -1R).
    Windows never cross a day boundary; windows cut short by the END OF DATA are skipped (outcome unknown)."""
    c, h, l = d["Close"].values.astype(float), d["High"].values.astype(float), d["Low"].values.astype(float)
    day = d.index.normalize().values.astype("datetime64[D]").astype(np.int64)
    n = len(c)
    rl, rs = np.full(n, np.nan), np.full(n, np.nan)
    for i in range(n - 1):
        a = atr[i]
        if not (a > 0):
            continue
        j_end = i
        while j_end < min(i + horizon, n - 1) and day[j_end + 1] == day[i]:
            j_end += 1
        if j_end == n - 1 and j_end - i < horizon:
            continue                                  # future not fully known yet
        if j_end - i < 3:
            continue
        for sign, out in ((1, rl), (-1, rs)):
            tgt, stp = c[i] + sign * up * a, c[i] - sign * dn * a
            r = None
            for j in range(i + 1, j_end + 1):
                hit_stop = (l[j] <= stp) if sign == 1 else (h[j] >= stp)
                hit_tgt = (h[j] >= tgt) if sign == 1 else (l[j] <= tgt)
                if hit_stop:                          # stop first (also when both inside one candle: conservative)
                    r = -dn / dn
                    break
                if hit_tgt:
                    r = up / dn
                    break
            if r is None:
                r = clip(sign * (c[j_end] - c[i]) / (a * dn), -1.0, up / dn)
            out[i] = r
    return rl, rs


# ----------------------------------------------------------------------------- ridge model
def ridge_fit(X, y, lam):
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = (X - mu) / sd
    ym = float(y.mean())
    beta = np.linalg.solve(Z.T @ Z + lam * np.eye(Z.shape[1]), Z.T @ (y - ym))
    return dict(mu=mu, sd=sd, beta=beta, ym=ym)


def ridge_edge(m, X):
    """Feature-driven expected R (intercept removed: market drift of the sample is NOT an edge)."""
    return ((X - m["mu"]) / m["sd"]) @ m["beta"]


def train_models(f, rl, rs, min_rows=300):
    X = f[FEATURES].values.astype(float)
    ok = np.isfinite(X).all(1) & np.isfinite(rl) & np.isfinite(rs)
    idx = np.where(ok)[0]
    out = dict(status="ok", n_train=int(len(idx)), n_test=0, ic=0.0, ic_adj=0.0, rel=0.0, top_mean_r=None,
               top_n=0, base_r=None, models=None, note="")
    if len(idx) < min_rows:
        out.update(status="insufficient", note=f"Only {len(idx)} labelled candles (need {min_rows}+). Model stays out of the decision.")
        return out
    cut = int(len(idx) * 0.65)
    tr = idx[:cut]
    te = idx[idx > idx[cut - 1] + HORIZON]            # embargo: no label overlap between train and test
    lam = 0.3 * len(tr)
    if len(te) >= 60:
        ml, ms = ridge_fit(X[tr], rl[tr], lam), ridge_fit(X[tr], rs[tr], lam)
        pl, ps = ridge_edge(ml, X[te]), ridge_edge(ms, X[te])
        pred, real = np.r_[pl, ps], np.r_[rl[te], rs[te]]
        if pred.std() > 1e-9 and real.std() > 1e-9:
            ic = float(np.corrcoef(pred, real)[0, 1])
        else:
            ic = 0.0
        se = 1 / math.sqrt(len(te))
        ic_adj = ic - se
        thr = float(np.quantile(np.r_[ridge_edge(ml, X[tr]), ridge_edge(ms, X[tr])], 0.8))
        top = pred >= thr
        out.update(n_test=int(len(te)), ic=round(ic, 4), ic_adj=round(ic_adj, 4),
                   rel=round(clip(ic_adj / 0.06, 0.0, 1.0), 3),
                   top_mean_r=(round(float(real[top].mean()), 3) if top.sum() >= 20 else None),
                   top_n=int(top.sum()), base_r=round(float(real.mean()), 3))
    else:
        out["note"] = "Not enough unseen data to validate the model yet."
    out["models"] = (ridge_fit(X[idx], rl[idx], 0.3 * len(idx)), ridge_fit(X[idx], rs[idx], 0.3 * len(idx)))
    return out


def predict_latest(M, f):
    x = f[FEATURES].iloc[-1].values.astype(float)
    if M.get("models") is None or not np.isfinite(x).all():
        return None
    ml, ms = M["models"]
    X = x.reshape(1, -1)
    z_l, z_s = (x - ml["mu"]) / ml["sd"], (x - ms["mu"]) / ms["sd"]
    return dict(ev_long=float(ridge_edge(ml, X)[0]), ev_short=float(ridge_edge(ms, X)[0]),
                contrib_long=dict(zip(FEATURES, (z_l * ml["beta"]).tolist())),
                contrib_short=dict(zip(FEATURES, (z_s * ms["beta"]).tolist())))


# ----------------------------------------------------------------------------- market reading
def _vote(close, fast, slow):
    if len(close) < slow + 2:
        return 0.0
    ef, es = ema(close, fast).iloc[-1], ema(close, slow).iloc[-1]
    px = close.iloc[-1]
    if ef > es:
        return 1.0 if px > ef else 0.5
    return -1.0 if px < ef else -0.5


def session_phase(minute_of_day):
    if minute_of_day < 9 * 60 + 30:
        return "Opening"
    if minute_of_day < 11 * 60 + 30:
        return "Morning"
    if minute_of_day < 13 * 60 + 30:
        return "Midday"
    if minute_of_day < 14 * 60 + 45:
        return "Afternoon"
    return "Closing"


def read_market(d, aux, chain=None, vix=None, inst_name="Index"):
    c, h, l = d["Close"].astype(float), d["High"].astype(float), d["Low"].astype(float)
    atr = float(aux["atr"].iloc[-1])
    px = float(c.iloc[-1])
    n = len(c)
    net24 = float((c.iloc[-1] - c.iloc[max(n - 25, 0)]) / atr) if atr > 0 else 0.0
    path = float(c.diff().abs().iloc[-24:].sum())
    er = float(abs(c.iloc[-1] - c.iloc[max(n - 25, 0)]) / path) if path > 0 else 0.0
    med = float(aux["atr"].iloc[-375:].median())
    ratio = atr / med if med > 0 else 1.0
    adx = float(adx_calc(h, l, c).iloc[-1])

    v5 = _vote(c, 20, 50)
    c15 = c.resample("15min").last().dropna()
    c60 = c.resample("60min", offset="15min").last().dropna()
    v15, v60 = _vote(c15, 20, 50), _vote(c60, 9, 21)
    mtf = dict(m5=v5, m15=v15, m60=v60)
    agree = (v5 + v15 + v60)

    if ratio >= 1.45 and er < 0.35:
        label, tone = "Volatile / whipsaw", "warn"
    elif er >= 0.30 and abs(net24) >= 1.5:
        label, tone = ("Trending up", "bull") if net24 > 0 else ("Trending down", "bear")
    elif er < 0.22:
        label, tone = "Range-bound", "warn"
    elif net24 > 0:
        label, tone = "Drifting up", "bull"
    else:
        label, tone = "Drifting down", "bear"
    vol_state = "Expanding" if ratio >= 1.25 else "Compressed" if ratio <= 0.75 else "Normal"

    last_day = d.index.normalize()[-1]
    today = d[d.index.normalize() == last_day]
    prev = d[d.index.normalize() < last_day]
    hi, lo = float(today["High"].max()), float(today["Low"].min())
    day_open = float(today["Open"].iloc[0])
    avg_rng = None
    if len(prev):
        pr = prev.groupby(prev.index.normalize()).agg({"High": "max", "Low": "min"})
        avg_rng = float((pr["High"] - pr["Low"]).tail(5).mean())
    range_used = (hi - lo) / avg_rng if avg_rng else None
    pdh = pdl = None
    if len(prev):
        pday = prev[prev.index.normalize() == prev.index.normalize()[-1]]
        pdh, pdl = float(pday["High"].max()), float(pday["Low"].min())
    orb = None
    if len(today) >= 3:
        orh, orl = float(today["High"].iloc[:3].max()), float(today["Low"].iloc[:3].min())
        state = "above" if px > orh else "below" if px < orl else "inside"
        orb = dict(high=orh, low=orl, state=state)
    end = d.index[-1] + pd.Timedelta(minutes=5)
    phase = session_phase(end.hour * 60 + end.minute)
    straddle = (chain or {}).get("straddle")
    exp_used = ((hi - lo) / straddle) if straddle else None
    sess_dev = float((px - aux["sess_mean"].iloc[-1]) / atr) if atr > 0 else 0.0

    arrows = {k: ("up" if v > 0 else "down" if v < 0 else "flat") for k, v in mtf.items()}
    parts = []
    if label.startswith("Trending") or label.startswith("Drifting"):
        parts.append(f"{inst_name} is {label.lower()} (efficiency {er:.2f}, {net24:+.1f} ATR over 2 hours).")
    elif label.startswith("Range"):
        parts.append(f"{inst_name} is moving sideways: lots of movement but little net progress (efficiency {er:.2f}). Breakout trades fail often in this state.")
    else:
        parts.append(f"{inst_name} is volatile and whipsawing: candles are {ratio:.1f}x their normal size with no clean direction.")
    if abs(agree) >= 2.5:
        parts.append("5m, 15m and 60m trends agree " + ("bullish." if agree > 0 else "bearish."))
    elif abs(agree) >= 1.0:
        parts.append("Timeframes lean " + ("bullish" if agree > 0 else "bearish") + " but do not fully agree.")
    else:
        parts.append("Timeframes disagree, so there is no clear higher-timeframe backing.")
    if abs(sess_dev) >= 0.6:
        parts.append(f"Price is {abs(sess_dev):.1f} ATR {'above' if sess_dev > 0 else 'below'} the session average" +
                     (" (stretched, pullback risk)." if abs(sess_dev) >= 1.8 else "."))
    if range_used is not None:
        parts.append(f"Today's range is {range_used * 100:.0f}% of the recent average daily range" +
                     (" (most of the day's move may already be done)." if range_used >= 1.1 else "."))
    if exp_used is not None and exp_used >= 1.0:
        parts.append(f"Day range has already used {exp_used:.1f}x the option-implied move, so premiums are rich.")
    if vix and vix.get("last"):
        parts.append(f"India VIX {vix['last']:.1f} ({vix.get('change_pct', 0):+.1f}%).")

    return dict(label=label, tone=tone, er=round(er, 3), net24=round(net24, 2), adx=round(adx, 1),
                atr=round(atr, 2), atr_ratio=round(ratio, 2), vol_state=vol_state, mtf=mtf, arrows=arrows,
                agree=round(agree, 1), phase=phase, day_high=hi, day_low=lo, day_open=day_open,
                range_used=None if range_used is None else round(range_used, 2), pdh=pdh, pdl=pdl, orb=orb,
                exp_used=None if exp_used is None else round(exp_used, 2), sess_dev=round(sess_dev, 2),
                read=" ".join(parts))


# ----------------------------------------------------------------------------- news (local analyser)
WORDS = {
    "rally": 1, "rallies": 1, "surge": 1.2, "jump": 1, "soar": 1.3, "gain": .6, "rise": .5, "rose": .5, "climb": .6,
    "rebound": .9, "upgrade": .8, "bullish": 1, "inflow": .8, "buying": .6, "optimism": .8, "recover": .7,
    "recovery": .7, "boost": .6, "advance": .5, "strong": .5, "beat": .5, "cheer": .7, "positive": .5, "easing": .6,
    "fall": -.6, "fell": -.6, "slump": -1, "crash": -1.5, "drop": -.6, "decline": -.6, "selloff": -1.1,
    "plunge": -1.3, "tumble": -1.1, "slide": -.7, "bearish": -1, "outflow": -.8, "selling": -.6, "war": -1.0,
    "tension": -.7, "tariff": -.8, "downgrade": -.8, "fear": -.8, "weak": -.5, "loss": -.5, "panic": -1.3,
    "miss": -.5, "concern": -.5, "worry": -.6, "worries": -.6, "sanction": -.7, "dip": -.4, "slip": -.4,
    "retreat": -.6, "rout": -1.0, "pressure": -.4, "risk": -.3, "uncertainty": -.5, "volatile": -.3, "negative": -.5,
}
PHRASES = {
    "record high": 1.4, "all-time high": 1.4, "ends higher": .9, "settle higher": .9, "close higher": .9,
    "in the green": .8, "rate cut": 1.0, "cuts rates": 1.0, "ceasefire": .8,
    "ends lower": -.9, "settle lower": -.9, "close lower": -.9, "in the red": -.8, "rate hike": -1.0,
    "hikes rates": -1.0, "sell-off": -1.1, "sell off": -1.1, "profit booking": -.5,
}
NEGATORS = {"no", "not", "without", "avoid", "avoids", "halt", "halts", "stops", "ends", "end"}
EVENTS = {
    "RBI policy": (r"\b(rbi|mpc|repo rate|monetary policy)\b", True),
    "US Fed": (r"\b(fomc|powell|federal reserve|fed (rate|meeting|decision))\b", True),
    "Budget": (r"\bbudget\b", True),
    "Election": (r"\b(election|exit polls?|poll results?)\b", True),
    "Inflation / GDP data": (r"\b(cpi|wpi|gdp|inflation data)\b", False),
    "Geopolitics": (r"\b(war|missile|ceasefire|sanctions?|tariffs?)\b", False),
    "Earnings": (r"\b(q[1-4] (results|earnings)|earnings)\b", False),
}
_TOK = re.compile(r"[a-z][a-z\-']+")


def score_headline(title):
    s = title.lower()
    total = 0.0
    for ph, w in PHRASES.items():
        if ph in s:
            total += w
            s = s.replace(ph, " ")
    toks = _TOK.findall(s)
    for i, tk in enumerate(toks):
        w = WORDS.get(tk)
        if w is None and tk.endswith("s"):
            w = WORDS.get(tk[:-1])
        if w is None and tk.endswith("ed"):
            w = WORDS.get(tk[:-2]) or WORDS.get(tk[:-1])
        if w is None and tk.endswith("ing"):
            w = WORDS.get(tk[:-3]) or WORDS.get(tk[:-3] + "e")
        if w:
            neg = any(x in NEGATORS for x in toks[max(0, i - 2):i])
            total += -w if neg else w
    return math.tanh(total / 1.5)


def analyze_news(items, now_ts=None, llm=None):
    """items: [{title, source, ts(epoch or None)}]. Returns tone score in [-1, 1], confidence, event flags."""
    now_ts = now_ts or datetime.now().timestamp()
    seen, rows = set(), []
    for it in items or []:
        t = (it.get("title") or "").strip()
        key = re.sub(r"[^a-z0-9]", "", t.lower())[:60]
        if not t or key in seen:
            continue
        seen.add(key)
        age_h = (now_ts - it["ts"]) / 3600 if it.get("ts") else None
        w = math.exp(-max(age_h, 0) / 8) if age_h is not None else 0.4
        rows.append(dict(title=t, source=it.get("source", ""), score=round(score_headline(t), 2),
                         age_h=None if age_h is None else round(age_h, 1), w=w))
    tw = sum(r["w"] for r in rows)
    score = sum(r["score"] * r["w"] for r in rows) / tw if tw else 0.0
    mean_abs = sum(abs(r["score"]) * r["w"] for r in rows) / tw if tw else 0.0
    conf = clip(min(1.0, tw / 6.0) * (0.5 + 0.5 * min(1.0, mean_abs * 3)), 0.0, 1.0)
    flags = []
    for name, (rx, high) in EVENTS.items():
        n = sum(1 for r in rows if re.search(rx, r["title"].lower()) and (r["age_h"] is None or r["age_h"] <= 30))
        if n:
            flags.append(dict(name=name, count=n, high=high))
    risk = "HIGH" if any(f["high"] and f["count"] >= 2 for f in flags) else \
        "MEDIUM" if any(f["high"] for f in flags) else "LOW"
    out = dict(engine="lexicon", score=round(score, 3), confidence=round(conf, 2), count=len(rows),
               tone="POSITIVE" if score > 0.12 else "NEGATIVE" if score < -0.12 else "MIXED" if rows else "N/A",
               event_risk=risk, events=flags, items=sorted(rows, key=lambda r: -abs(r["score"]) * r["w"])[:12],
               headlines=[r["title"] for r in rows[:6]], llm=None)
    for r in out["items"]:
        r.pop("w", None)
    if llm and llm.get("ok"):
        out["llm"] = llm
        out["engine"] = "lexicon + Claude"
        out["score"] = round(0.4 * score + 0.6 * clip(llm.get("news_impact", 0.0)), 3)
        out["confidence"] = round(max(out["confidence"], 0.6), 2)
        out["tone"] = "POSITIVE" if out["score"] > 0.12 else "NEGATIVE" if out["score"] < -0.12 else "MIXED"
        rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
        if rank.get(llm.get("event_risk"), 0) > rank[risk]:
            out["event_risk"] = llm["event_risk"]
    return out


# ----------------------------------------------------------------------------- optional Claude review
def llm_review(snapshot, headlines, api_key=None, model=None, timeout=25):
    """Second opinion from Claude. Needs ANTHROPIC_API_KEY. Returns {ok: False, ...} on any problem."""
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return dict(ok=False, reason="no ANTHROPIC_API_KEY")
    model = model or os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
    import requests
    prompt = (
        "You are a risk reviewer for an Indian index-options desk. You are given a live market snapshot produced by a "
        "statistical engine and recent headlines. Judge ONLY what is in the data. Reply with one JSON object and nothing else:\n"
        '{"market_bias":"BULLISH|BEARISH|NEUTRAL","news_impact":-1..1,"event_risk":"LOW|MEDIUM|HIGH",'
        '"veto":true|false,"veto_reason":"short","summary":"max 2 sentences"}\n'
        "veto=true only if the proposed trade fights a clear news/event risk or the snapshot looks inconsistent.\n\n"
        f"SNAPSHOT:\n{json.dumps(snapshot, default=str)}\n\nHEADLINES:\n" + "\n".join(f"- {h}" for h in headlines[:12]))
    try:
        r = requests.post("https://api.anthropic.com/v1/messages", timeout=timeout,
                          headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                          json={"model": model, "max_tokens": 400, "messages": [{"role": "user", "content": prompt}]})
        r.raise_for_status()
        text = "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")
        return parse_llm_json(text, model)
    except Exception as e:
        return dict(ok=False, reason=f"{type(e).__name__}: {e}")


def parse_llm_json(text, model=""):
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return dict(ok=False, reason="no JSON in reply")
    try:
        j = json.loads(m.group(0))
        return dict(ok=True, model=model, market_bias=str(j.get("market_bias", "NEUTRAL")).upper(),
                    news_impact=clip(float(j.get("news_impact", 0) or 0)),
                    event_risk=str(j.get("event_risk", "LOW")).upper(), veto=bool(j.get("veto", False)),
                    veto_reason=str(j.get("veto_reason", ""))[:200], summary=str(j.get("summary", ""))[:400])
    except Exception as e:
        return dict(ok=False, reason=f"bad JSON: {e}")


# ----------------------------------------------------------------------------- external context tilt
def external_tilt(spot, atr, chain, gift, news, now, flow=None):
    parts = []

    def add(name, detail, val, w):
        parts.append(dict(name=name, detail=detail, value=round(float(val), 2), weight=round(float(w), 2)))

    if chain:
        pcr = chain.get("pcr_near")
        if pcr:
            add("Put/Call ratio (near ATM)", f"{pcr:.2f}", clip((pcr - 1.0) / 0.35), 0.30)
        bu = chain.get("buildup")
        if bu:
            add("Open-interest build-up", bu.title(), clip(chain.get("buildup_pts", 0) / 10), 0.20)
        sup, res = chain.get("support"), chain.get("resistance")
        if sup and res and atr > 0:
            d_res, d_sup = (res - spot) / atr, (spot - sup) / atr
            if d_res < -0.25:
                add("OI walls", f"Above resistance {res:,.0f} (breakout)", 0.6, 0.20)
            elif d_sup < -0.25:
                add("OI walls", f"Below support {sup:,.0f} (breakdown)", -0.6, 0.20)
            else:
                v = clip((d_sup - d_res) / (abs(d_sup) + abs(d_res) + 1e-9))
                add("OI walls", f"{d_sup:.1f} ATR above support {sup:,.0f}, {d_res:.1f} ATR below resistance {res:,.0f}", v, 0.20)
        mp = chain.get("max_pain")
        if mp and atr > 0:
            add("Max-pain pull", f"{mp:,.0f}", clip((mp - spot) / atr / 8), 0.10 if (chain.get("dte") or 9) <= 1 else 0.05)
    if gift and (now.hour, now.minute) < (10, 30):
        pct = float(gift.get("change_pct") or 0)
        add("GIFT Nifty (early session)", f"{pct:+.2f}%", clip(pct / 0.6), 0.15)
    if news and news.get("confidence", 0) > 0.15 and news.get("count", 0):
        add("News tone", f"{news['tone'].title()} ({news['count']} headlines)", clip(news["score"] * 1.5),
            0.10 + 0.20 * news["confidence"])
    if flow and flow.get("ok"):
        for p in flow.get("parts", []):
            add(p["name"], p["detail"], p["value"], p["weight"])
    sw = sum(p["weight"] for p in parts)
    tilt = sum(p["value"] * p["weight"] for p in parts) / sw if sw else 0.0
    if 0 < sw < 0.3:
        tilt *= sw / 0.3
    return clip(tilt), parts


# ----------------------------------------------------------------------------- option premium helper
def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def bs_delta(spot, strike, days, iv_pct, is_call, r=0.07):
    if not (iv_pct and iv_pct > 0 and days is not None):
        return 0.5
    T = max(days, 0.15) / 365.0
    s = iv_pct / 100.0
    try:
        d1 = (math.log(spot / strike) + (r + s * s / 2) * T) / (s * math.sqrt(T))
    except ValueError:
        return 0.5
    delta = _ncdf(d1) if is_call else 1 - _ncdf(d1)       # absolute delta
    return max(0.05, min(0.95, delta))


def build_plan(side, px, atr, chain=None):
    sg = 1 if side == "CALL" else -1
    plan = dict(side=side, entry=px, stoploss=px - sg * STOP_ATR * atr, target1=px + sg * TARGET_ATR * atr,
                target2=px + sg * T2_ATR * atr, sl_pts=STOP_ATR * atr, t1_pts=TARGET_ATR * atr, t2_pts=T2_ATR * atr,
                rr=round(TARGET_ATR / STOP_ATR, 2), max_bars=HORIZON, option=None)
    if chain:
        prem = chain.get("ce_ltp" if side == "CALL" else "pe_ltp") or 0
        iv = chain.get("ce_iv" if side == "CALL" else "pe_iv") or 0
        if prem > 0:
            dl = bs_delta(px, chain["atm"], chain.get("dte"), iv, side == "CALL")
            plan["option"] = dict(strike=chain["atm"], type="CE" if side == "CALL" else "PE", premium=prem,
                                  delta=round(dl, 2), sl_prem=max(prem - dl * plan["sl_pts"], prem * 0.15),
                                  t1_prem=prem + dl * plan["t1_pts"], t2_prem=prem + dl * plan["t2_pts"], expiry=chain.get("expiry"))
            try:
                from greeks import bs_greeks
                g = bs_greeks(px, chain["atm"], chain.get("dte"), iv, side == "CALL")
                plan["option"].update(gamma=g["gamma"], theta=g["theta"], vega=g["vega"])
            except Exception:
                pass
    return plan


# ----------------------------------------------------------------------------- decision
def _words(contrib, side_name, k=3):
    items = sorted(contrib.items(), key=lambda kv: -abs(kv[1]))[:k]
    out = []
    for name, v in items:
        if abs(v) < 0.004:
            continue
        out.append(dict(text=f"{FEATURE_LABELS[name]} {'supports' if v > 0 else 'works against'} a {side_name}", kind="good" if v > 0 else "bad",
                        value=round(v, 3)))
    return out


def decide(M, pred, tilt, parts, regime, news, chain_ok, sens, blockers, inst_name, llm=None, dte=None):
    S = SENSITIVITY.get(sens, SENSITIVITY["Balanced"])
    rel = M.get("rel", 0.0) if M.get("models") else 0.0
    scale = max(rel, S["floor"]) if M.get("models") else 0.0
    evl_m = (pred["ev_long"] * scale) if pred else 0.0
    evs_m = (pred["ev_short"] * scale) if pred else 0.0
    ev_long = evl_m + TILT_R * tilt - COST_R
    ev_short = evs_m - TILT_R * tilt - COST_R
    lean = "CALL" if ev_long > ev_short else "PUT"
    ev, ev_other = (ev_long, ev_short) if lean == "CALL" else (ev_short, ev_long)
    blockers = list(blockers)
    notes = []
    if llm and llm.get("ok") and llm.get("veto"):
        blockers.append(f"AI reviewer veto: {llm.get('veto_reason') or 'risk flagged'}")
    ok_edge = ev >= S["ev_min"] and (ev - ev_other) >= S["margin"]
    action = f"BUY {lean}" if (ok_edge and not blockers) else "WAIT"
    conf = clip(40 + 400 * max(ev, 0.0), 0, 98)
    if not chain_ok:
        conf = min(conf, 80)
        notes.append("Option chain unavailable: confidence capped.")
    if news and news.get("event_risk") == "HIGH":
        conf -= 12
        notes.append("High-impact event risk in the news.")
    elif news and news.get("event_risk") == "MEDIUM":
        conf -= 5
    if regime["tone"] == "warn" and regime["label"].startswith("Volatile"):
        conf -= 8
    conf = int(clip(conf, 0, 98))
    grade = "A+" if conf >= 85 else "A" if conf >= 70 else "B" if conf >= 55 else "C"

    size = 1.0
    if (news and news.get("event_risk") in ("MEDIUM", "HIGH")) or regime["label"].startswith("Volatile"):
        size *= 0.5
    if dte == 0:
        size *= 0.5
    if conf < 60:
        size *= 0.75

    reasons = []
    if pred and scale > 0:
        reasons += _words(pred["contrib_long" if lean == "CALL" else "contrib_short"], lean)
    for p in sorted(parts, key=lambda p: -abs(p["value"] * p["weight"]))[:3]:
        v = p["value"] if lean == "CALL" else -p["value"]
        if abs(v) >= 0.15:
            reasons.append(dict(text=f"{p['name']}: {p['detail']}", kind="good" if v > 0 else "bad", value=round(v * p["weight"], 3)))
    if M.get("models") is None:
        reasons.append(dict(text="Learning model is not ready; decision uses market context only.", kind="neutral", value=0))
    elif rel < 0.15:
        reasons.append(dict(text="Model showed no clear edge on unseen data, so its vote is down-weighted.", kind="neutral", value=0))

    if action == "WAIT":
        if blockers:
            summary = f"Waiting: {blockers[0]}."
        elif not ok_edge:
            summary = (f"No trade: best side is {lean} but expected edge is {ev:+.2f}R after costs "
                       f"(needs {S['ev_min']:+.2f}R and a clear lead over the other side).")
        else:
            summary = "Waiting."
    else:
        summary = (f"{action}: expected edge {ev:+.2f}R per trade after costs (stop 1R, target 1.5R). "
                   f"Market is {regime['label'].lower()}; model reliability {int(rel * 100)}%.")
    return dict(action=action, lean=lean, confidence=conf, grade=grade, ev=round(ev, 3), ev_long=round(ev_long, 3),
                ev_short=round(ev_short, 3), model_scale=round(scale, 2), size_factor=round(size, 2), blockers=blockers,
                notes=notes, reasons=reasons[:7], summary=summary, sensitivity=sens, thresholds=S)


def analyze(d, now_n, chain=None, gift=None, news=None, vix=None, sens="Balanced", blockers=None, llm=None,
            inst_name="Index", min_rows=300, flow=None):
    """Full read of the market from closed candles `d`. No I/O."""
    f, aux = build_features(d)
    rl, rs = triple_barrier(d, aux["atr"].values)
    M = train_models(f, rl, rs, min_rows=min_rows)
    pred = predict_latest(M, f)
    regime = read_market(d, aux, chain, vix, inst_name)
    px, atr = float(d["Close"].iloc[-1]), float(aux["atr"].iloc[-1])
    tilt, parts = external_tilt(px, atr, chain, gift, news, now_n, flow)
    dec = decide(M, pred, tilt, parts, regime, news, chain is not None, sens, blockers or [], inst_name, llm,
                 dte=(chain or {}).get("dte"))
    if flow and flow.get("iv_crush") and dec["action"] != "WAIT":
        dec["size_factor"] = round(dec["size_factor"] * 0.75, 2)
        dec["notes"].append("Implied volatility is falling fast: premiums can shrink even if direction is right. Size reduced.")
    side = dec["lean"]
    plan = build_plan(side, px, atr, chain)
    plan["confirmed"] = dec["action"] != "WAIT"
    top = []
    if pred:
        contrib = pred["contrib_long" if side == "CALL" else "contrib_short"]
        top = [dict(name=FEATURE_LABELS[k], key=k, value=round(v, 4)) for k, v in sorted(contrib.items(), key=lambda kv: -abs(kv[1]))]
    model = {k: v for k, v in M.items() if k != "models"}
    model.update(ev_long_raw=None if not pred else round(pred["ev_long"], 4), ev_short_raw=None if not pred else round(pred["ev_short"], 4),
                 top_features=top)
    return dict(decision=dec, regime=regime, model=model, context=dict(tilt=round(tilt, 3), parts=parts), plan=plan,
                tech=dict(price=px, atr=atr, rsi=float(rsi_calc(d["Close"]).iloc[-1]), adx=regime["adx"],
                          ema20=float(aux["ema20"].iloc[-1]), ema50=float(aux["ema50"].iloc[-1]),
                          sess_mean=float(aux["sess_mean"].iloc[-1])), aux=aux)


# ----------------------------------------------------------------------------- journal (live accountability)
def _parse_ts(s):
    return datetime.strptime(s, "%d-%m-%Y %H:%M:%S")


def resolve_journal(hist, d):
    """Close PENDING signals using candles printed after the signal. Stop first if both hit in one candle."""
    changed = False
    for e in hist:
        if e.get("status", "PENDING") != "PENDING" or "candle_time" not in e:
            continue
        t0 = pd.Timestamp(_parse_ts(e["candle_time"]))
        fut = d[d.index > t0]
        fut = fut[fut.index.normalize() == t0.normalize()].iloc[:e.get("max_bars", HORIZON)]
        sign = 1 if e["signal"] == "BUY CALL" else -1
        risk = abs(e["entry"] - e["stoploss"]) or 1.0
        res = None
        for ts_, row in fut.iterrows():
            stop_hit = row["Low"] <= e["stoploss"] if sign == 1 else row["High"] >= e["stoploss"]
            tgt_hit = row["High"] >= e["target1"] if sign == 1 else row["Low"] <= e["target1"]
            if stop_hit:
                res = ("LOSS", -1.0, ts_)
                break
            if tgt_hit:
                res = ("WIN", abs(e["target1"] - e["entry"]) / risk, ts_)
                break
        if res is None and len(fut):
            later_day = (d.index.normalize() > t0.normalize()).any()
            if len(fut) >= e.get("max_bars", HORIZON) or later_day:
                r = clip(sign * (fut["Close"].iloc[-1] - e["entry"]) / risk, -1.0, TARGET_ATR / STOP_ATR)
                res = ("TIMEOUT", r, fut.index[-1])
        if res:
            e["status"], e["r"], e["closed"] = res[0], round(float(res[1]), 2), res[2].strftime("%d-%m-%Y %H:%M:%S")
            changed = True
    return changed


def journal_stats(hist):
    done = [h for h in hist if h.get("status") in ("WIN", "LOSS", "TIMEOUT")]
    rs = [h["r"] for h in done]
    wins = [r for r in rs if r > 0]
    eq, run = [], 0.0
    for r in rs:
        run += r
        eq.append(round(run, 2))
    return dict(n=len(done), pending=sum(1 for h in hist if h.get("status", "PENDING") == "PENDING"),
                wins=len(wins), win_rate=(len(wins) / len(done) * 100 if done else None),
                avg_r=(sum(rs) / len(rs) if rs else None), total_r=round(sum(rs), 2), equity=eq,
                target_hits=sum(1 for h in done if h["status"] == "WIN"), stops=sum(1 for h in done if h["status"] == "LOSS"))


def today_guard(hist, today_str, max_signals, stop_after_losses):
    """Daily risk limits. Returns list of blocker strings."""
    todays = [h for h in hist if h.get("time", "")[:10] == today_str]
    out = []
    if len(todays) >= max_signals:
        out.append(f"Daily signal limit reached ({max_signals})")
    streak = 0
    for h in reversed(todays):
        if h.get("status") in ("LOSS",):
            streak += 1
        elif h.get("status") in ("WIN", "TIMEOUT") and h.get("r", 0) > 0:
            break
        elif h.get("status") == "PENDING":
            continue
        else:
            break
    if streak >= stop_after_losses:
        out.append(f"{streak} losses in a row today: paused for the day")
    return out

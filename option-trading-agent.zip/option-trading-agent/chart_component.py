"""chart_component.py - TradingView lightweight-charts wrapper for Streamlit (components.html).

chart_html(candles, lines, markers, levels, volume, title, height, font, bars, colors) -> html string
  candles : [{time, open, high, low, close}]            time = epoch seconds (IST wall clock, shown as-is)
  lines   : [{name, color, data:[{time,value}], width, dashed}]
  markers : [{time, position, color, shape, size, text}]
  levels  : [{price, title, color, dashed}]
  volume  : [{time, value, color}] or []
Needs internet once to load the chart library from the CDN (pinned version).
"""
import json
from html import escape

LIB = "https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js"


def _js(obj):
    return json.dumps(obj).replace("</", "<\\/")


def chart_html(candles, lines, markers, levels, volume, title, height, font, bars, colors):
    c = colors
    title = escape(str(title), quote=True).replace("\\", "")
    cfg = dict(candles=candles, lines=lines or [], markers=markers or [], levels=levels or [], volume=volume or [],
               bars=int(bars), font=int(font), height=int(height), UP=c["UP"], DOWN=c["DOWN"], BG=c["BG"],
               MUTED=c["MUTED"], GRID=c["GRID"], BORDER=c["BORDER"])
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
html,body{{margin:0;padding:0;background:{c['BG']};font-family:'IBM Plex Sans',system-ui,sans-serif;}}
#wrap{{position:relative;width:100%;height:{int(height)}px;}}
#chart{{position:absolute;inset:0;}}
#legend{{position:absolute;left:10px;top:8px;z-index:5;color:{c['MUTED']};font-size:{int(font)}px;pointer-events:none;
  display:flex;flex-wrap:wrap;gap:6px 14px;max-width:92%;}}
#legend b{{color:{c['MUTED']};font-weight:600;margin-right:4px;}}
#legend i{{display:inline-block;width:14px;height:3px;margin-right:5px;vertical-align:middle;border-radius:2px;}}
#err{{display:none;color:{c['MUTED']};padding:30px;font-size:{int(font)}px;}}
</style></head><body>
<div id="wrap"><div id="legend"></div><div id="chart"></div><div id="err">Chart library could not load. Check your internet connection and refresh.</div></div>
<script src="{LIB}"></script>
<script>
const CFG = {_js(cfg)};
(function(){{
  if (typeof LightweightCharts === 'undefined') {{ document.getElementById('err').style.display='block'; return; }}
  const el = document.getElementById('chart');
  const chart = LightweightCharts.createChart(el, {{
    width: el.clientWidth, height: CFG.height,
    layout: {{ background: {{ type: 'solid', color: CFG.BG }}, textColor: CFG.MUTED, fontSize: CFG.font }},
    grid: {{ vertLines: {{ color: CFG.GRID }}, horzLines: {{ color: CFG.GRID }} }},
    rightPriceScale: {{ borderColor: CFG.BORDER }},
    timeScale: {{ borderColor: CFG.BORDER, timeVisible: true, secondsVisible: false, rightOffset: 6 }},
    crosshair: {{ mode: 0 }},
  }});
  const cs = chart.addCandlestickSeries({{ upColor: CFG.UP, downColor: CFG.DOWN, borderVisible: false,
    wickUpColor: CFG.UP, wickDownColor: CFG.DOWN }});
  cs.setData(CFG.candles);
  const legend = document.getElementById('legend');
  legend.innerHTML = '<b>{title}</b>';
  CFG.lines.forEach(function(L) {{
    if (!L.data || !L.data.length) return;
    const s = chart.addLineSeries({{ color: L.color, lineWidth: L.width || 1, lineStyle: L.dashed ? 2 : 0,
      priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false }});
    s.setData(L.data);
    legend.insertAdjacentHTML('beforeend', '<span><i style="background:' + L.color + '"></i>' + L.name + '</span>');
  }});
  if (CFG.volume.length) {{
    const v = chart.addHistogramSeries({{ priceFormat: {{ type: 'volume' }}, priceScaleId: 'vol' }});
    chart.priceScale('vol').applyOptions({{ scaleMargins: {{ top: 0.82, bottom: 0 }} }});
    v.setData(CFG.volume);
  }}
  const known = new Set(CFG.candles.map(function(x) {{ return x.time; }}));
  const mk = CFG.markers.filter(function(m) {{ return known.has(m.time); }}).sort(function(a, b) {{ return a.time - b.time; }});
  if (mk.length) cs.setMarkers(mk);
  CFG.levels.forEach(function(L) {{
    cs.createPriceLine({{ price: L.price, color: L.color, lineWidth: 1, lineStyle: L.dashed === false ? 0 : 2,
      axisLabelVisible: true, title: L.title }});
  }});
  const n = CFG.candles.length;
  chart.timeScale().setVisibleLogicalRange({{ from: Math.max(0, n - CFG.bars), to: n + 6 }});
  new ResizeObserver(function() {{ chart.applyOptions({{ width: el.clientWidth }}); }}).observe(el);
}})();
</script></body></html>"""
